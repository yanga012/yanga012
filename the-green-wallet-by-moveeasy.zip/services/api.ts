import type { User, Project, SavingsGoal, Transaction } from '../types';

type UserRecord = User & { 
  password_hash: string;
  emailVerificationCode: string;
  phoneVerificationCode: string;
};

// MOCK DATABASE
const MOCK_USERS: { [email:string]: UserRecord } = {
  'green@moveeasy.app': {
    id: 'user-green-1',
    email: 'green@moveeasy.app',
    phone: '0821234567',
    password_hash: 'password123',
    isEmailVerified: false,
    isPhoneVerified: false,
    isVerified: false, // KYC
    kycSkipped: false,
    emailVerificationCode: '123456',
    phoneVerificationCode: '654321'
  },
};

const MOCK_PROJECTS: Project[] = [
    { id: 'proj-solar-home', name: 'Home Solar Starter Kit', description: 'A 5kW inverter, 10kWh battery, and 8 solar panels. Perfect for a standard 3-bedroom house.', totalCost: 85000, category: 'Residential', imageUrl: 'https://images.pexels.com/photos/159397/solar-panel-array-power-sun-electricity-159397.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', supplier: 'SunPower Inc.' },
    { id: 'proj-solar-geyser', name: 'Solar Geyser System', description: 'Reduce your electricity bill by heating your water with the sun. 150L capacity.', totalCost: 22000, category: 'Residential', imageUrl: 'https://images.pexels.com/photos/3867623/pexels-photo-3867623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', supplier: 'GeoHeat Systems' },
    { id: 'proj-biz-backup', name: 'Business Backup Power', description: 'A 10kW inverter and 20kWh battery solution to keep your small business running during outages.', totalCost: 150000, category: 'Commercial', imageUrl: 'https://images.pexels.com/photos/7249187/pexels-photo-7249187.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', supplier: 'PowerSecure Ltd.' },
    { id: 'proj-water-pump', name: 'Solar Water Pump', description: 'Ideal for small farms or off-grid properties. Provides consistent water supply powered by solar.', totalCost: 35000, category: 'Community', imageUrl: 'https://images.pexels.com/photos/11822365/pexels-photo-11822365.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', supplier: 'AquaSolar' },
];

let MOCK_SAVINGS_GOALS: SavingsGoal[] = [
    { id: 'goal-1', projectId: 'proj-solar-home', userId: 'user-green-1', savedAmount: 25000, status: 'saving' },
    { id: 'goal-2', projectId: 'proj-solar-geyser', userId: 'user-green-1', savedAmount: 22000, status: 'complete' },
];

let MOCK_TRANSACTIONS: Transaction[] = [];

const SESSION_KEY = 'moveeasy_green_wallet_session';

// API IMPLEMENTATION
export const getSession = async (): Promise<User | null> => {
  const sessionEmail = localStorage.getItem(SESSION_KEY);
  if (!sessionEmail) return null;
  const user = MOCK_USERS[sessionEmail];
  if (!user) {
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
  const { password_hash, emailVerificationCode, phoneVerificationCode, ...userProfile } = user;
  return userProfile;
};

export const signIn = async (email: string, password: string): Promise<User> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = MOCK_USERS[email];
      if (user && password.length > 0) {
         if (!user.isEmailVerified) {
          return reject(new Error('Please verify your email address before signing in.'));
        }
        localStorage.setItem(SESSION_KEY, email);
        const { password_hash, emailVerificationCode, phoneVerificationCode, ...userProfile } = user;
        resolve(userProfile);
      } else {
        reject(new Error('Invalid email or password.'));
      }
    }, 1000);
  });
};

export const signUp = async (email: string, phone: string, password: string): Promise<{ success: boolean }> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (MOCK_USERS[email]) {
                return reject(new Error('An account with this email already exists.'));
            }
            MOCK_USERS[email] = {
                id: `user-${Date.now()}`,
                email,
                phone,
                password_hash: password,
                isEmailVerified: false,
                isPhoneVerified: false,
                isVerified: false,
                kycSkipped: false,
                emailVerificationCode: String(Math.floor(100000 + Math.random() * 900000)),
                phoneVerificationCode: String(Math.floor(100000 + Math.random() * 900000)),
            };
            console.log(`Verification code for ${email}: ${MOCK_USERS[email].emailVerificationCode}`);
            resolve({ success: true });
        }, 1000);
    });
};

export const verifyEmail = async (email: string, code: string): Promise<{ success: boolean }> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = MOCK_USERS[email];
            if (user && user.emailVerificationCode === code) {
                user.isEmailVerified = true;
                resolve({ success: true });
            } else {
                reject(new Error('Invalid verification code.'));
            }
        }, 1000);
    });
};

export const verifyPhone = async (userId: string, code: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const userEmail = Object.keys(MOCK_USERS).find(email => MOCK_USERS[email].id === userId);
            const user = userEmail ? MOCK_USERS[userEmail] : undefined;
            if (user && user.phoneVerificationCode === code) {
                user.isPhoneVerified = true;
                const { password_hash, emailVerificationCode, phoneVerificationCode, ...userProfile } = user;
                resolve(userProfile);
            } else {
                reject(new Error('Invalid verification code.'));
            }
        }, 1000);
    });
};

export const signOut = async (): Promise<void> => {
    localStorage.removeItem(SESSION_KEY);
};

export const getProjects = async (): Promise<Project[]> => {
    return new Promise(resolve => setTimeout(() => resolve(MOCK_PROJECTS), 500));
};

export const getProjectById = async (id: string): Promise<Project | undefined> => {
    return Promise.resolve(MOCK_PROJECTS.find(p => p.id === id));
};

export const getSavingsGoalsForUser = async (userId: string): Promise<SavingsGoal[]> => {
    return new Promise(resolve => {
        setTimeout(() => {
            const goals = MOCK_SAVINGS_GOALS.filter(g => g.userId === userId);
            resolve(goals.sort((a,b) => (a.status === 'saving' ? -1 : 1))); // Active goals first
        }, 500);
    });
};

export const startNewGoal = async (userId: string, projectId: string): Promise<SavingsGoal> => {
    return new Promise((resolve, reject) => {
        if (MOCK_SAVINGS_GOALS.some(g => g.userId === userId && g.projectId === projectId && g.status !== 'complete')) {
            return reject(new Error('You already have an active goal for this project.'));
        }
        const newGoal: SavingsGoal = {
            id: `goal-${Date.now()}`,
            projectId,
            userId,
            savedAmount: 0,
            status: 'saving',
        };
        MOCK_SAVINGS_GOALS.push(newGoal);
        resolve(newGoal);
    });
};

export const addFundsToGoal = async (goalId: string, amount: number): Promise<SavingsGoal> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const goal = MOCK_SAVINGS_GOALS.find(g => g.id === goalId);
            if (!goal) return reject(new Error('Savings goal not found.'));
            if (goal.status !== 'saving') return reject(new Error('Can only add funds to an active goal.'));
            
            goal.savedAmount += amount;

            const newTransaction: Transaction = {
                id: `txn-${Date.now()}`,
                goalId: goal.id,
                type: 'deposit',
                amount,
                date: new Date().toISOString(),
            };
            MOCK_TRANSACTIONS.push(newTransaction);
            resolve(goal);
        }, 1500);
    });
};

export const requestProjectInstallation = async (goalId: string): Promise<SavingsGoal> => {
    return new Promise(async (resolve, reject) => {
        const goal = MOCK_SAVINGS_GOALS.find(g => g.id === goalId);
        if (!goal) return reject(new Error('Savings goal not found.'));

        const project = await getProjectById(goal.projectId);
        if (!project) return reject(new Error('Associated project not found.'));

        const requiredAmount = project.totalCost / 3;
        if (goal.savedAmount < requiredAmount) {
            return reject(new Error('You have not saved enough to unlock this project.'));
        }

        goal.status = 'unlocked';
        
        // Simulate backend process
        setTimeout(() => {
            goal.status = 'installation_in_progress';
            console.log(`Installation for goal ${goal.id} has been scheduled.`);
        }, 3000);

        resolve(goal);
    });
};

export const submitKYC = async (userId: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const userEmail = Object.keys(MOCK_USERS).find(email => MOCK_USERS[email].id === userId);
            if (userEmail && MOCK_USERS[userEmail]) {
                MOCK_USERS[userEmail].isVerified = true;
                MOCK_USERS[userEmail].kycSkipped = false;
                const { password_hash, emailVerificationCode, phoneVerificationCode, ...userProfile } = MOCK_USERS[userEmail];
                resolve(userProfile);
            } else {
                reject(new Error('User not found.'));
            }
        }, 2000); // Simulate network delay and processing time
    });
};

export const skipKYC = async (userId: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const userEmail = Object.keys(MOCK_USERS).find(email => MOCK_USERS[email].id === userId);
            if (userEmail && MOCK_USERS[userEmail]) {
                MOCK_USERS[userEmail].kycSkipped = true;
                const { password_hash, emailVerificationCode, phoneVerificationCode, ...userProfile } = MOCK_USERS[userEmail];
                resolve(userProfile);
            } else {
                reject(new Error('User not found.'));
            }
        }, 500);
    });
}

export const resetKYCSkip = async (userId: string): Promise<User> => {
     return new Promise((resolve, reject) => {
        setTimeout(() => {
            const userEmail = Object.keys(MOCK_USERS).find(email => MOCK_USERS[email].id === userId);
            if (userEmail && MOCK_USERS[userEmail]) {
                MOCK_USERS[userEmail].kycSkipped = false;
                const { password_hash, emailVerificationCode, phoneVerificationCode, ...userProfile } = MOCK_USERS[userEmail];
                resolve(userProfile);
            } else {
                reject(new Error('User not found.'));
            }
        }, 500);
    });
}