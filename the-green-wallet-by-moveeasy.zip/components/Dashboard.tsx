import React, { useState, useEffect, useCallback } from 'react';
import type { User, Project, SavingsGoal } from '../types';
import { signOut, getProjects, getSavingsGoalsForUser, startNewGoal } from '../services/api';
import MoveEasyLogo from './icons/MoveEasyLogo';
import BottomNavBar, { type View } from './BottomNavBar';
import HomeView from './HomeView';
import ProjectBrowser from './ProjectBrowser';
import MyGoals from './MyGoals';
import DepositModal from './DepositModal';
import VerificationBanner from './VerificationBanner';

interface DashboardProps {
  user: User;
  onLogout: () => void;
  onStartVerification: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user: initialUser, onLogout, onStartVerification }) => {
  const [user, setUser] = useState<User>(initialUser);
  const [view, setView] = useState<View>('home');
  
  const [projects, setProjects] = useState<Project[]>([]);
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  
  const [isLoading, setIsLoading] = useState(true);
  
  const [isDepositModalOpen, setDepositModalOpen] = useState(false);
  const [goalToDeposit, setGoalToDeposit] = useState<SavingsGoal | null>(null);
  
  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
        const [fetchedProjects, fetchedGoals] = await Promise.all([
          getProjects(),
          getSavingsGoalsForUser(user.id),
        ]);
        setProjects(fetchedProjects);
        setGoals(fetchedGoals);
    } catch (error) {
        console.error("Failed to fetch data:", error);
    } finally {
        setIsLoading(false);
    }
  }, [user.id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleStartGoal = async (projectId: string) => {
    try {
      await startNewGoal(user.id, projectId);
      fetchData(); // Refresh data to show the new goal
      setView('goals'); // Switch to the goals view
    } catch (error: any) {
        alert(error.message); // Simple error handling for demo
    }
  };

  const handleOpenDepositModal = (goal: SavingsGoal) => {
    setGoalToDeposit(goal);
    setDepositModalOpen(true);
  };

  const handleDepositSuccess = () => {
    setDepositModalOpen(false);
    setGoalToDeposit(null);
    fetchData(); // Refresh goals to show new balance
  };

  const handleLogout = async () => {
    await signOut();
    onLogout();
  };
  
  const renderProfileView = () => (
    <div className="space-y-6 bg-white p-6 rounded-2xl shadow-lg">
        <div className="text-center">
            <h3 className="text-xl font-bold text-slate-800">{user.email}</h3>
            <p className="text-sm text-slate-500">{user.phone}</p>
            <p className={`mt-2 text-xs font-bold px-2 py-1 rounded-full inline-block ${user.isVerified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
              {user.isVerified ? 'KYC Verified' : 'Verification Incomplete'}
            </p>
        </div>
        <button 
            onClick={handleLogout} 
            className="w-full mt-4 px-4 py-3 text-base font-bold text-red-600 bg-red-50 rounded-lg hover:bg-red-100"
        >
            Logout
        </button>
    </div>
  );

  const renderView = () => {
    switch (view) {
      case 'projects':
        return <ProjectBrowser projects={projects} isLoading={isLoading} onStartGoal={handleStartGoal} />;
      case 'goals':
        return <MyGoals goals={goals} projects={projects} isLoading={isLoading} onDeposit={handleOpenDepositModal} onRefresh={fetchData} />;
      case 'profile':
        return renderProfileView();
      case 'home':
      default:
        return <HomeView goals={goals} projects={projects} setView={setView} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white/80 backdrop-blur-lg sticky top-0 z-10 p-4 border-b border-slate-200">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <MoveEasyLogo className="h-8 w-8" />
            <h1 className="text-xl font-bold text-slate-800">Green Wallet</h1>
          </div>
        </div>
      </header>
      
      <main className="flex-grow max-w-5xl w-full mx-auto p-4 sm:p-6 pb-24">
        {!user.isVerified && <VerificationBanner onStartVerification={onStartVerification} />}
        {renderView()}
      </main>

      <BottomNavBar currentView={view} setView={setView} />
      
      {isDepositModalOpen && goalToDeposit && (
        <DepositModal 
            goal={goalToDeposit}
            project={projects.find(p => p.id === goalToDeposit.projectId)}
            onClose={() => setDepositModalOpen(false)}
            onSuccess={handleDepositSuccess}
        />
      )}
    </div>
  );
};
export default Dashboard;