import React, { useState } from 'react';
import type { User } from '../types';
import { verifyPhone } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';

interface PhoneVerificationProps {
  user: User;
  onSuccess: (user: User) => void;
}

const PhoneVerification: React.FC<PhoneVerificationProps> = ({ user, onSuccess }) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const updatedUser = await verifyPhone(user.id, code);
      onSuccess(updatedUser);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
        <p className="text-center text-slate-600 mb-6">For your security, please enter the verification code we've sent to your console for phone number <span className="font-bold">{user.phone}</span>.</p>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label htmlFor="code" className="text-sm font-medium text-slate-700">Verification Code</label>
          <input
            id="code"
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="123456"
            required
            className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
            disabled={loading}
          />
        </div>
         {error && <p className="text-center text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          className="w-full mt-2 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 flex items-center justify-center"
          disabled={loading}
        >
          {loading ? <LoaderIcon className="h-6 w-6" /> : 'Verify and Continue'}
        </button>
      </form>
    </div>
  );
};

export default PhoneVerification;
