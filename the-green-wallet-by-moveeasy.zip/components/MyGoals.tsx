import React from 'react';
import type { SavingsGoal, Project } from '../types';
import GoalCard from './GoalCard';
import LoaderIcon from './icons/LoaderIcon';

interface MyGoalsProps {
  goals: SavingsGoal[];
  projects: Project[];
  isLoading: boolean;
  onDeposit: (goal: SavingsGoal) => void;
  onRefresh: () => void;
}

const MyGoals: React.FC<MyGoalsProps> = ({ goals, projects, isLoading, onDeposit, onRefresh }) => {
  if (isLoading) {
    return <div className="flex justify-center p-10"><LoaderIcon className="h-10 w-10 text-teal-500" /></div>;
  }
  
  if (goals.length === 0) {
      return <div className="text-center bg-white p-8 rounded-2xl shadow-lg">You haven't started any savings goals yet.</div>
  }

  return (
    <div>
       <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800">My Savings Goals</h2>
        <p className="text-md text-slate-500 mt-2">Track your progress and manage your green energy projects.</p>
      </div>
      <div className="space-y-6">
        {goals.map(goal => {
          const project = projects.find(p => p.id === goal.projectId);
          if (!project) return null;
          return <GoalCard key={goal.id} goal={goal} project={project} onDeposit={onDeposit} onRefresh={onRefresh} />;
        })}
      </div>
    </div>
  );
};

export default MyGoals;