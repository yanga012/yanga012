import React from 'react';
import type { SavingsGoal, Project } from '../types';
import { formatCurrency } from '../types';
import GoalCard from './GoalCard';
import type { View } from './BottomNavBar';

interface HomeViewProps {
  goals: SavingsGoal[];
  projects: Project[];
  setView: (view: View) => void;
}

const HomeView: React.FC<HomeViewProps> = ({ goals, projects, setView }) => {
    const totalSavings = goals.reduce((sum, goal) => sum + goal.savedAmount, 0);
    const activeGoal = goals.find(g => g.status === 'saving');
    const activeProject = activeGoal ? projects.find(p => p.id === activeGoal.projectId) : null;

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-lg text-center">
                <p className="text-sm text-slate-500">Total Savings</p>
                <p className="text-4xl font-bold text-slate-800 mt-1">{formatCurrency(totalSavings)}</p>
                <p className="text-xs text-green-600 mt-1">towards a cleaner future</p>
            </div>

            {activeGoal && activeProject ? (
                 <div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Your Active Goal</h3>
                    <GoalCard goal={activeGoal} project={activeProject} onDeposit={() => {}} onRefresh={() => {}} isPreview />
                </div>
            ) : (
                <div className="bg-white p-6 rounded-2xl shadow-lg text-center">
                    <h3 className="text-xl font-bold text-slate-800">Start a New Goal</h3>
                    <p className="text-sm text-slate-500 mt-2 mb-4">Browse our sponsored projects and start saving towards your first renewable energy installation.</p>
                    <button onClick={() => setView('projects')} className="px-6 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">
                        Browse Projects
                    </button>
                </div>
            )}
        </div>
    );
};

export default HomeView;