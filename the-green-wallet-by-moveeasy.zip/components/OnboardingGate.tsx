import React from 'react';
import type { User } from '../types';
import PhoneVerification from './PhoneVerification';
import KYC from './KYC';
import MoveEasyLogo from './icons/MoveEasyLogo';

interface OnboardingGateProps {
    user: User;
    onOnboardingComplete: () => void;
}

const OnboardingGate: React.FC<OnboardingGateProps> = ({ user, onOnboardingComplete }) => {
    
    let currentStepComponent;
    let stepTitle = '';
    let stepNumber = 0;
    const totalSteps = 2;

    if (!user.isPhoneVerified) {
        stepNumber = 1;
        stepTitle = "Verify Phone Number";
        currentStepComponent = <PhoneVerification user={user} onSuccess={onOnboardingComplete} />;
    } else if (!user.isVerified && !user.kycSkipped) {
        stepNumber = 2;
        stepTitle = "Identity Verification (KYC)";
        currentStepComponent = <KYC user={user} onVerificationSuccess={onOnboardingComplete} onSkip={onOnboardingComplete} />;
    } else {
        // Should not happen if logic in App.tsx is correct, but as a fallback:
        onOnboardingComplete();
        return null;
    }


    return (
        <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
             <header className="flex flex-col items-center text-center mb-6">
                <MoveEasyLogo className="h-10 w-10 mb-3" />
                <h1 className="text-2xl font-bold text-slate-800">
                    Account Setup
                </h1>
             </header>
            <main className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-lg w-full">
               <div className="text-center mb-6 pb-6 border-b border-slate-200">
                    <p className="text-sm font-bold text-teal-600">STEP {stepNumber} OF {totalSteps}</p>
                    <h2 className="text-xl font-bold text-slate-800 mt-1">{stepTitle}</h2>
               </div>
               {currentStepComponent}
            </main>
        </div>
    );
};

export default OnboardingGate;