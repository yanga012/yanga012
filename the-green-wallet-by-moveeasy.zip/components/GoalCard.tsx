import React, { useState } from 'react';
import type { SavingsGoal, Project } from '../types';
import { formatCurrency } from '../types';
import { requestProjectInstallation } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';

interface GoalCardProps {
  goal: SavingsGoal;
  project: Project;
  onDeposit: (goal: SavingsGoal) => void;
  onRefresh: () => void;
  isPreview?: boolean;
}

const GoalCard: React.FC<GoalCardProps> = ({ goal, project, onDeposit, onRefresh, isPreview = false }) => {
  const [isUnlocking, setIsUnlocking] = useState(false);

  const progress = (goal.savedAmount / project.totalCost) * 100;
  const unlockThreshold = project.totalCost / 3;
  const isUnlockable = goal.savedAmount >= unlockThreshold;

  const handleUnlock = async () => {
    if (!confirm('Are you sure you want to request installation? Your savings will be locked as collateral.')) return;
    setIsUnlocking(true);
    try {
        await requestProjectInstallation(goal.id);
        onRefresh(); // Refresh data to get the new status
    } catch (error: any) {
        alert(error.message);
    } finally {
        setIsUnlocking(false);
    }
  };
  
  const renderStatusOrAction = () => {
    if (isUnlocking) {
        return <div className="flex items-center justify-center gap-2 mt-4 text-slate-600"><LoaderIcon className="h-5 w-5"/> Submitting request...</div>
    }

    switch (goal.status) {
        case 'saving':
            if (isUnlockable) {
                return (
                    <button onClick={handleUnlock} className="w-full mt-4 py-3 font-bold text-white bg-green-600 rounded-lg hover:bg-green-700">
                        Unlock Project & Request Installation
                    </button>
                );
            }
            return (
                <button onClick={() => onDeposit(goal)} className="w-full mt-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">
                    Deposit Funds
                </button>
            );
        case 'unlocked':
            return <p className="mt-4 text-center font-semibold text-blue-600 bg-blue-100 p-3 rounded-lg">Status: Unlocked! A consultant will contact you shortly.</p>;
        case 'installation_in_progress':
            return <p className="mt-4 text-center font-semibold text-purple-600 bg-purple-100 p-3 rounded-lg">Status: Installation in Progress.</p>;
        case 'complete':
            return <p className="mt-4 text-center font-semibold text-green-600 bg-green-100 p-3 rounded-lg">Status: Project Complete!</p>;
        default:
            return null;
    }
  };

  return (
    <div className={`bg-white rounded-2xl shadow-lg p-6 ${goal.isNew ? 'transaction-new' : ''}`}>
      <div className="flex flex-col sm:flex-row gap-6">
        <img src={project.imageUrl} alt={project.name} className="w-full sm:w-32 h-32 rounded-lg object-cover" />
        <div className="flex-grow">
          <h3 className="text-xl font-bold text-slate-800">{project.name}</h3>
          <div className="mt-4">
            <div className="flex justify-between items-baseline text-sm mb-1">
              <span className="font-semibold text-slate-700">Progress</span>
              <span className="font-bold text-teal-600">{progress.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-4">
              <div className="bg-teal-500 h-4 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            <div className="flex justify-between items-baseline text-xs text-slate-500 mt-1">
              <span>{formatCurrency(goal.savedAmount)}</span>
              <span>{formatCurrency(project.totalCost)}</span>
            </div>
             {!isUnlockable && goal.status === 'saving' && (
                <p className="text-xs text-center mt-2 text-orange-600 bg-orange-50 p-2 rounded-md">
                    Save {formatCurrency(unlockThreshold - goal.savedAmount)} more to unlock installation.
                </p>
            )}
          </div>
        </div>
      </div>
      {!isPreview && (
        <div className="mt-4 border-t border-slate-100 pt-4">
            {renderStatusOrAction()}
        </div>
      )}
    </div>
  );
};

export default GoalCard;