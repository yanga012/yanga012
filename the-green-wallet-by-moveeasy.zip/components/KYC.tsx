import React, { useState, useRef, useEffect } from 'react';
import { skipKYC, submitKYC } from '../services/api';
import type { User } from '../types';

import LoaderIcon from './icons/LoaderIcon';
import CameraIcon from './icons/CameraIcon';
import UploadIcon from './icons/UploadIcon';

interface KYCProps {
  user: User;
  onVerificationSuccess: (user: User) => void;
  onSkip: (user: User) => void;
}

const KYC: React.FC<KYCProps> = ({ user, onVerificationSuccess, onSkip }) => {
  const [step, setStep] = useState(1);
  const [selfie, setSelfie] = useState<string | null>(null);
  const [idType, setIdType] = useState<'id' | 'passport'>('id');
  const [idNumber, setIdNumber] = useState('');
  const [idPhoto, setIdPhoto] = useState<File | null>(null);
  const [useCredit, setUseCredit] = useState(false);
  const [proofOfAddress, setProofOfAddress] = useState<File | null>(null);
  const [proofOfBank, setProofOfBank] = useState<File | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [isCapturing, setIsCapturing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError("Could not access camera. Please check permissions and refresh.");
    }
  };
  
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (step === 2 && !selfie) {
      setIsCapturing(true);
      startCamera();
    } else {
      stopCamera();
    }
    
    return () => {
      stopCamera();
    };
  }, [step, selfie]);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      context?.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
      setSelfie(canvas.toDataURL('image/jpeg'));
      setIsCapturing(false);
      stopCamera();
    }
  };
  
  const handleRetake = () => {
    setSelfie(null);
    setError(null);
    setIsCapturing(true);
  };
  
  const handleFileChange = (setter: React.Dispatch<React.SetStateAction<File | null>>) => (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setter(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    setError(null);
    setLoadingMessage('Submitting for verification...');
    setIsLoading(true);
    try {
      const updatedUser = await submitKYC(user.id);
      onVerificationSuccess(updatedUser);
    } catch (err: any) {
      setError(err.message || "An error occurred during submission.");
      setIsLoading(false);
    }
  };

  const handleSkip = async () => {
    setError(null);
    setLoadingMessage('Loading dashboard...');
    setIsLoading(true);
    try {
        const updatedUser = await skipKYC(user.id);
        onSkip(updatedUser);
    } catch (err: any) {
        setError(err.message || "An error occurred.");
        setIsLoading(false);
    }
  }

  const steps = [
    { name: 'Welcome' },
    { name: 'Selfie' },
    { name: 'ID Document' },
    { name: 'Other Docs' },
    { name: 'Submit' },
  ];
  
  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="text-center">
            <h2 className="text-2xl font-bold text-slate-800">Verify Your Identity (KYC)</h2>
            <p className="mt-2 text-slate-600">To secure your account, unlock all features, and comply with financial regulations, we need to verify your identity. The process is quick, secure, and your data is protected.</p>
            <p className="mt-4 text-sm text-slate-500 font-semibold">Please have the following ready:</p>
            <ul className="text-sm text-slate-500 list-disc list-inside text-left max-w-xs mx-auto mt-2">
              <li>A well-lit room for a clear selfie</li>
              <li>Your valid SA ID or Passport document</li>
              <li>Proof of address & banking (optional, for credit)</li>
            </ul>
          </div>
        );
      case 2:
        return (
          <div>
            <h2 className="text-xl font-bold text-slate-800 text-center">Take a Selfie</h2>
            <p className="text-sm text-slate-500 text-center mb-4">Position your face in the center of the frame.</p>
            <div className="relative w-full max-w-sm mx-auto aspect-square bg-slate-200 rounded-lg overflow-hidden flex items-center justify-center">
              {isCapturing && <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />}
              {selfie && <img src={selfie} alt="User selfie" className="w-full h-full object-cover" />}
              <canvas ref={canvasRef} className="hidden" />
            </div>
            {isCapturing && (
              <button onClick={handleCapture} className="w-full mt-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 flex items-center justify-center gap-2">
                <CameraIcon className="h-5 w-5"/> Capture
              </button>
            )}
             {selfie && (
              <div className="flex gap-4 mt-4">
                  <button onClick={handleRetake} className="w-full py-3 font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Retake</button>
                  <button onClick={() => setStep(3)} className="w-full py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Confirm & Continue</button>
              </div>
            )}
          </div>
        );
       case 3:
        return (
          <div>
            <h2 className="text-xl font-bold text-slate-800 text-center mb-4">Identity Document</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-slate-700">Document Type</label>
                <div className="grid grid-cols-2 gap-4 mt-1">
                  <button onClick={() => setIdType('id')} className={`p-3 rounded-lg border-2 text-center ${idType === 'id' ? 'border-teal-500 bg-teal-50' : 'border-slate-300'}`}>SA ID</button>
                  <button onClick={() => setIdType('passport')} className={`p-3 rounded-lg border-2 text-center ${idType === 'passport' ? 'border-teal-500 bg-teal-50' : 'border-slate-300'}`}>Passport</button>
                </div>
              </div>
              <div>
                <label htmlFor="idNumber" className="text-sm font-medium text-slate-700">{idType === 'id' ? 'ID Number' : 'Passport Number'}</label>
                <input id="idNumber" type="text" value={idNumber} onChange={e => setIdNumber(e.target.value)} className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg" />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-700">Upload Photo of Document</label>
                <label htmlFor="idPhoto" className="mt-1 w-full p-6 text-center border-2 border-dashed border-slate-300 rounded-lg cursor-pointer block hover:bg-slate-50">
                  {idPhoto ? <p className="text-slate-700 font-medium">{idPhoto.name}</p> : <><UploadIcon className="h-8 w-8 mx-auto text-slate-400"/> <p className="text-sm text-slate-500 mt-2">Click to upload</p></>}
                </label>
                <input id="idPhoto" type="file" accept="image/*" onChange={handleFileChange(setIdPhoto)} className="hidden" />
              </div>
            </div>
          </div>
        );
        case 4:
            return (
                <div>
                    <h2 className="text-xl font-bold text-slate-800 text-center mb-4">Financial Documents</h2>
                     <div className="space-y-4">
                        <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-lg">
                           <input type="checkbox" id="useCredit" checked={useCredit} onChange={e => setUseCredit(e.target.checked)} className="h-5 w-5 mt-0.5 rounded text-teal-600 focus:ring-teal-500 border-slate-300" />
                           <label htmlFor="useCredit" className="text-sm text-slate-700">I intend to use credit management services (this requires proof of address and bank account).</label>
                        </div>
                        {useCredit && (
                            <div className="space-y-4 pt-4 border-t">
                             <div>
                                <label className="text-sm font-medium text-slate-700">Proof of Address</label>
                                <p className="text-xs text-slate-500 mb-1">e.g., Utility bill, lease agreement</p>
                                <label htmlFor="proofOfAddress" className="mt-1 w-full p-6 text-center border-2 border-dashed border-slate-300 rounded-lg cursor-pointer block hover:bg-slate-50">
                                  {proofOfAddress ? <p className="text-slate-700 font-medium">{proofOfAddress.name}</p> : <><UploadIcon className="h-8 w-8 mx-auto text-slate-400"/> <p className="text-sm text-slate-500 mt-2">Click to upload</p></>}
                                </label>
                                <input id="proofOfAddress" type="file" accept="image/*,application/pdf" onChange={handleFileChange(setProofOfAddress)} className="hidden" />
                              </div>
                               <div>
                                <label className="text-sm font-medium text-slate-700">Proof of Bank Account</label>
                                <p className="text-xs text-slate-500 mb-1">e.g., Bank statement</p>
                                <label htmlFor="proofOfBank" className="mt-1 w-full p-6 text-center border-2 border-dashed border-slate-300 rounded-lg cursor-pointer block hover:bg-slate-50">
                                  {proofOfBank ? <p className="text-slate-700 font-medium">{proofOfBank.name}</p> : <><UploadIcon className="h-8 w-8 mx-auto text-slate-400"/> <p className="text-sm text-slate-500 mt-2">Click to upload</p></>}
                                </label>
                                <input id="proofOfBank" type="file" accept="image/*,application/pdf" onChange={handleFileChange(setProofOfBank)} className="hidden" />
                              </div>
                            </div>
                        )}
                    </div>
                </div>
            );
        case 5:
            return (
                <div>
                    <h2 className="text-xl font-bold text-slate-800 text-center mb-4">Review and Submit</h2>
                    <p className="text-center text-slate-600 mb-6">Please review your information before submitting. Verification can take up to 24 hours.</p>
                    <div className="space-y-3 text-sm">
                        <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg"><span>Selfie</span><span className={`font-semibold ${selfie ? 'text-green-600' : 'text-red-600'}`}>{selfie ? '✓ Captured' : '✗ Missing'}</span></div>
                        <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg"><span>ID Document</span><span className={`font-semibold ${idPhoto && idNumber ? 'text-green-600' : 'text-red-600'}`}>{idPhoto && idNumber ? '✓ Provided' : '✗ Missing'}</span></div>
                        {useCredit && (
                             <>
                                <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg"><span>Proof of Address</span><span className={`font-semibold ${proofOfAddress ? 'text-green-600' : 'text-red-600'}`}>{proofOfAddress ? '✓ Provided' : '✗ Missing'}</span></div>
                                <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg"><span>Proof of Bank Account</span><span className={`font-semibold ${proofOfBank ? 'text-green-600' : 'text-red-600'}`}>{proofOfBank ? '✓ Provided' : '✗ Missing'}</span></div>
                             </>
                        )}
                    </div>
                </div>
            );
      default: return null;
    }
  };
  
  const isNextDisabled = () => {
    if (step === 2 && !selfie) return true;
    if (step === 3 && (!idNumber.trim() || !idPhoto)) return true;
    if (step === 4 && useCredit && (!proofOfAddress || !proofOfBank)) return true;
    if (step === 5) {
      if (!selfie || !idNumber.trim() || !idPhoto) return true;
      if (useCredit && (!proofOfAddress || !proofOfBank)) return true;
    }
    return false;
  };

  if (isLoading) {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <LoaderIcon className="h-12 w-12 text-teal-600 mx-auto" />
            <p className="mt-4 text-slate-600">{loadingMessage}</p>
        </div>
    );
  }

  return (
    <div className="w-full">
        <div className="mb-8">
          <ol className="flex items-center w-full">
            {steps.map((s, index) => (
              <li key={s.name} className={`flex w-full items-center ${index + 1 < steps.length ? "after:content-[''] after:w-full after:h-1 after:border-b after:border-4 after:inline-block " : ''} ${index < step ? 'text-teal-600 after:border-teal-100' : 'text-slate-500 after:border-slate-100'}`}>
                <span className={`flex items-center justify-center w-10 h-10 rounded-full lg:h-12 lg:w-12 shrink-0 ${index < step ? 'bg-teal-100' : 'bg-slate-100'}`}>
                  <span className="font-bold">{index+1}</span>
                </span>
              </li>
            ))}
          </ol>
        </div>
        
        {error && <p className="mb-4 text-center text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</p>}

        <div className="min-h-[400px] flex flex-col justify-center">
          {renderStepContent()}
        </div>

        <div className="mt-8 pt-6 border-t border-slate-200 flex flex-col-reverse sm:flex-row sm:justify-between sm:items-center gap-4">
          <button onClick={handleSkip} className="text-sm font-bold text-slate-500 hover:text-teal-600">Skip for now</button>
          <div className="flex gap-4">
            <button onClick={() => setStep(s => Math.max(1, s-1))} disabled={step === 1} className="px-6 py-2 font-bold text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200 disabled:opacity-50 disabled:cursor-not-allowed">Back</button>
            {step < 5 ? (
              <button onClick={() => setStep(s => s+1)} disabled={isNextDisabled()} className="px-6 py-2 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 disabled:cursor-not-allowed">Next</button>
            ) : (
              <button onClick={handleSubmit} disabled={isNextDisabled()} className="px-6 py-2 font-bold text-white bg-green-600 rounded-lg hover:bg-green-700 disabled:bg-slate-400 disabled:cursor-not-allowed">Submit for Verification</button>
            )}
          </div>
        </div>
    </div>
  );
};

export default KYC;