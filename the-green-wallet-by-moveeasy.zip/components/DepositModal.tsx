import React, { useState } from 'react';
import type { SavingsGoal, Project } from '../types';
import { addFundsToGoal } from '../services/api';
import { formatCurrency, Status } from '../types';
import StatusDisplay from './StatusDisplay';

interface DepositModalProps {
  goal: SavingsGoal;
  project?: Project;
  onClose: () => void;
  onSuccess: () => void;
}

const DepositModal: React.FC<DepositModalProps> = ({ goal, project, onClose, onSuccess }) => {
  const [amount, setAmount] = useState<number | ''>('');
  const [status, setStatus] = useState<Status>('idle');
  const [message, setMessage] = useState('');

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (amount === '' || amount <= 0) {
      setStatus('error');
      setMessage('Please enter a valid amount.');
      return;
    }
    setStatus('loading');
    setMessage('Processing your deposit...');
    try {
      await addFundsToGoal(goal.id, amount);
      setStatus('success');
      setMessage(`Successfully deposited ${formatCurrency(amount)}.`);
      setTimeout(onSuccess, 1500);
    } catch (err: any) {
      setStatus('error');
      setMessage(err.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center pb-4 border-b">
          <h3 className="text-lg font-bold text-slate-800">Add Funds to {project?.name}</h3>
          <button onClick={onClose} className="text-2xl font-light text-slate-500 hover:text-slate-800">&times;</button>
        </div>

        {status === 'idle' || status === 'error' ? (
          <form onSubmit={handleDeposit} className="mt-4 space-y-4">
            <div>
              <label htmlFor="amount" className="text-sm font-medium text-slate-700">Deposit Amount</label>
              <input
                id="amount"
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0.00"
                required
                className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg"
              />
            </div>
            {status === 'error' && <p className="text-sm text-red-600 text-center">{message}</p>}
            <button type="submit" className="w-full py-3 font-bold text-white bg-teal-600 rounded-lg">
              Confirm Deposit
            </button>
          </form>
        ) : (
          <div className="mt-4">
            <StatusDisplay status={status} message={message} />
          </div>
        )}
      </div>
    </div>
  );
};

export default DepositModal;