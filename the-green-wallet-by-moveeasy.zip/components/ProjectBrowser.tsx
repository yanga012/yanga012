import React from 'react';
import type { Project } from '../types';
import ProjectCard from './ProjectCard';
import LoaderIcon from './icons/LoaderIcon';

interface ProjectBrowserProps {
  projects: Project[];
  isLoading: boolean;
  onStartGoal: (projectId: string) => void;
}

const ProjectBrowser: React.FC<ProjectBrowserProps> = ({ projects, isLoading, onStartGoal }) => {
  return (
    <div>
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800">Our Projects</h2>
        <p className="text-md text-slate-500 mt-2">Select a project to start saving. Sponsored by our finance partners.</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center p-10"><LoaderIcon className="h-10 w-10 text-teal-500" /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map(project => (
            <ProjectCard key={project.id} project={project} onStartGoal={onStartGoal} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProjectBrowser;