import React from 'react';
import HomeIcon from './icons/HomeIcon';
import LeafIcon from './icons/LeafIcon';
import TargetIcon from './icons/TargetIcon';
import UserIcon from './icons/UserIcon';

export type View = 'home' | 'projects' | 'goals' | 'profile';

interface BottomNavBarProps {
  currentView: View;
  setView: (view: View) => void;
}

interface NavItemProps {
  label: string;
  targetView: View;
  currentView: View;
  setView: (view: View) => void;
  icon: React.ReactElement<{ className?: string }>;
}

const NavItem: React.FC<NavItemProps> = ({ label, targetView, currentView, setView, icon }) => {
  const isActive = currentView === targetView;
  const activeClasses = 'text-teal-600';
  const inactiveClasses = 'text-slate-500 hover:text-teal-600';

  return (
    <button
      onClick={() => setView(targetView)}
      className={`flex flex-col items-center justify-center gap-1 w-full transition-colors duration-200 ${isActive ? activeClasses : inactiveClasses}`}
      aria-current={isActive ? 'page' : undefined}
    >
      {React.cloneElement(icon, { className: 'h-6 w-6' })}
      <span className="text-xs font-bold">{label}</span>
    </button>
  );
};

const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentView, setView }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-lg border-t border-slate-200 z-10">
      <div className="max-w-3xl mx-auto h-full flex items-center justify-around">
        <NavItem 
          label="Home" 
          targetView="home" 
          currentView={currentView} 
          setView={setView} 
          icon={<HomeIcon />} 
        />
        <NavItem 
          label="Projects" 
          targetView="projects" 
          currentView={currentView} 
          setView={setView} 
          icon={<LeafIcon />}
        />
        <NavItem 
          label="My Goals" 
          targetView="goals" 
          currentView={currentView} 
          setView={setView} 
          icon={<TargetIcon />} 
        />
        <NavItem 
          label="Profile" 
          targetView="profile" 
          currentView={currentView} 
          setView={setView} 
          icon={<UserIcon />} 
        />
      </div>
    </nav>
  );
};

export default BottomNavBar;