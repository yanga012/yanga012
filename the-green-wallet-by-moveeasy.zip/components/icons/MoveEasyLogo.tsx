import React from 'react';

const MoveEasyLogo: React.FC<{ className?: string }> = ({ className }) => (
  <div className={`p-1.5 bg-teal-100 rounded-lg flex items-center justify-center ${className}`}>
    <svg 
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="text-teal-600 h-full w-full"
    >
        <path d="M11 20A7 7 0 0 1 4 13V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        <path d="M15.5 8.5c.3-1 .5-2.2.5-3.5a2 2 0 0 0-2-2h-1" />
        <path d="M12 22s-4-2-4-8" />
    </svg>
  </div>
);

export default MoveEasyLogo;