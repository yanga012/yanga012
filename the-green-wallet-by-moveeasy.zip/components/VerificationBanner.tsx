import React from 'react';

interface VerificationBannerProps {
  onStartVerification: () => void;
}

const VerificationBanner: React.FC<VerificationBannerProps> = ({ onStartVerification }) => (
  <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-4 rounded-lg shadow mb-6" role="alert">
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div>
        <p className="font-bold">Account Verification Incomplete</p>
        <p className="text-sm">Complete your identity verification to unlock all features and secure your account.</p>
      </div>
      <button 
        onClick={onStartVerification} 
        className="px-4 py-2 bg-yellow-500 text-white font-bold rounded-lg hover:bg-yellow-600 whitespace-nowrap self-start sm:self-center"
      >
        Verify Now
      </button>
    </div>
  </div>
);

export default VerificationBanner;