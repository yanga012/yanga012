import React from 'react';
import type { Project } from '../types';
import { formatCurrency } from '../types';

interface ProjectCardProps {
  project: Project;
  onStartGoal: (projectId: string) => void;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onStartGoal }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col">
      <img src={project.imageUrl} alt={project.name} className="w-full h-48 object-cover" />
      <div className="p-4 flex flex-col flex-grow">
        <span className="text-xs font-semibold text-teal-600 bg-teal-100 px-2 py-1 rounded-full self-start">{project.category}</span>
        <h3 className="text-lg font-bold text-slate-800 mt-2">{project.name}</h3>
        <p className="text-sm text-slate-500 mt-1 flex-grow">{project.description}</p>
        <p className="text-sm text-slate-400 mt-2">Supplier: {project.supplier}</p>
        <div className="mt-4 pt-4 border-t border-slate-100">
            <p className="text-xs text-slate-500">Total Project Cost</p>
            <p className="text-2xl font-extrabold text-slate-900">{formatCurrency(project.totalCost)}</p>
        </div>
        <button 
          onClick={() => onStartGoal(project.id)}
          className="w-full mt-4 px-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
        >
          Start Saving For This
        </button>
      </div>
    </div>
  );
};

export default ProjectCard;