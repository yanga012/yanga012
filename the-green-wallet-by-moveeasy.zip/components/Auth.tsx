import React, { useState } from 'react';
import { signIn, signUp, verifyEmail } from '../services/api';
import type { User } from '../types';
import MoveEasyLogo from './icons/MoveEasyLogo';
import LoaderIcon from './icons/LoaderIcon';

interface AuthProps {
  onAuthSuccess: (user: User) => void;
}

type Mode = 'signin' | 'signup' | 'verify-email';

const Auth: React.FC<AuthProps> = ({ onAuthSuccess }) => {
  const [mode, setMode] = useState<Mode>('signin');
  
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setLoading(true);

    try {
      const user = await signIn(email, password);
      onAuthSuccess(user);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setLoading(true);
    try {
      await signUp(email, phone, password);
      setSuccessMessage(`A verification code has been sent to your console for ${email}.`);
      setMode('verify-email');
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  }

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage(null);
    setLoading(true);
    try {
      await verifyEmail(email, code);
      setSuccessMessage('Email verified successfully! You can now sign in.');
      setMode('signin');
      setPassword('');
      setCode('');
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (newMode: Mode) => {
    setMode(newMode);
    setError(null);
    setSuccessMessage(null);
    setEmail('');
    setPassword('');
    setPhone('');
    setCode('');
  }

  const renderContent = () => {
    switch (mode) {
      case 'signup':
        return (
          <>
            <p className="text-sm text-slate-500 mt-2">Create an account to start your green journey.</p>
            <form onSubmit={handleSignUp} className="flex flex-col gap-4 mt-8">
              <div>
                <label htmlFor="email" className="text-sm font-medium text-slate-700">Email Address</label>
                <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={loading} />
              </div>
              <div>
                <label htmlFor="phone" className="text-sm font-medium text-slate-700">Phone Number</label>
                <input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="0821234567" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={loading} />
              </div>
               <div>
                <label htmlFor="password"  className="text-sm font-medium text-slate-700">Password</label>
                <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={loading} />
              </div>
              <button type="submit" className="w-full mt-2 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 flex items-center justify-center" disabled={loading}>
                {loading ? <LoaderIcon className="h-6 w-6" /> : 'Create Account'}
              </button>
            </form>
            <p className="text-center text-sm text-slate-600 mt-6">
              Already have an account? <button onClick={() => switchMode('signin')} className="font-bold text-teal-600 hover:underline">Sign In</button>
            </p>
          </>
        );
      case 'verify-email':
        return (
          <>
            <p className="text-sm text-slate-500 mt-2">Enter the verification code sent to your console.</p>
            <form onSubmit={handleVerifyEmail} className="flex flex-col gap-4 mt-8">
              <div>
                <label htmlFor="code" className="text-sm font-medium text-slate-700">Verification Code</label>
                <input id="code" type="text" value={code} onChange={(e) => setCode(e.target.value)} placeholder="123456" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={loading} />
              </div>
              <button type="submit" className="w-full mt-2 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 flex items-center justify-center" disabled={loading}>
                {loading ? <LoaderIcon className="h-6 w-6" /> : 'Verify Email'}
              </button>
            </form>
          </>
        );
      case 'signin':
      default:
        return (
          <>
            <p className="text-sm text-slate-500 mt-2">Sign in to start saving for your green future</p>
            <form onSubmit={handleSignIn} className="flex flex-col gap-4 mt-8">
              <div>
                <label htmlFor="email" className="text-sm font-medium text-slate-700">Email Address</label>
                <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={loading}/>
              </div>
               <div>
                <label htmlFor="password"  className="text-sm font-medium text-slate-700">Password</label>
                <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={loading} />
              </div>
              <button type="submit" className="w-full mt-2 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 flex items-center justify-center" disabled={loading}>
                {loading ? <LoaderIcon className="h-6 w-6" /> : 'Sign In'}
              </button>
            </form>
            <p className="text-center text-sm text-slate-600 mt-6">
              Don't have an account? <button onClick={() => switchMode('signup')} className="font-bold text-teal-600 hover:underline">Sign Up</button>
            </p>
          </>
        );
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-slate-50">
      <main className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-sm w-full">
        <header className="flex flex-col items-center text-center pb-6 border-b border-slate-200">
          <MoveEasyLogo className="h-10 w-10 mb-3" />
          <h1 className="text-2xl font-bold text-slate-800">
            The Green Wallet
            <span className="block text-sm font-semibold text-slate-500 mt-1">by MoveEasy</span>
          </h1>
        </header>
        <div className="mt-4">
          {error && <p className="mb-4 text-center text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</p>}
          {successMessage && <p className="mb-4 text-center text-sm text-green-600 bg-green-50 p-3 rounded-lg">{successMessage}</p>}
          {renderContent()}
          {mode === 'signin' && (
             <div className="mt-4 p-3 bg-slate-50 rounded-lg text-xs text-slate-500 text-center">
              <p className="font-semibold text-slate-600">Testing Credentials</p>
              <p><span className="font-medium">Email:</span> green@moveeasy.app</p>
              <p><span className="font-medium">Phone:</span> 0821234567</p>
              <p><span className="font-medium">Password:</span> any password</p>
              <p className="mt-1 text-teal-700">Follow the full sign-up and verification flow!</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Auth;