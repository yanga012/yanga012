import React from 'react';
import LoaderIcon from './icons/LoaderIcon';
import { Status } from '../types';

interface StatusDisplayProps {
  status: Status;
  message: string;
}

const SuccessIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22 4 12 14.01 9 11.01" />
  </svg>
);

const ErrorIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="8" x2="12" y2="12" />
    <line x1="12" y1="16" x2="12.01" y2="16" />
  </svg>
);

const StatusDisplay: React.FC<StatusDisplayProps> = ({ status, message }) => {
  const renderIcon = () => {
    switch (status) {
      case 'loading':
        return <LoaderIcon className="h-12 w-12 text-teal-500" />;
      case 'success':
        return <SuccessIcon className="h-12 w-12 text-green-500" />;
      case 'error':
        return <ErrorIcon className="h-12 w-12 text-red-500" />;
      default:
        return null;
    }
  };

  const textColor = {
    loading: 'text-slate-600',
    success: 'text-green-600',
    error: 'text-red-600',
    idle: 'text-slate-500',
  }[status];

  return (
    <div className="flex flex-col items-center justify-center text-center p-8 space-y-4">
      {renderIcon()}
      <p className={`text-lg font-semibold ${textColor}`}>{message}</p>
    </div>
  );
};

export default StatusDisplay;