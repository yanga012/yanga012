// Defines the core data structures used throughout the application.

export interface User {
  id: string;
  email: string;
  phone: string;
  isEmailVerified: boolean;
  isPhoneVerified: boolean;
  isVerified: boolean; // KYC verified
  kycSkipped?: boolean;
  businessName?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  totalCost: number;
  category: 'Residential' | 'Commercial' | 'Community';
  imageUrl: string;
  supplier: string;
}

export interface SavingsGoal {
  id: string;
  projectId: string;
  userId: string;
  savedAmount: number;
  status: 'saving' | 'unlocked' | 'installation_in_progress' | 'complete';
  isNew?: boolean;
}

export interface Transaction {
  id: string;
  goalId: string;
  type: 'deposit';
  amount: number;
  date: string; // ISO string format
}

export type Status = 'idle' | 'loading' | 'success' | 'error';
 
/**
 * Formats a number as a string with a "R" prefix, thousand separators, and two decimal places.
 * e.g., 1234.5 becomes "R1,234.50"
 * @param amount - The number to format.
 * @returns A string representing the formatted currency.
 */
export const formatCurrency = (amount: number): string => {
  // Use en-US locale for comma separators for thousands and dot for decimal.
  const formattedAmount = amount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `R${formattedAmount}`;
};