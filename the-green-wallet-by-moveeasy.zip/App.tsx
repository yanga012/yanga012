import React, { useState, useEffect, useCallback } from 'react';
import type { User } from './types';
import { getSession, resetKYCSkip } from './services/api';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import OnboardingGate from './components/OnboardingGate';
import LoaderIcon from './components/icons/LoaderIcon';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loadingSession, setLoadingSession] = useState(true);

  const checkSession = useCallback(async () => {
    try {
      const sessionUser = await getSession();
      setUser(sessionUser);
    } catch (error) {
      console.error("An unexpected error occurred while checking session:", error);
      setUser(null);
    } finally {
      setLoadingSession(false);
    }
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  const handleStartVerification = async () => {
    if (!user) return;
    setLoadingSession(true);
    await resetKYCSkip(user.id);
    await checkSession();
    setLoadingSession(false);
  }

  if (loadingSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <LoaderIcon className="h-12 w-12 text-teal-600" />
      </div>
    );
  }

  if (!user) {
    return <Auth onAuthSuccess={setUser} />;
  }
  
  // After login, guide user through onboarding steps if not complete
  if (!user.isPhoneVerified || (!user.isVerified && !user.kycSkipped)) {
    return <OnboardingGate user={user} onOnboardingComplete={checkSession} />;
  }
  
  return <Dashboard user={user} onLogout={() => setUser(null)} onStartVerification={handleStartVerification} />;
};

export default App;