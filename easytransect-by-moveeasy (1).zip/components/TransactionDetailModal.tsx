import React from 'react';
import type { Transaction } from '../types';
import { formatCurrency } from '../types';

interface TransactionDetailModalProps {
  transaction: Transaction;
  onClose: () => void;
}

const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({ transaction, onClose }) => {
  const isRedeem = transaction.type === 'redeem';
  const amountColor = isRedeem ? 'text-green-600' : 'text-red-600';
  const sign = isRedeem ? '+' : '-';

  return (
    <div
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fadeIn"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6"
        onClick={(e) => e.stopPropagation()} // Prevent closing modal when clicking inside
      >
        <div className="flex justify-between items-center pb-4 border-b border-slate-200">
          <h3 className="text-lg font-bold text-slate-800">Transaction Details</h3>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-800"
            aria-label="Close modal"
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="mt-6 space-y-4">
          <div>
            <p className="text-xs text-slate-500">Amount</p>
            <p className={`text-3xl font-bold ${amountColor}`}>{sign}{formatCurrency(transaction.amount)}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Description</p>
            <p className="text-base font-semibold text-slate-700">{transaction.description}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Date & Time</p>
            <p className="text-base text-slate-700">
              {new Date(transaction.date).toLocaleString('en-ZA', {
                dateStyle: 'full',
                timeStyle: 'medium',
              })}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Transaction ID</p>
            <p className="text-sm font-mono text-slate-500 break-all">{transaction.id}</p>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-200">
          <button
            onClick={onClose}
            className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 focus:outline-none focus:ring-4 focus:ring-teal-300"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default TransactionDetailModal;
