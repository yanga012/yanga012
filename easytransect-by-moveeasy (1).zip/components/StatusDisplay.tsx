
import React from 'react';
// Fix: Corrected import path for types.
import type { Status } from '../types';
import { formatCurrency } from '../types';
import LoaderIcon from './icons/LoaderIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import XCircleIcon from './icons/XCircleIcon';

interface StatusDisplayProps {
  status: Status;
  message: string;
  voucherValue?: number;
  valueLabel?: string;
}

const StatusDisplay: React.FC<StatusDisplayProps> = ({ status, message, voucherValue, valueLabel }) => {
  if (status === 'idle') return null;

  const statusConfig = {
    loading: {
      icon: <LoaderIcon className="h-6 w-6 text-teal-500" />,
      textClass: 'text-slate-600',
      bgClass: 'bg-teal-50',
    },
    success: {
      icon: <CheckCircleIcon className="h-6 w-6 text-green-500" />,
      textClass: 'text-green-800',
      bgClass: 'bg-green-100',
    },
    error: {
      icon: <XCircleIcon className="h-6 w-6 text-red-500" />,
      textClass: 'text-red-800',
      bgClass: 'bg-red-100',
    },
  };

  const config = statusConfig[status];
  if (!config) return null;

  return (
    <div className={`mt-6 p-4 rounded-lg flex flex-col items-center justify-center gap-3 transition-all duration-300 ${config.bgClass}`}>
      <div className="flex items-center gap-3">
        {config.icon}
        <p className={`text-sm font-medium ${config.textClass}`}>{message}</p>
      </div>
      {status === 'success' && voucherValue && voucherValue > 0 && (
         <div className="text-center bg-white/60 p-3 rounded-md w-full">
            <p className="text-xs text-slate-500">{valueLabel || 'REDEEMED VALUE'}</p>
            <p className="text-xl font-bold text-slate-800">{formatCurrency(voucherValue)}</p>
        </div>
      )}
    </div>
  );
};

export default StatusDisplay;