import React from 'react';
import MoveEasyLogo from './icons/MoveEasyLogo';
import UserIcon from './icons/UserIcon';
import BuildingStorefrontIcon from './icons/BuildingStorefrontIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';

interface RoleSelectionProps {
  onSelectRole: (role: 'user' | 'merchant') => void;
}

const RoleSelection: React.FC<RoleSelectionProps> = ({ onSelectRole }) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <header className="text-center mb-8">
        <MoveEasyLogo className="h-12 w-12 text-teal-600 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-slate-800">Welcome to MoveEasy</h1>
        <p className="text-md text-slate-500 mt-2">Please select your portal to get started.</p>
      </header>
      <main className="w-full max-w-4xl grid md:grid-cols-2 gap-6">
        {/* User Card */}
        <div className="bg-white rounded-2xl shadow-lg p-6 flex flex-col items-center text-center border-2 border-transparent hover:border-teal-500 transition-all duration-300">
          <UserIcon className="h-10 w-10 text-teal-600 mb-4" />
          <h2 className="text-2xl font-bold text-slate-800">For Individuals</h2>
          <p className="text-sm text-slate-600 mt-2 mb-6 flex-grow">
            Redeem digital vouchers and consolidate funds from various mobile money services into a single, easy-to-manage wallet.
          </p>
          <button
            onClick={() => onSelectRole('user')}
            className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
          >
            Enter Personal Portal
          </button>
        </div>

        {/* Merchant Card */}
        <div className="bg-white rounded-2xl shadow-lg p-6 flex flex-col border-2 border-transparent hover:border-teal-500 transition-all duration-300">
          <BuildingStorefrontIcon className="h-10 w-10 text-teal-600 mb-4 self-center" />
          <div className="text-center">
             <h2 className="text-2xl font-bold text-slate-800">For Businesses</h2>
             <p className="text-sm text-teal-600 font-semibold mt-1">The Easiest Way to Accept Digital Vouchers</p>
          </div>
         
          <div className="text-left my-6 text-sm text-slate-600 flex-grow">
            <p className="mb-4">Equip your business to serve the growing MoveEasy ecosystem. Redeem digital vouchers for fuel, goods, and services with a simple scan.</p>
            
            <h3 className="font-bold text-slate-700 mb-2">Who is it for?</h3>
            <p className="text-xs mb-3">Fuel Stations, Supermarkets, Retail Shops, Service Providers.</p>

            <h3 className="font-bold text-slate-700 mb-2">Benefits:</h3>
            <ul className="space-y-1.5 text-xs">
              <li className="flex items-start gap-2"><CheckCircleIcon className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" /> Attract More Customers: Tap into the network of MoveEasy users.</li>
              <li className="flex items-start gap-2"><CheckCircleIcon className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" /> Faster Checkouts: Scanning a QR code is quicker than cash or cards.</li>
              <li className="flex items-start gap-2"><CheckCircleIcon className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" /> Secure Transactions: Drastically reduces the risk of fraud.</li>
              <li className="flex items-start gap-2"><CheckCircleIcon className="h-4 w-4 text-green-500 flex-shrink-0 mt-0.5" /> Simple Reconciliation: All transactions logged for easy accounting.</li>
            </ul>
          </div>

          <button
            onClick={() => onSelectRole('merchant')}
            className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 mt-auto"
          >
            Enter Merchant Portal
          </button>
        </div>
      </main>
    </div>
  );
};

export default RoleSelection;
