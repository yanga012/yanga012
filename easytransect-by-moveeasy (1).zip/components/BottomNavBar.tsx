import React from 'react';
import HomeIcon from './icons/HomeIcon';
import WalletIcon from './icons/WalletIcon';
import ListIcon from './icons/ListIcon';
import UserIcon from './icons/UserIcon';
import LockClosedIcon from './icons/LockClosedIcon';

export type View = 'home' | 'cash-out' | 'activity' | 'profile';

interface BottomNavBarProps {
  currentView: View;
  setView: (view: View) => void;
  isVerified: boolean;
}

interface NavItemProps {
  label: string;
  targetView: View;
  currentView: View;
  setView: (view: View) => void;
  // Fix: The type for 'icon' has been made more specific to include `className` in its props. This resolves the overload error on React.cloneElement.
  icon: React.ReactElement<{ className?: string }>;
  isLocked?: boolean;
}

const NavItem: React.FC<NavItemProps> = ({ label, targetView, currentView, setView, icon, isLocked = false }) => {
  const isActive = currentView === targetView;
  const activeClasses = 'text-teal-600';
  const inactiveClasses = 'text-slate-500 hover:text-teal-600';
  
  const handlePress = () => {
    if (isLocked) {
        // If the feature is locked, redirect to the profile page for verification
        setView('profile');
    } else {
        setView(targetView);
    }
  }

  return (
    <button
      onClick={handlePress}
      className={`flex flex-col items-center justify-center gap-1 w-full transition-colors duration-200 relative ${isActive ? activeClasses : inactiveClasses}`}
      aria-current={isActive ? 'page' : undefined}
    >
      {isLocked && <LockClosedIcon className="absolute -top-1 right-[20%] h-3 w-3 p-0.5 bg-orange-400 text-white rounded-full" />}
      {/* Fix: With the corrected prop type, the type assertion is no longer needed. This resolves the overload error. */}
      {React.cloneElement(icon, { className: 'h-6 w-6' })}
      <span className="text-xs font-bold">{label}</span>
    </button>
  );
};

const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentView, setView, isVerified }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-lg border-t border-slate-200 z-10">
      <div className="max-w-3xl mx-auto h-full flex items-center justify-around">
        <NavItem 
          label="Home" 
          targetView="home" 
          currentView={currentView} 
          setView={setView} 
          icon={<HomeIcon />} 
        />
        <NavItem 
          label="Cash Out" 
          targetView="cash-out" 
          currentView={currentView} 
          setView={setView} 
          icon={<WalletIcon />} 
          isLocked={!isVerified}
        />
        <NavItem 
          label="Activity" 
          targetView="activity" 
          currentView={currentView} 
          setView={setView} 
          icon={<ListIcon />} 
        />
        <NavItem 
          label="Profile" 
          targetView="profile" 
          currentView={currentView} 
          setView={setView} 
          icon={<UserIcon />} 
        />
      </div>
    </nav>
  );
};

export default BottomNavBar;