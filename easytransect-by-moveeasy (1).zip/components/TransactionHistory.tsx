// Created the TransactionHistory component to display a list of transactions.
import React, { useState } from 'react';
import type { Transaction } from '../types';
import { formatCurrency } from '../types';
import TransactionDetailModal from './TransactionDetailModal';
import PlusCircleIcon from './icons/PlusCircleIcon';
import MinusCircleIcon from './icons/MinusCircleIcon';
import TransactionHistorySkeleton from './skeletons/TransactionHistorySkeleton';

interface TransactionItemProps {
    transaction: Transaction & { isNew?: boolean };
    onClick: () => void;
}

interface TransactionHistoryProps {
  transactions: Transaction[];
  embedded?: boolean;
  isLoading?: boolean;
}

const TransactionItem: React.FC<TransactionItemProps> = ({ transaction, onClick }) => {
  const isRedeem = transaction.type === 'redeem';
  const amountColor = isRedeem ? 'text-green-600' : 'text-red-600';
  const sign = isRedeem ? '+' : '-';
  const isNew = (transaction as any).isNew;

  return (
    <li className={`${isNew ? 'transaction-new' : ''}`}>
        <button 
            onClick={onClick}
            className="w-full flex items-center justify-between py-4 border-b border-slate-100 last:border-b-0 text-left hover:bg-slate-50 transition-colors duration-200 rounded-md px-2 -mx-2"
            aria-label={`View details for transaction: ${transaction.description}`}
        >
          <div className="flex items-center gap-4">
            {isRedeem ? (
                <PlusCircleIcon className="h-6 w-6 text-green-600 flex-shrink-0" />
            ) : (
                <MinusCircleIcon className="h-6 w-6 text-red-600 flex-shrink-0" />
            )}
            <div>
              <p className="font-semibold text-slate-800">{transaction.description}</p>
              <p className="text-sm text-slate-500">
                {new Date(transaction.date).toLocaleString('en-ZA', {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                })}
              </p>
            </div>
          </div>
          <p className={`text-lg font-bold ${amountColor}`}>
            {sign}{formatCurrency(transaction.amount)}
          </p>
        </button>
    </li>
  );
};

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ transactions, embedded = false, isLoading = false }) => {
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  if (isLoading) {
    return <TransactionHistorySkeleton count={embedded ? 3 : 5} />;
  }

  const historyContent = (
    transactions.length > 0 ? (
      <ul className={!embedded ? "mt-4" : ""}>
        {transactions.map(t => (
          <TransactionItem key={t.id} transaction={t} onClick={() => setSelectedTransaction(t)} />
        ))}
      </ul>
    ) : (
      <div className={`flex items-center justify-center h-32 bg-slate-50 rounded-lg ${!embedded ? 'mt-4' : ''}`}>
          <p className="text-sm text-slate-500">No transactions yet.</p>
      </div>
    )
  );
  
  const mainContent = (
    <>
      {historyContent}
      {selectedTransaction && (
        <TransactionDetailModal 
            transaction={selectedTransaction} 
            onClose={() => setSelectedTransaction(null)} 
        />
      )}
    </>
  );

  if (embedded) {
    return mainContent;
  }

  return (
    <div className="mt-8 bg-white p-6 rounded-2xl shadow-lg">
      <h3 className="text-xl font-bold text-slate-800">Transaction History</h3>
      {mainContent}
    </div>
  );
};

export default TransactionHistory;
