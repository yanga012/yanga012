import React, { useState, useEffect, useCallback } from 'react';
import type { User, Transaction } from '../types';
import { formatCurrency } from '../types';
import { getTransactions, performIdentityVerification } from '../services/api';
import MoveEasyLogo from './icons/MoveEasyLogo';
import Activity from './Activity';
import EyeIcon from './icons/EyeIcon';
import EyeSlashIcon from './icons/EyeSlashIcon';
import ShieldCheckIcon from './icons/ShieldCheckIcon';
import VerificationFlow from './VerificationFlow';
import CashInFlow from './CashInFlow';
import MerchantCashOutFlow from './MerchantCashOutFlow';

// Nav Bar Imports
import HomeIcon from './icons/HomeIcon';
import ListIcon from './icons/ListIcon';
import UserIcon from './icons/UserIcon';
import ArrowDownIcon from './icons/ArrowDownIcon';
import ArrowUpIcon from './icons/ArrowUpIcon';


type MerchantView = 'home' | 'activity' | 'profile';

interface MerchantDashboardProps {
  user: User;
  onLogout: () => void;
}

interface NavItemProps {
  label: string;
  targetView: MerchantView;
  currentView: MerchantView;
  setView: (view: MerchantView) => void;
  icon: React.ReactElement<{ className?: string }>;
}

const NavItem: React.FC<NavItemProps> = ({ label, targetView, currentView, setView, icon }) => {
  const isActive = currentView === targetView;
  const activeClasses = 'text-teal-600';
  const inactiveClasses = 'text-slate-500 hover:text-teal-600';
  
  const handlePress = () => {
    setView(targetView);
  }

  return (
    <button
      onClick={handlePress}
      className={`flex flex-col items-center justify-center gap-1 w-full transition-colors duration-200 relative ${isActive ? activeClasses : inactiveClasses}`}
      aria-current={isActive ? 'page' : undefined}
    >
      {React.cloneElement(icon, { className: 'h-6 w-6' })}
      <span className="text-xs font-bold">{label}</span>
    </button>
  );
};


const MerchantDashboard: React.FC<MerchantDashboardProps> = ({ user: initialUser, onLogout }) => {
  const [user, setUser] = useState<User>(initialUser);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<MerchantView>('home');
  const [showBalance, setShowBalance] = useState(true);
  const [showVerificationFlow, setShowVerificationFlow] = useState(!user.isVerified);
  const [serviceMode, setServiceMode] = useState<'none' | 'cash-in' | 'cash-out'>('none');

  const fetchTransactions = useCallback(async () => {
    try {
      setLoading(true);
      const userTransactions = await getTransactions(user.id);
      setTransactions(userTransactions);
    } catch (error) {
      console.error("Failed to fetch transactions:", error);
    } finally {
      setLoading(false);
    }
  }, [user.id]);

  useEffect(() => {
    if (user.isVerified) {
      fetchTransactions();
    }
  }, [user.isVerified, fetchTransactions]);

  const handleTransactionSuccess = (newTransaction: Transaction) => {
    setTransactions(prev => [{ ...newTransaction, isNew: true }, ...prev]);
    
    // Merchant balance always increases as they are taking a commission or float
    const newBalance = user.balance + newTransaction.amount;
    setUser(currentUser => ({...currentUser, balance: newBalance }));
    
    // Go to activity to show the new transaction, and reset the service mode
    setView('activity');
    setServiceMode('none');

    if (Notification.permission === 'granted') {
      const title = 'Service Complete';
      const body = `Amount: ${formatCurrency(newTransaction.amount)}\nDescription: ${newTransaction.description}`;
      new Notification(title, { body });
    }
  };

  const handleVerificationSuccess = async () => {
    try {
      await performIdentityVerification(user.id);
      setUser(currentUser => ({...currentUser, isVerified: true}));
      setShowVerificationFlow(false);
    } catch (error) {
      console.error("Identity verification failed", error);
    }
  };
  
  useEffect(() => {
    // If user navigates away from home, reset the service mode
    if(view !== 'home') {
        setServiceMode('none');
    }
  }, [view]);

  if (showVerificationFlow) {
    return <VerificationFlow onVerified={handleVerificationSuccess} onSkip={() => setShowVerificationFlow(false)} />;
  }

  const renderHomeView = () => {
    if (serviceMode === 'cash-in') {
      return (
        <div className="bg-white p-6 rounded-2xl shadow-lg">
            <button onClick={() => setServiceMode('none')} className="mb-4 text-sm font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
                Back to Services
            </button>
           <CashInFlow 
             onRedeemSuccess={handleTransactionSuccess} 
             successMessage="Voucher redeemed! Pay customer cash."
           />
        </div>
      );
    }

    if (serviceMode === 'cash-out') {
      return (
        <MerchantCashOutFlow 
            user={user} 
            onPaymentSuccess={handleTransactionSuccess} 
            onBack={() => setServiceMode('none')} 
        />
      );
    }

    // serviceMode === 'none'
    return (
        <>
        <div className="bg-white p-6 rounded-2xl shadow-lg mb-6">
            <div className="flex justify-between items-center">
                <div>
                    <p className="text-sm text-slate-500">Merchant Wallet</p>
                    <div className="flex items-center gap-2">
                        <p className="text-3xl font-bold text-slate-800">
                            {showBalance ? formatCurrency(user.balance) : 'R ••••••'}
                        </p>
                        <button onClick={() => setShowBalance(!showBalance)} className="text-slate-500 hover:text-slate-800" aria-label={showBalance ? 'Hide balance' : 'Show balance'}>
                            {showBalance ? <EyeSlashIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                        </button>
                    </div>
                    <p className="text-sm text-slate-500 mt-1">{user.businessName}</p>
                </div>
            </div>
            <div className="mt-6 text-center">
                <h3 className="text-lg font-bold text-slate-800">Cash Exchange Services</h3>
                <p className="text-sm text-slate-500 mt-1 mb-6">Select a service to perform for the customer.</p>

                <div className="grid sm:grid-cols-2 gap-4">
                    <button 
                        onClick={() => setServiceMode('cash-in')}
                        className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-all duration-200 flex flex-col items-center justify-center text-center h-36"
                        disabled={!user.isVerified}
                    >
                        <ArrowDownIcon className="h-8 w-8 text-green-600 mb-2"/>
                        <p className="font-semibold text-slate-700">Customer Cash In</p>
                        <p className="text-xs text-slate-500">Exchange voucher for cash.</p>
                    </button>
                    <button 
                        onClick={() => setServiceMode('cash-out')}
                        className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-all duration-200 flex flex-col items-center justify-center text-center h-36"
                        disabled={!user.isVerified}
                    >
                        <ArrowUpIcon className="h-8 w-8 text-red-600 mb-2"/>
                        <p className="font-semibold text-slate-700">Customer Cash Out</p>
                        <p className="text-xs text-slate-500">Exchange wallet balance for cash.</p>
                    </button>
                </div>
                 {!user.isVerified && <p className="text-xs text-orange-600 mt-4">Please verify your account to provide services.</p>}
            </div>
        </div>
        
        <div className="mt-4">
            <h3 className="text-lg font-bold text-slate-800 mb-2">Recent Activity</h3>
            <div className="bg-white p-4 rounded-2xl shadow-lg">
                <Activity transactions={transactions.slice(0, 3)} isLoading={loading} isPreview={true} />
            </div>
        </div>
        </>
    );
  };

  const renderProfileView = () => (
    <div className="space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-lg text-center">
            <h3 className="text-xl font-bold text-slate-800">{user.businessName}</h3>
            <p className="text-md text-slate-500">{user.email}</p>
            <p className={`mt-2 text-sm font-semibold flex items-center justify-center gap-2 ${user.isVerified ? 'text-green-600' : 'text-orange-600'}`}>
                {user.isVerified ? <ShieldCheckIcon className="h-5 w-5"/> : null}
                {user.isVerified ? 'Verified Merchant' : 'Verification Required'}
            </p>
            {!user.isVerified && (
              <button 
                onClick={() => setShowVerificationFlow(true)}
                className="w-full mt-4 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
              >
                Verify Your Business
              </button>
            )}
        </div>
        <button 
            onClick={onLogout} 
            className="w-full mt-4 px-4 py-3 text-base font-bold text-red-600 bg-red-50 rounded-lg hover:bg-red-100"
        >
            Logout
        </button>
    </div>
  );

  const renderView = () => {
    switch (view) {
      case 'activity':
        return <Activity transactions={transactions} isLoading={loading} />;
      case 'profile':
        return renderProfileView();
      case 'home':
      default:
        return renderHomeView();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white/80 backdrop-blur-lg sticky top-0 z-10 p-4 border-b border-slate-200">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <MoveEasyLogo className="h-8 w-8 text-teal-600" />
            <h1 className="text-xl font-bold text-slate-800">MoveEasy Merchant</h1>
          </div>
          <p className="text-sm font-semibold text-slate-600 hidden sm:block">
            {user.businessName}
          </p>
        </div>
      </header>
      
      <main className="flex-grow max-w-3xl w-full mx-auto p-4 sm:p-6 pb-24">
        {renderView()}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-lg border-t border-slate-200 z-10">
        <div className="max-w-3xl mx-auto h-full flex items-center justify-around">
            <NavItem label="Home" targetView="home" currentView={view} setView={setView} icon={<HomeIcon />} />
            <NavItem label="Activity" targetView="activity" currentView={view} setView={setView} icon={<ListIcon />} />
            <NavItem label="Profile" targetView="profile" currentView={view} setView={setView} icon={<UserIcon />} />
        </div>
      </nav>
    </div>
  );
};

export default MerchantDashboard;