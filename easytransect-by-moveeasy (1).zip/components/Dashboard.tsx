


import React, { useState, useEffect, useCallback } from 'react';
import type { User, Transaction } from '../types';
import { formatCurrency } from '../types';
import { getTransactions, performIdentityVerification } from '../services/api';
import MoveEasyLogo from './icons/MoveEasyLogo';
import CashInFlow from './CashInFlow';
import CashOutOptions from './CashOutOptions';
import Activity from './Activity';
import BottomNavBar, { type View } from './BottomNavBar';
import EyeIcon from './icons/EyeIcon';
import EyeSlashIcon from './icons/EyeSlashIcon';
import NotificationPermissionBanner from './NotificationPermissionBanner';
import ShieldCheckIcon from './icons/ShieldCheckIcon';
import VerificationFlow from './VerificationFlow';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user: initialUser, onLogout }) => {
  const [user, setUser] = useState<User>(initialUser);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<View>('home');
  const [showBalance, setShowBalance] = useState(true);
  const [isCashInModalOpen, setCashInModalOpen] = useState(false);
  const [showVerificationFlow, setShowVerificationFlow] = useState(!user.isVerified);

  const fetchTransactions = useCallback(async () => {
    try {
      setLoading(true);
      const userTransactions = await getTransactions(user.id);
      setTransactions(userTransactions);
    } catch (error) {
      console.error("Failed to fetch transactions:", error);
    } finally {
      setLoading(false);
    }
  }, [user.id]);
  
  useEffect(() => {
    // Only fetch transactions if the user is verified.
    if (user.isVerified) {
      fetchTransactions();
    }
  }, [user.isVerified, fetchTransactions]);

  const handleTransactionSuccess = (newTransaction: Transaction) => {
    setTransactions(prev => [{ ...newTransaction, isNew: true }, ...prev]);
    
    // Update balance based on transaction
    const newBalance = newTransaction.type === 'redeem'
      ? user.balance + newTransaction.amount
      : user.balance - newTransaction.amount;
    setUser(currentUser => ({...currentUser, balance: newBalance }));
    
    // Switch to activity view after a transaction to show it
    setView('activity');
    setCashInModalOpen(false); // Close modal if open

    if (Notification.permission === 'granted') {
      const title = newTransaction.type === 'redeem' ? 'Cash In Successful' : 'Payout Processed';
      const body = `Amount: ${formatCurrency(newTransaction.amount)}\nDescription: ${newTransaction.description}`;
      new Notification(title, { body });
    }
  };

  const handleVerificationSuccess = async () => {
    try {
      await performIdentityVerification(user.id);
      setUser(currentUser => ({...currentUser, isVerified: true}));
      setShowVerificationFlow(false);
    } catch (error) {
      console.error("Identity verification failed", error);
      // Optionally show an error message to the user
    }
  };

  const handleSkipVerification = () => {
    setShowVerificationFlow(false);
  };

  // For unverified users who haven't skipped, render the mandatory verification flow.
  if (showVerificationFlow) {
    return <VerificationFlow onVerified={handleVerificationSuccess} onSkip={handleSkipVerification} />;
  }


  const renderHomeView = () => (
    <>
      <div className="bg-white p-6 rounded-2xl shadow-lg mb-6">
        <div className="flex justify-between items-center">
            <div>
                <p className="text-sm text-slate-500">Available Balance</p>
                <div className="flex items-center gap-2">
                    <p className="text-3xl font-bold text-slate-800">
                        {showBalance ? formatCurrency(user.balance) : 'R ••••••'}
                    </p>
                    <button onClick={() => setShowBalance(!showBalance)} className="text-slate-500 hover:text-slate-800" aria-label={showBalance ? 'Hide balance' : 'Show balance'}>
                        {showBalance ? <EyeSlashIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                    </button>
                </div>
            </div>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-4">
            <button onClick={() => setCashInModalOpen(true)} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Cash In</button>
            <button onClick={() => setView('cash-out')} className="w-full px-4 py-3 text-base font-bold text-teal-700 bg-teal-100 rounded-lg hover:bg-teal-200">Cash Out</button>
        </div>
      </div>
      
      <div className="mt-4">
          <h3 className="text-lg font-bold text-slate-800 mb-2">Recent Activity</h3>
          <div className="bg-white p-4 rounded-2xl shadow-lg">
              <Activity transactions={transactions.slice(0, 3)} isLoading={loading} isPreview={true} />
          </div>
      </div>
    </>
  );
  
  const renderProfileView = () => (
    <div className="space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-lg text-center">
            <h3 className="text-xl font-bold text-slate-800">{user.email}</h3>
            <p className={`mt-2 text-sm font-semibold flex items-center justify-center gap-2 ${user.isVerified ? 'text-green-600' : 'text-orange-600'}`}>
                {user.isVerified ? <ShieldCheckIcon className="h-5 w-5"/> : null}
                {user.isVerified ? 'Verified' : 'Verification Required'}
            </p>
            {!user.isVerified && (
              <button 
                onClick={() => setShowVerificationFlow(true)}
                className="w-full mt-4 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
              >
                Verify Your Account
              </button>
            )}
        </div>
        <button 
            onClick={onLogout} 
            className="w-full mt-4 px-4 py-3 text-base font-bold text-red-600 bg-red-50 rounded-lg hover:bg-red-100"
        >
            Logout
        </button>
    </div>
  );

  const renderView = () => {
    switch (view) {
      case 'cash-out':
        return <CashOutOptions user={user} onPayoutSuccess={handleTransactionSuccess} />;
      case 'activity':
        return <Activity transactions={transactions} isLoading={loading} />;
      case 'profile':
        return renderProfileView();
      case 'home':
      default:
        return renderHomeView();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white/80 backdrop-blur-lg sticky top-0 z-10 p-4 border-b border-slate-200">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <MoveEasyLogo className="h-8 w-8 text-teal-600" />
            <h1 className="text-xl font-bold text-slate-800">MoveEasy</h1>
          </div>
          <p className="text-sm font-semibold text-slate-600 hidden sm:block">
            {user.email}
          </p>
        </div>
      </header>
      
      <main className="flex-grow max-w-3xl w-full mx-auto p-4 sm:p-6 pb-24">
        {view === 'home' && <NotificationPermissionBanner />}
        {renderView()}
      </main>

      <BottomNavBar currentView={view} setView={setView} isVerified={user.isVerified} />

      {isCashInModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fadeIn">
              <div className="relative w-full max-w-md" onClick={(e) => e.stopPropagation()}>
                <CashInFlow onRedeemSuccess={handleTransactionSuccess} />
                <button 
                    onClick={() => setCashInModalOpen(false)}
                    className="absolute -top-2 -right-2 h-8 w-8 bg-white rounded-full flex items-center justify-center shadow-lg text-slate-600 hover:text-slate-900"
                    aria-label="Close cash in modal"
                >
                    &times;
                </button>
              </div>
          </div>
      )}
    </div>
  );
};
export default Dashboard;