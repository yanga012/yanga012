import React, { useState, useEffect } from 'react';
import type { BankDetails, Status, Transaction, User } from '../types';
import { formatCurrency } from '../types';
import { requestPayout } from '../services/api';
import StepIndicator from './StepIndicator';
import StatusDisplay from './StatusDisplay';
import LoaderIcon from './icons/LoaderIcon';

interface CashOutOptionsProps {
  user: User;
  onPayoutSuccess: (transaction: Transaction) => void;
}

type PayoutMethod = 'eft' | 'payshap' | 'fnb_ewallet' | 'absa_cashsend' | 'sb_instant_money' | 'nedbank_mobimoney';
type Step = 'method' | 'details' | 'confirm' | 'status';

const CashOutOptions: React.FC<CashOutOptionsProps> = ({ user, onPayoutSuccess }) => {
  const [step, setStep] = useState<Step>('method');
  const [method, setMethod] = useState<PayoutMethod | null>(null);
  const [amount, setAmount] = useState<number | ''>('');
  const [bankDetails, setBankDetails] = useState<BankDetails>({ bankName: '', accountNumber: '', branchCode: '' });
  const [payoutIdentifier, setPayoutIdentifier] = useState('');
  const [saveDetails, setSaveDetails] = useState<boolean>(false);
  
  const [status, setStatus] = useState<Status>('idle');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (method === 'eft' && user.savedBankDetails) {
      setBankDetails(user.savedBankDetails);
    }
  }, [method, user.savedBankDetails]);

  const steps = ['Method', 'Details', 'Confirm'];
  const currentStepIndex = step === 'method' ? 0 : step === 'details' ? 1 : 2;

  const handleSelectMethod = (selectedMethod: PayoutMethod) => {
    setMethod(selectedMethod);
    setStep('details');
  };

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount === '' || amount <= 0) {
      setError('Please enter a valid amount.');
      return;
    }
    if (amount > user.balance) {
      setError('Amount cannot exceed your balance.');
      return;
    }
    setError(null);
    setStep('confirm');
  };

  const handleConfirmPayout = async () => {
    if (!method || amount === '') return;

    setStatus('loading');
    setError(null);
    setStep('status');

    try {
      const details = method === 'eft' ? bankDetails : payoutIdentifier;
      const newTransaction = await requestPayout(amount, method, details, saveDetails);
      onPayoutSuccess(newTransaction);
      setStatus('success');
    } catch (err: any) {
      setStatus('error');
      setError(err.message || 'An unexpected error occurred.');
    }
  };
  
  const resetFlow = () => {
    setStep('method');
    setMethod(null);
    setAmount('');
    setBankDetails({ bankName: '', accountNumber: '', branchCode: '' });
    setPayoutIdentifier('');
    setStatus('idle');
    setError(null);
    setSaveDetails(false);
  }

  const renderStepContent = () => {
    const isMobileMoney = method && ['fnb_ewallet', 'absa_cashsend', 'sb_instant_money', 'nedbank_mobimoney'].includes(method);

    switch (step) {
      case 'method':
        return (
          <div className="text-center">
            <h3 className="text-lg font-bold text-slate-800 mb-1">Choose Payout Method</h3>
            <p className="text-sm text-slate-500 mb-6">How would you like to receive your money?</p>
            <div className="space-y-4">
              <div>
                <h4 className="text-md font-semibold text-slate-600 text-left pt-2 mb-2">Bank Transfer</h4>
                <div className="space-y-2">
                    <button onClick={() => handleSelectMethod('eft')} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                        <p className="font-semibold">EFT (Bank Transfer)</p>
                        <p className="text-sm text-slate-500">Standard transfer to your bank account (1-2 business days).</p>
                    </button>
                    <button onClick={() => handleSelectMethod('payshap')} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                        <p className="font-semibold">PayShap</p>
                        <p className="text-sm text-slate-500">Instant payment to your phone number or ShapID.</p>
                    </button>
                </div>
              </div>

              <div>
                <h4 className="text-md font-semibold text-slate-600 text-left pt-4 mb-2">Mobile Money Collection</h4>
                 <div className="space-y-2">
                    <button onClick={() => handleSelectMethod('fnb_ewallet')} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                        <p className="font-semibold">FNB eWallet</p>
                        <p className="text-sm text-slate-500">Send money to a mobile number, collect at FNB ATMs.</p>
                    </button>
                     <button onClick={() => handleSelectMethod('absa_cashsend')} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                        <p className="font-semibold">Absa CashSend</p>
                        <p className="text-sm text-slate-500">Send money to a mobile number, collect at Absa ATMs.</p>
                    </button>
                     <button onClick={() => handleSelectMethod('sb_instant_money')} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                        <p className="font-semibold">Standard Bank Instant Money</p>
                        <p className="text-sm text-slate-500">Collect cash at Standard Bank ATMs or retail partners.</p>
                    </button>
                     <button onClick={() => handleSelectMethod('nedbank_mobimoney')} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                        <p className="font-semibold">Nedbank MobiMoney</p>
                        <p className="text-sm text-slate-500">Withdraw cash at Nedbank ATMs or select retailers.</p>
                    </button>
                 </div>
              </div>

            </div>
          </div>
        );
      case 'details':
        return (
          <form onSubmit={handleDetailsSubmit}>
            <h3 className="text-lg font-bold text-slate-800 mb-6 text-center">Enter Payout Details</h3>
            <div className="space-y-4">
                <div>
                    <label htmlFor="amount" className="text-sm font-medium text-slate-700">Amount (Balance: {formatCurrency(user.balance)})</label>
                    <input id="amount" type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} placeholder="0.00" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors" />
                </div>
              {method === 'eft' && (
                <>
                  <div>
                    <label htmlFor="bankName" className="text-sm font-medium text-slate-700">Bank Name</label>
                    <input id="bankName" type="text" value={bankDetails.bankName} onChange={e => setBankDetails({...bankDetails, bankName: e.target.value})} placeholder="e.g., Standard Bank" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors" />
                  </div>
                   <div>
                    <label htmlFor="accountNumber" className="text-sm font-medium text-slate-700">Account Number</label>
                    <input id="accountNumber" type="text" value={bankDetails.accountNumber} onChange={e => setBankDetails({...bankDetails, accountNumber: e.target.value})} placeholder="Your account number" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors" />
                  </div>
                  <div>
                    <label htmlFor="branchCode" className="text-sm font-medium text-slate-700">Branch Code</label>
                    <input id="branchCode" type="text" value={bankDetails.branchCode} onChange={e => setBankDetails({...bankDetails, branchCode: e.target.value})} placeholder="Your branch code" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors" />
                  </div>
                  <div className="pt-2">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={saveDetails}
                        onChange={(e) => setSaveDetails(e.target.checked)}
                        className="h-4 w-4 rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                      />
                      <span className="ml-2 text-sm text-slate-700">Save these details for future use</span>
                    </label>
                  </div>
                </>
              )}
              {(method === 'payshap' || isMobileMoney) && (
                 <div>
                    <label htmlFor="payoutIdentifier" className="text-sm font-medium text-slate-700">
                        {isMobileMoney ? 'Recipient Mobile Number' : 'PayShap Identifier'}
                    </label>
                    <input 
                        id="payoutIdentifier" 
                        type={isMobileMoney ? 'tel' : 'text'} 
                        value={payoutIdentifier} 
                        onChange={e => setPayoutIdentifier(e.target.value)} 
                        placeholder={isMobileMoney ? 'e.g., 0821234567' : 'Phone number or ShapID'}
                        required 
                        className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors" />
                  </div>
              )}
            </div>
            {error && <p className="mt-4 text-center text-sm text-red-600">{error}</p>}
            <div className="flex gap-2 mt-6">
                <button type="button" onClick={() => setStep('method')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
                <button type="submit" className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Continue</button>
            </div>
          </form>
        );
      case 'confirm':
          const payoutDetails = method === 'eft' 
            ? `${bankDetails.bankName} (...${bankDetails.accountNumber.slice(-4)})`
            : payoutIdentifier;
          const methodDisplayMap: { [key in PayoutMethod]: string } = {
            'eft': 'EFT (Bank Transfer)',
            'payshap': 'PayShap',
            'fnb_ewallet': 'FNB eWallet',
            'absa_cashsend': 'Absa CashSend',
            'sb_instant_money': 'Standard Bank Instant Money',
            'nedbank_mobimoney': 'Nedbank MobiMoney',
          };

        return (
            <div className="text-center">
                 <h3 className="text-lg font-bold text-slate-800 mb-6">Confirm Payout</h3>
                 <div className="bg-slate-50 p-4 rounded-lg space-y-2 text-left mb-6">
                    <div className="flex justify-between"><span className="text-slate-500">Amount:</span><span className="font-semibold text-slate-800">{formatCurrency(Number(amount))}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">To:</span><span className="font-semibold text-slate-800">{payoutDetails}</span></div>
                    <div className="flex justify-between"><span className="text-slate-500">Method:</span><span className="font-semibold text-slate-800">{method ? methodDisplayMap[method] : ''}</span></div>
                 </div>
                 <div className="flex gap-2 mt-6">
                    <button type="button" onClick={() => setStep('details')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
                    <button onClick={handleConfirmPayout} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Confirm & Pay</button>
                </div>
            </div>
        );
      case 'status':
        return (
            <div>
                <StatusDisplay 
                    status={status}
                    message={
                        status === 'loading' ? 'Processing your payout...' :
                        status === 'success' ? 'Payout successful!' :
                        status === 'error' ? error || 'Payout failed.' : ''
                    }
                />
                {status !== 'loading' && (
                     <button onClick={resetFlow} className="w-full mt-4 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">
                        Make another payout
                    </button>
                )}
            </div>
        )
      default: return null;
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg">
      <div className="mb-6">
        <StepIndicator steps={steps} currentStep={currentStepIndex} />
      </div>
      {renderStepContent()}
    </div>
  );
};

export default CashOutOptions;