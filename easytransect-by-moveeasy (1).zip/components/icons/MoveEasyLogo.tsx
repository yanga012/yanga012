import React from 'react';

const MoveEasyLogo: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-label="MoveEasy Logo"
    role="img"
  >
    <path
      d="M16 10L30 24L16 38"
      stroke="currentColor"
      strokeWidth="4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M26 10L40 24L26 38"
      stroke="currentColor"
      strokeWidth="4"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="opacity-70"
    />
  </svg>
);

export default MoveEasyLogo;
