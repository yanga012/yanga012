import React, { useState, useEffect } from 'react';
import { verifyUserAccount } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import XCircleIcon from './icons/XCircleIcon';
import MoveEasyLogo from './icons/MoveEasyLogo';

interface EmailVerificationHandlerProps {
  email: string;
  token: string;
}

type VerificationStatus = 'verifying' | 'success' | 'error';

const EmailVerificationHandler: React.FC<EmailVerificationHandlerProps> = ({ email, token }) => {
  const [status, setStatus] = useState<VerificationStatus>('verifying');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const verify = async () => {
      try {
        await verifyUserAccount(email, token);
        setStatus('success');
        setMessage('Your account has been successfully verified!');
      } catch (err: any) {
        setStatus('error');
        setMessage(err.message || 'An unknown error occurred.');
      }
    };
    verify();
  }, [email, token]);

  const statusConfig = {
    verifying: {
      icon: <LoaderIcon className="h-12 w-12 text-teal-600" />,
      title: 'Verifying Your Account...',
      text: 'Please wait a moment.',
      color: 'text-slate-800'
    },
    success: {
      icon: <CheckCircleIcon className="h-12 w-12 text-green-500" />,
      title: 'Verification Successful!',
      text: message,
      color: 'text-green-800'
    },
    error: {
      icon: <XCircleIcon className="h-12 w-12 text-red-500" />,
      title: 'Verification Failed',
      text: message,
      color: 'text-red-800'
    }
  };

  const config = statusConfig[status];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <main className="bg-white p-8 rounded-2xl shadow-lg max-w-sm w-full text-center">
        <header className="flex flex-col items-center text-center mb-6">
          <MoveEasyLogo className="h-10 w-10 text-teal-600 mb-3" />
          {config.icon}
        </header>
        <h1 className={`text-2xl font-bold ${config.color}`}>{config.title}</h1>
        <p className="text-slate-600 mt-2">{config.text}</p>
        
        {status !== 'verifying' && (
          <button
            onClick={() => {
              // Redirect to the login page by removing URL parameters
              window.location.href = window.location.pathname;
            }}
            className="w-full mt-6 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
          >
            Proceed to Sign In
          </button>
        )}
      </main>
    </div>
  );
};

export default EmailVerificationHandler;
