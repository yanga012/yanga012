
import React, { useState } from 'react';
import type { Transaction } from '../types';
import { searchTransactionsWithAI } from '../services/api';
import TransactionHistory from './TransactionHistory';
import TransactionChart from './TransactionChart';
import SearchIcon from './icons/SearchIcon';
import LoaderIcon from './icons/LoaderIcon';
import XCircleIcon from './icons/XCircleIcon';

interface ActivityProps {
  transactions: Transaction[];
  isLoading?: boolean;
  isPreview?: boolean;
}

const Activity: React.FC<ActivityProps> = ({ transactions, isLoading = false, isPreview = false }) => {
  const [activeTab, setActiveTab] = useState<'history' | 'chart'>('history');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[] | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      handleClearSearch();
      return;
    }
    
    setIsSearching(true);
    setSearchError(null);
    setFilteredTransactions(null);

    try {
      const matchingIds = await searchTransactionsWithAI(searchQuery, transactions);
      const filtered = transactions.filter(t => matchingIds.includes(t.id));
      setFilteredTransactions(filtered);
    } catch (err: any) {
      setSearchError(err.message || 'An unknown error occurred during search.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setFilteredTransactions(null);
    setSearchError(null);
  };

  const displayedTransactions = filteredTransactions ?? transactions;

  if (isPreview) {
    return <TransactionHistory transactions={transactions} embedded isLoading={isLoading} />;
  }

  const renderMainContent = () => {
    if (isLoading) {
      return activeTab === 'history' 
        ? <TransactionHistory transactions={[]} embedded isLoading={true} />
        : <TransactionChart transactions={[]} embedded isLoading={true} />;
    }

    if (isSearching) {
      return (
        <div className="flex flex-col items-center justify-center h-48 gap-3">
            <LoaderIcon className="h-8 w-8 text-teal-500" />
            <p className="text-sm text-slate-500">AI is searching your transactions...</p>
        </div>
      );
    }

    if (searchError) {
      return (
        <div className="flex flex-col items-center justify-center h-48 gap-3 text-center">
            <XCircleIcon className="h-8 w-8 text-red-500" />
            <p className="text-sm text-red-700">{searchError}</p>
        </div>
      );
    }
    
    if (filteredTransactions && filteredTransactions.length === 0) {
      return (
        <div className="flex items-center justify-center h-48">
          <p className="text-sm text-slate-500 text-center">No matching transactions found for your search.</p>
        </div>
      )
    }

    return activeTab === 'history' 
      ? <TransactionHistory transactions={displayedTransactions} embedded />
      : <TransactionChart transactions={displayedTransactions} embedded />;
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
            <h3 className="text-xl font-bold text-slate-800">Activity</h3>
            <div className="flex items-center gap-2 rounded-lg bg-slate-100 p-1 self-start sm:self-center">
            <button
                onClick={() => setActiveTab('history')}
                className={`px-3 py-1 text-sm font-semibold rounded-md transition-all ${activeTab === 'history' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:bg-slate-200'}`}
                aria-pressed={activeTab === 'history'}
            >
                History
            </button>
            <button
                onClick={() => setActiveTab('chart')}
                className={`px-3 py-1 text-sm font-semibold rounded-md transition-all ${activeTab === 'chart' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:bg-slate-200'}`}
                aria-pressed={activeTab === 'chart'}
            >
                Chart
            </button>
            </div>
        </div>

        <div className="mt-4">
            <form onSubmit={handleSearch} className="flex gap-2 mb-4">
                <div className="relative flex-grow">
                    <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search transactions with AI (e.g., payouts > R40)"
                        className="w-full pl-10 pr-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                        disabled={isSearching || isLoading}
                    />
                     {searchQuery && (
                      <button 
                        type="button" 
                        onClick={handleClearSearch}
                        className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 hover:text-slate-600"
                        aria-label="Clear search"
                        >
                          <XCircleIcon className="h-5 w-5" />
                      </button>
                     )}
                </div>
                <button
                    type="submit"
                    className="px-4 py-2 text-sm font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 focus:outline-none focus:ring-4 focus:ring-teal-300 disabled:bg-slate-400 disabled:cursor-not-allowed flex items-center justify-center"
                    disabled={isSearching || isLoading}
                >
                    {isSearching ? <LoaderIcon className="h-5 w-5" /> : 'Search'}
                </button>
            </form>
        </div>
      
      <div className="mt-2 min-h-[12rem]">{renderMainContent()}</div>

    </div>
  );
};

export default Activity;
