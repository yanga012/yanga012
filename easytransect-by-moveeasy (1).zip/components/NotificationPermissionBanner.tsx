
import React, { useState, useEffect } from 'react';

const NotificationPermissionBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
      // Show if permission has not been granted or denied
      if (Notification.permission === 'default') {
        setIsVisible(true);
      }
    }
  }, []);

  const handleRequestPermission = async () => {
    if ('Notification' in window) {
      const result = await Notification.requestPermission();
      setPermission(result);
      setIsVisible(false); // Hide banner after interaction
    }
  };

  const handleDismiss = () => {
    setIsVisible(false);
  };

  if (!isVisible || permission !== 'default') {
    return null;
  }

  return (
    <div className="mb-6 bg-teal-50 border border-teal-200 rounded-lg p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
      <div className="text-teal-800 text-sm">
        <p className="font-semibold">Stay updated!</p>
        <p>Enable notifications to get real-time alerts about your transactions.</p>
      </div>
      <div className="flex-shrink-0 flex gap-2">
        <button
          onClick={handleRequestPermission}
          className="px-4 py-2 text-sm font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
        >
          Enable Notifications
        </button>
        <button
          onClick={handleDismiss}
          className="px-4 py-2 text-sm font-medium text-slate-600 bg-white/60 rounded-lg hover:bg-white"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
};

export default NotificationPermissionBanner;
