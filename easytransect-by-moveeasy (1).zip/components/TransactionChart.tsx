import React from 'react';
import type { Transaction } from '../types';
import { formatCurrency } from '../types';
import TransactionChartSkeleton from './skeletons/TransactionChartSkeleton';

interface TransactionChartProps {
  transactions: Transaction[];
  embedded?: boolean;
  isLoading?: boolean;
}

const TransactionChart: React.FC<TransactionChartProps> = ({ transactions, embedded = false, isLoading = false }) => {
  // Only show the 7 most recent transactions for the chart
  const recentTransactions = transactions.slice(0, 7).reverse();
  
  if (isLoading) {
    return <TransactionChartSkeleton />;
  }

  const chartContent = recentTransactions.length < 2 ? (
    <div className={`flex items-center justify-center h-48 bg-slate-50 rounded-lg ${!embedded ? 'mt-4' : ''}`}>
      <p className="text-sm text-slate-500">Not enough data to display chart.</p>
    </div>
  ) : (
    <>
      <div className="mt-4 h-48 flex items-end justify-around gap-2 p-4 border-b border-slate-200">
        {recentTransactions.map(t => {
          const maxValue = Math.max(...recentTransactions.map(tr => tr.amount), 0);
          const barHeight = maxValue > 0 ? (t.amount / maxValue) * 100 : 0;
          const isRedeem = t.type === 'redeem';
          return (
            <div key={t.id} className="group relative flex-1 flex flex-col items-center h-full justify-end">
              <div className="absolute bottom-full mb-2 w-max px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                {isRedeem ? '+' : '-'}{formatCurrency(t.amount)}
              </div>
              <div
                className={`w-full rounded-t-md transition-colors ${isRedeem ? 'bg-green-400 hover:bg-green-500' : 'bg-red-400 hover:bg-red-500'}`}
                style={{ height: `${barHeight}%`, minHeight: '2px' }}
              />
            </div>
          );
        })}
      </div>
       <div className="h-8 flex justify-around gap-2 px-4">
         {recentTransactions.map(t => (
            <div key={t.id} className="flex-1 text-center text-xs text-slate-500 pt-2">
                {new Date(t.date).toLocaleDateString('en-ZA', { month: 'short', day: 'numeric' })}
            </div>
        ))}
      </div>
    </>
  );

  if (embedded) {
    return chartContent;
  }
  
  return (
    <div className="mt-8 bg-white p-6 rounded-2xl shadow-lg">
      <h3 className="text-lg font-bold text-slate-800">Recent Activity</h3>
      {chartContent}
    </div>
  );
};

export default TransactionChart;
