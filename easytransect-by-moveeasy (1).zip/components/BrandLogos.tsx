
import React from 'react';

const Logo: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="flex items-center justify-center h-8 px-3 bg-slate-100 border border-slate-200 rounded-md">
    <span className="text-xs font-bold text-slate-500 tracking-wide">{children}</span>
  </div>
);

const BrandLogos: React.FC = () => {
  return (
    <div className="flex flex-wrap items-center justify-center gap-2 my-2">
      <Logo>1Voucher</Logo>
      <Logo>OTT</Logo>
      <Logo>Blu</Logo>
      <Logo>FNB eWallet</Logo>
      <Logo>Absa CashSend</Logo>
      <Logo>SB Instant Money</Logo>
      <Logo>Nedbank MobiMoney</Logo>
    </div>
  );
};

export default BrandLogos;