
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { validateBankAccount } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';
import ShieldCheckIcon from './icons/ShieldCheckIcon';
import StepIndicator from './StepIndicator';
import CameraIcon from './icons/CameraIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import IdCardIcon from './icons/IdCardIcon';
import UploadCloudIcon from './icons/UploadCloudIcon';
import XCircleIcon from './icons/XCircleIcon';
import InformationCircleIcon from './icons/InformationCircleIcon';
import SunIcon from './icons/SunIcon';
import FaceSmileIcon from './icons/FaceSmileIcon';

interface VerificationFlowProps {
  onVerified: () => void;
  onSkip: () => void;
}

type KycStep = 'intro' | 'selfie' | 'idSelect' | 'idCapture' | 'addressProof' | 'bankProof' | 'bankDetails' | 'confirm' | 'submitting' | 'success';
type IdType = 'sa_id' | 'passport';

const InfoBox: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="mt-2 mb-4 p-3 bg-teal-50 border border-teal-200 rounded-lg text-xs text-teal-800 flex items-start gap-2 animate-fadeIn">
    <InformationCircleIcon className="h-4 w-4 flex-shrink-0 mt-0.5" />
    <div>{children}</div>
  </div>
);


const VerificationFlow: React.FC<VerificationFlowProps> = ({ onVerified, onSkip }) => {
  const [step, setStep] = useState<KycStep>('intro');
  const [selfie, setSelfie] = useState<string | null>(null);
  const [idType, setIdType] = useState<IdType>('sa_id');
  const [idNumber, setIdNumber] = useState('');
  const [idImage, setIdImage] = useState<File | string | null>(null);
  const [addressProof, setAddressProof] = useState<File | null>(null);
  const [bankProof, setBankProof] = useState<File | null>(null);
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);

  const [idImageError, setIdImageError] = useState<string | null>(null);
  const [addressProofError, setAddressProofError] = useState<string | null>(null);
  const [bankProofError, setBankProofError] = useState<string | null>(null);

  const [bankValidationStatus, setBankValidationStatus] = useState<'idle' | 'validating' | 'error'>('idle');
  const [bankValidationError, setBankValidationError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setIsCameraActive(true);
        }
      } catch (err) {
        console.error("Error accessing camera:", err);
        setCameraError("Could not access camera. Please check permissions and try again.");
        setIsCameraActive(false);
      }
    } else {
        setCameraError("Camera not supported on this device.");
        setIsCameraActive(false);
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsCameraActive(false);
    }
  }, []);

  useEffect(() => {
    // Cleanup camera on component unmount
    return () => stopCamera();
  }, [stopCamera]);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        if(step === 'selfie') setSelfie(dataUrl);
        if(step === 'idCapture') {
            setIdImage(dataUrl);
            setIdImageError(null);
        }
        stopCamera();
      }
    }
  };

  const handleFileChange = (
    setter: (file: File | null) => void,
    errorSetter: React.Dispatch<React.SetStateAction<string | null>>
  ) => (e: React.ChangeEvent<HTMLInputElement>) => {
      errorSetter(null); // Clear previous errors
      const file = e.target.files?.[0];
      const MAX_FILE_SIZE_MB = 5;
      const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
      const ALLOWED_MIMETYPES = ['image/jpeg', 'image/png', 'application/pdf'];
  
      if (file) {
        if (!ALLOWED_MIMETYPES.includes(file.type)) {
          errorSetter(`Invalid file type. Please upload a PNG, JPG, or PDF.`);
          e.target.value = ''; // Reset input
          return;
        }
        if (file.size > MAX_FILE_SIZE_BYTES) {
          errorSetter(`File is too large. Maximum size is ${MAX_FILE_SIZE_MB}MB.`);
          e.target.value = ''; // Reset input
          return;
        }
        setter(file);
      }
  };

  const handleBankDetailsSubmit = async () => {
    if (!bankName.trim() || !accountNumber.trim()) return;

    setBankValidationStatus('validating');
    setBankValidationError(null);

    try {
      await validateBankAccount(bankName, accountNumber);
      setBankValidationStatus('idle'); // reset on success
      setStep('confirm');
    } catch (err: any) {
      setBankValidationStatus('error');
      setBankValidationError(err.message || 'An unknown validation error occurred.');
    }
  };

  const handleSubmit = () => {
    setStep('submitting');
    setTimeout(() => {
      onVerified();
      setStep('success'); // Technically won't be seen as component unmounts
    }, 2500); // Simulate API call
  };

  const getFileName = (file: File | string | null): string => {
    if (file instanceof File) return file.name;
    if (typeof file === 'string') return 'Image captured';
    return '';
  };

  const kycSteps = ["Intro", "Selfie", "ID", "Documents", "Bank Details", "Confirm"];
  const stepMap: { [key in KycStep]: number } = {
    intro: 0, selfie: 1, idSelect: 2, idCapture: 2,
    addressProof: 3, bankProof: 3, 
    bankDetails: 4,
    confirm: 5, 
    submitting: 6, 
    success: 6
  };
  const currentStepIndex = stepMap[step];

  const renderContent = () => {
    switch (step) {
      case 'intro':
        return (
          <div className="text-center">
            <ShieldCheckIcon className="h-12 w-12 text-teal-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-slate-800">Identity Verification</h3>
            <p className="text-sm text-slate-500 mt-2 mb-6">To keep your account secure and unlock all features, we need to verify your identity. This process is quick, secure, and required by law.</p>
            
            <div className="bg-slate-50 p-4 rounded-lg text-left mb-6 animate-fadeIn">
                <h4 className="font-semibold text-slate-700 mb-3 text-center">What you'll need:</h4>
                <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                        <IdCardIcon className="h-6 w-6 text-teal-600 flex-shrink-0" />
                        <span className="text-sm text-slate-600">Your valid ID document (SA ID or Passport).</span>
                    </li>
                    <li className="flex items-center gap-3">
                        <SunIcon className="h-6 w-6 text-teal-600 flex-shrink-0" />
                        <span className="text-sm text-slate-600">A well-lit room to take a clear selfie.</span>
                    </li>
                </ul>
            </div>

            <button onClick={() => { setStep('selfie'); startCamera(); }} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Start Verification</button>
            <button onClick={onSkip} className="w-full mt-2 px-4 py-3 text-sm font-medium text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200">Skip for now</button>
          </div>
        );

      case 'selfie':
        return (
          <div>
            <h3 className="text-lg font-bold text-slate-800 mb-2 text-center">Take a Selfie</h3>
            <p className="text-sm text-center text-slate-500">Please look directly at the camera. Ensure your face is well-lit and clearly visible.</p>
            <InfoBox>
              <ul className="list-disc list-inside space-y-1">
                <li>Remove hats and glasses.</li>
                <li>Find a spot with good, even lighting.</li>
                <li>Keep a neutral expression.</li>
              </ul>
            </InfoBox>
            {selfie ? (
                <div className="text-center">
                    <img src={selfie} alt="User selfie" className="rounded-lg mb-4 mx-auto" />
                    <div className="flex gap-2">
                        <button onClick={() => { setSelfie(null); startCamera(); }} className="w-full px-4 py-2 text-sm font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Retake</button>
                        <button onClick={() => setStep('idSelect')} className="w-full px-4 py-2 text-sm font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Looks Good</button>
                    </div>
                </div>
            ) : (
                <div className="text-center">
                    <div className="relative w-full aspect-square bg-slate-200 rounded-lg overflow-hidden mb-4">
                        <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                        
                        {/* Visual Guide Overlay for face placement */}
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none" aria-hidden="true">
                            <div 
                                className="w-[70%] h-[85%] border-4 border-white/50 border-dashed rounded-[50%]"
                            />
                        </div>

                        {cameraError && <div className="absolute inset-0 flex items-center justify-center bg-black/50"><p className="text-white text-sm p-4">{cameraError}</p></div>}
                    </div>
                    
                    {/* Visual Guide Tips */}
                    <div className="grid grid-cols-2 gap-4 text-center mb-4">
                        <div className="flex flex-col items-center justify-center gap-1 p-2 bg-slate-50 rounded-lg h-full">
                            <SunIcon className="h-6 w-6 text-teal-600" />
                            <span className="text-xs font-semibold text-slate-600">Good Lighting</span>
                        </div>
                        <div className="flex flex-col items-center justify-center gap-1 p-2 bg-slate-50 rounded-lg h-full">
                            <FaceSmileIcon className="h-6 w-6 text-teal-600" />
                            <span className="text-xs font-semibold text-slate-600">Neutral Face</span>
                        </div>
                    </div>

                    <button onClick={handleCapture} disabled={!isCameraActive} className="w-full flex items-center justify-center gap-2 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400">
                        <CameraIcon className="h-5 w-5" /> Capture
                    </button>
                </div>
            )}
          </div>
        );
        
      case 'idSelect':
          return (
            <div>
              <h3 className="text-lg font-bold text-slate-800 mb-4 text-center">Identity Document</h3>
              <div className="space-y-4">
                <button onClick={() => { setIdType('sa_id'); setStep('idCapture'); }} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                    <p className="font-semibold">South African ID</p>
                    <p className="text-sm text-slate-500">Use your green ID book or Smart ID card.</p>
                </button>
                <button onClick={() => { setIdType('passport'); setStep('idCapture'); }} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                    <p className="font-semibold">Passport</p>
                    <p className="text-sm text-slate-500">Use a valid, government-issued passport.</p>
                </button>
              </div>
              <button onClick={() => {setStep('selfie'); startCamera();}} className="mt-6 w-full px-4 py-2 text-sm font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
            </div>
          );

      case 'idCapture':
          return (
            <div>
                <h3 className="text-lg font-bold text-slate-800 mb-4 text-center">
                    {idType === 'sa_id' ? 'SA ID Details' : 'Passport Details'}
                </h3>
                <InfoBox>
                  <p className="font-semibold mb-1">To ensure a clear photo:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Place your document on a flat, well-lit surface.</li>
                    <li>Make sure all four corners of the document are visible in the photo.</li>
                    <li>Hold your camera steady to avoid a blurry image.</li>
                    <li>Avoid reflections or glare by adjusting the lighting.</li>
                  </ul>
                </InfoBox>
                <div className="space-y-4">
                     <div>
                        <label htmlFor="idNumber" className="text-sm font-medium text-slate-700">{idType === 'sa_id' ? 'ID Number' : 'Passport Number'}</label>
                        <input id="idNumber" type="text" value={idNumber} onChange={e => setIdNumber(e.target.value)} className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" />
                    </div>
                    <div>
                        <label className="text-sm font-medium text-slate-700">ID Document Image</label>
                        {idImage ? (
                            <div className="mt-2 flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                                <span className="text-sm text-green-800 truncate">{getFileName(idImage)}</span>
                                <button onClick={() => {setIdImage(null); setIdImageError(null);}}><XCircleIcon className="h-5 w-5 text-slate-500" /></button>
                            </div>
                        ) : isCameraActive ? (
                             <div className="text-center mt-2">
                                <div className="relative w-full aspect-video bg-slate-200 rounded-lg overflow-hidden mb-2">
                                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={stopCamera} className="w-full px-4 py-2 text-sm font-bold text-slate-700 bg-slate-200 rounded-lg">Cancel</button>
                                    <button onClick={handleCapture} className="w-full px-4 py-2 text-sm font-bold text-white bg-teal-600 rounded-lg">Capture ID</button>
                                </div>
                            </div>
                        ) : (
                            <div className="mt-1 grid grid-cols-2 gap-2">
                                <label htmlFor="id-upload" className="w-full cursor-pointer flex flex-col items-center justify-center gap-1 px-4 py-3 text-sm font-bold text-teal-700 bg-teal-50 rounded-lg hover:bg-teal-100">
                                    <UploadCloudIcon className="h-5 w-5" /> Upload File
                                </label>
                                <input id="id-upload" type="file" accept="image/jpeg,image/png" className="hidden" onChange={handleFileChange(setIdImage, setIdImageError)}/>
                                <button onClick={startCamera} className="w-full flex flex-col items-center justify-center gap-1 px-4 py-3 text-sm font-bold text-teal-700 bg-teal-50 rounded-lg hover:bg-teal-100">
                                    <CameraIcon className="h-5 w-5" /> Take Photo
                                </button>
                            </div>
                        )}
                        {idImageError && <p className="mt-2 text-sm text-red-600">{idImageError}</p>}
                    </div>
                </div>
                <div className="flex gap-2 mt-6">
                    <button onClick={() => setStep('idSelect')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
                    <button onClick={() => setStep('addressProof')} disabled={!idNumber || !idImage} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400">Next</button>
                </div>
            </div>
          );

    case 'addressProof':
    case 'bankProof':
        const isAddress = step === 'addressProof';
        const file = isAddress ? addressProof : bankProof;
        const setFile = isAddress ? setAddressProof : setBankProof;
        const error = isAddress ? addressProofError : bankProofError;
        const setError = isAddress ? setAddressProofError : setBankProofError;

        const title = isAddress ? 'Proof of Address' : 'Proof of Bank Account';
        const description = isAddress ? 'Upload a recent utility bill or official document showing your name and address.' : 'Upload a recent bank statement. Required for enabling EFT and PayShap transfers.';
        const nextStep = isAddress ? 'bankProof' : 'bankDetails';
        const prevStep = isAddress ? 'idCapture' : 'addressProof';

        return (
            <div>
                 <h3 className="text-lg font-bold text-slate-800 mb-2 text-center">{title}</h3>
                 <p className="text-sm text-center text-slate-500">{description}</p>
                 <InfoBox>
                    <ul className="list-disc list-inside space-y-1">
                      {isAddress ? (
                          <>
                            <li>Accepted: Utility bill, bank statement, or lease agreement.</li>
                            <li>Must be less than 3 months old.</li>
                          </>
                      ) : (
                          <>
                           <li>Accepted: Bank statement or official letter from your bank.</li>
                           <li>Must show bank logo, your name, and account number.</li>
                          </>
                      )}
                      <li>Your full name and address must be clearly visible.</li>
                    </ul>
                 </InfoBox>
                 {file ? (
                    <div className="mt-2 flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                        <span className="text-sm text-green-800 truncate">{file.name}</span>
                        <button onClick={() => {setFile(null); setError(null);}}><XCircleIcon className="h-5 w-5 text-slate-500" /></button>
                    </div>
                 ) : (
                    <label htmlFor={step} className="mt-2 w-full cursor-pointer flex flex-col items-center justify-center gap-2 px-4 py-10 border-2 border-dashed border-slate-300 text-slate-500 rounded-lg hover:border-teal-500 hover:text-teal-600">
                        <UploadCloudIcon className="h-8 w-8" />
                        <span className="text-sm font-semibold">Click to upload document</span>
                        <span className="text-xs">PDF, PNG, JPG (Max 5MB)</span>
                    </label>
                 )}
                 <input id={step} type="file" accept=".pdf,image/jpeg,image/png" className="hidden" onChange={handleFileChange(setFile, setError)} />
                 {error && <p className="mt-2 text-sm text-red-600 text-center">{error}</p>}
                 <div className="flex gap-2 mt-6">
                    <button onClick={() => setStep(prevStep)} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg">Back</button>
                    <button onClick={() => setStep(nextStep)} disabled={!file} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg disabled:bg-slate-400">Next</button>
                 </div>
            </div>
        )
    
    case 'bankDetails':
      const isValidating = bankValidationStatus === 'validating';
      return (
        <div>
          <h3 className="text-lg font-bold text-slate-800 mb-2 text-center">Bank Account Details</h3>
          <p className="text-sm text-center text-slate-500">Please provide your bank account details for verification. This ensures we can securely process payouts to you.</p>
          <InfoBox>
            <ul className="list-disc list-inside space-y-1">
              <li>Your bank account must be in your own name.</li>
              <li>This information is encrypted and stored securely.</li>
            </ul>
          </InfoBox>
          <div className="space-y-4">
            <div>
              <label htmlFor="bankName" className="text-sm font-medium text-slate-700">Bank Name</label>
              <input id="bankName" type="text" value={bankName} onChange={e => setBankName(e.target.value)} placeholder="e.g., Capitec Bank" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={isValidating} />
            </div>
            <div>
              <label htmlFor="accountNumber" className="text-sm font-medium text-slate-700">Account Number</label>
              <input id="accountNumber" type="text" inputMode="numeric" value={accountNumber} onChange={e => setAccountNumber(e.target.value)} placeholder="Your account number" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500" disabled={isValidating} />
            </div>
          </div>
          {bankValidationError && (
              <p className="mt-4 text-center text-sm text-red-600 animate-fadeIn">{bankValidationError}</p>
          )}
          <div className="flex gap-2 mt-6">
            <button onClick={() => setStep('bankProof')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300" disabled={isValidating}>Back</button>
            <button onClick={handleBankDetailsSubmit} disabled={!bankName.trim() || !accountNumber.trim() || isValidating} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 flex items-center justify-center">
              {isValidating ? <LoaderIcon className="h-6 w-6" /> : 'Validate & Continue'}
            </button>
          </div>
        </div>
      );

    case 'confirm':
        return (
            <div className="text-center">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Confirm Details</h3>
                <div className="bg-slate-50 p-4 rounded-lg space-y-3 text-left mb-6">
                    <div className="flex justify-between items-center"><span className="text-slate-500 text-sm">Selfie</span><CheckCircleIcon className="h-5 w-5 text-green-500" /></div>
                    <div className="flex justify-between items-center"><span className="text-slate-500 text-sm">ID Document</span><span className="font-semibold text-slate-800 text-sm">{idType === 'sa_id' ? 'SA ID' : 'Passport'}</span></div>
                    <div className="flex justify-between items-center"><span className="text-slate-500 text-sm">ID Number</span><span className="font-mono text-sm text-slate-600">{idNumber}</span></div>
                    <div className="flex justify-between items-center"><span className="text-slate-500 text-sm">ID Image</span><CheckCircleIcon className="h-5 w-5 text-green-500" /></div>
                    <div className="flex justify-between items-center"><span className="text-slate-500 text-sm">Proof of Address</span><span className="font-semibold text-slate-800 text-sm truncate max-w-[50%]">{addressProof?.name}</span></div>
                    <div className="flex justify-between items-center"><span className="text-slate-500 text-sm">Proof of Bank</span><span className="font-semibold text-slate-800 text-sm truncate max-w-[50%]">{bankProof?.name}</span></div>
                    <div className="flex justify-between items-center border-t border-slate-200 mt-2 pt-2"><span className="text-slate-500 text-sm">Bank Name</span><span className="font-semibold text-slate-800 text-sm">{bankName}</span></div>
                    <div className="flex justify-between items-center"><span className="text-slate-500 text-sm">Account Number</span><span className="font-mono text-sm text-slate-600">{accountNumber}</span></div>
                </div>
                 <div className="flex gap-2 mt-6">
                    <button onClick={() => setStep('bankDetails')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
                    <button onClick={handleSubmit} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Submit Verification</button>
                </div>
            </div>
        );

    case 'submitting':
        return (
            <div className="text-center h-64 flex flex-col items-center justify-center">
                <LoaderIcon className="h-10 w-10 text-teal-500" />
                <p className="mt-4 text-sm text-slate-600">Submitting your details for verification...</p>
            </div>
        );

      default:
        return null;
    }
  };

  const totalVerificationSteps = 5;
  const currentStepNumberForDisplay = Math.max(1, Math.min(currentStepIndex, totalVerificationSteps));

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <main className="bg-white p-6 rounded-2xl shadow-lg w-full max-w-lg animate-slideInUp">
        <canvas ref={canvasRef} className="hidden"></canvas>
        {step !== 'intro' && step !== 'submitting' && step !== 'success' && (
             <p className="text-center text-sm font-semibold text-teal-600 mb-2">
                 Step {currentStepNumberForDisplay} of {totalVerificationSteps}
             </p>
        )}
        <div className="mb-8">
            <StepIndicator steps={kycSteps} currentStep={currentStepIndex} />
        </div>
        {renderContent()}
      </main>
    </div>
  );
};

export default VerificationFlow;
