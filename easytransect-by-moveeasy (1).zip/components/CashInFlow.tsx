import React, { useState, useEffect } from 'react';
import { getVoucherPartners, redeemVoucher } from '../services/api';
import type { Status, Transaction, VoucherPartner } from '../types';
import { formatCurrency } from '../types';
import StatusDisplay from './StatusDisplay';
import LoaderIcon from './icons/LoaderIcon';
import StepIndicator from './StepIndicator';

interface CashInFlowProps {
  onRedeemSuccess: (transaction: Transaction) => void;
  successMessage?: string;
}

type Step = 'select_partner' | 'enter_details' | 'confirm' | 'status';
type PartnerCategory = 'voucher' | 'bank';

// Configuration for bank-specific input fields
const bankPartnerConfig: { [key: string]: { refLabel: string; pinLabel: string; refPlaceholder: string; pinPlaceholder: string; refType: string; pinType: string } } = {
  fnb_ewallet: { refLabel: 'Recipient Mobile Number', pinLabel: 'eWallet PIN', refPlaceholder: 'e.g., 0821234567', pinPlaceholder: '4-digit PIN', refType: 'tel', pinType: 'password' },
  absa_cashsend: { refLabel: 'CashSend Reference Number', pinLabel: 'Secret PIN', refPlaceholder: '10-digit number', pinPlaceholder: '6-digit PIN', refType: 'text', pinType: 'password' },
  sb_instant_money: { refLabel: 'Voucher Number', pinLabel: 'Cash Collection PIN', refPlaceholder: 'e.g., SBIM1234567', pinPlaceholder: '4-digit PIN', refType: 'text', pinType: 'password' },
  nedbank_mobimoney: { refLabel: 'MobiMoney Reference', pinLabel: 'PIN', refPlaceholder: 'e.g., NEDMM98765', pinPlaceholder: '4-digit PIN', refType: 'text', pinType: 'password' },
};

const CashInFlow: React.FC<CashInFlowProps> = ({ onRedeemSuccess, successMessage }) => {
  const [step, setStep] = useState<Step>('select_partner');
  const [partners, setPartners] = useState<VoucherPartner[]>([]);
  const [selectedPartner, setSelectedPartner] = useState<VoucherPartner | null>(null);
  const [loadingPartners, setLoadingPartners] = useState(true);
  const [activeCategory, setActiveCategory] = useState<PartnerCategory>('voucher');

  const [voucherCode, setVoucherCode] = useState('');
  const [bankDetails, setBankDetails] = useState({ reference: '', pin: '' });

  const [status, setStatus] = useState<Status>('idle');
  const [message, setMessage] = useState('');
  const [redeemedValue, setRedeemedValue] = useState(0);

  useEffect(() => {
    const fetchPartners = async () => {
      try {
        const fetchedPartners = await getVoucherPartners();
        setPartners(fetchedPartners);
      } catch (error) {
        console.error("Failed to fetch voucher partners:", error);
        setMessage('Could not load voucher partners. Please try again later.');
      } finally {
        setLoadingPartners(false);
      }
    };
    fetchPartners();
  }, []);

  const handlePartnerSelect = (partner: VoucherPartner) => {
    setSelectedPartner(partner);
    setStep('enter_details');
    // Reset all input fields and status
    setVoucherCode('');
    setBankDetails({ reference: '', pin: '' });
    setStatus('idle');
    setMessage('');
    setRedeemedValue(0);
  };

  const handleBack = () => {
    if (step === 'enter_details') {
      setStep('select_partner');
      setSelectedPartner(null);
    } else if (step === 'confirm') {
      setStep('enter_details');
    }
  };

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPartner?.category === 'voucher') {
        if (!voucherCode.trim()) {
            setStatus('error');
            setMessage('Please enter a valid voucher code.');
            return;
        }
    } else if (selectedPartner?.category === 'bank') {
        if (!bankDetails.reference.trim() || !bankDetails.pin.trim()) {
            setStatus('error');
            setMessage('Please fill in all required fields.');
            return;
        }
    }
    
    setStatus('idle');
    setMessage('');
    setStep('confirm');
  };
  
  const handleConfirmAndRedeem = async () => {
    if (!selectedPartner) return;

    setStatus('loading');
    setMessage('Processing your redemption...');
    setRedeemedValue(0);
    setStep('status');

    try {
      const redemptionDetails = selectedPartner.category === 'voucher'
        ? { code: voucherCode }
        : { reference: bankDetails.reference, pin: bankDetails.pin };

      const newTransaction = await redeemVoucher(redemptionDetails, selectedPartner.id);
      setStatus('success');
      setMessage(successMessage || 'Redemption successful! Funds added.');
      setRedeemedValue(newTransaction.amount);
      setTimeout(() => {
        onRedeemSuccess(newTransaction);
      }, 2000); // Allow user to see success message
    } catch (err: any) {
      setStatus('error');
      setMessage(err.message || 'An unexpected error occurred.');
    }
  };

  const resetFlow = () => {
    setStep('select_partner');
    setSelectedPartner(null);
    setVoucherCode('');
    setBankDetails({ reference: '', pin: '' });
    setStatus('idle');
    setMessage('');
  };

  const renderPartnerSelection = () => {
    const TabButton: React.FC<{ category: PartnerCategory; label: string }> = ({ category, label }) => (
      <button
        onClick={() => setActiveCategory(category)}
        className={`w-full py-3 text-sm font-bold rounded-lg transition-colors ${
          activeCategory === category
            ? 'bg-teal-600 text-white'
            : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
        }`}
      >
        {label}
      </button>
    );

    const filteredPartners = partners.filter(p => p.category === activeCategory);
    
    return (
      <div className="text-center">
        <h3 className="text-lg font-bold text-slate-800 mb-1">Choose Cash In Method</h3>
        <p className="text-sm text-slate-500 mb-6">How would you like to add funds?</p>
        
        <div className="grid grid-cols-2 gap-2 mb-6">
          <TabButton category="voucher" label="Redeem Voucher" />
          <TabButton category="bank" label="Bank Mobile Money" />
        </div>
        
        {loadingPartners ? (
          <div className="flex justify-center items-center h-48"><LoaderIcon className="h-8 w-8 text-teal-500" /></div>
        ) : (
          <div className="space-y-3 animate-fadeIn text-left">
            {filteredPartners.length > 0 ? filteredPartners.map(partner => (
              <button
                key={partner.id}
                onClick={() => handlePartnerSelect(partner)}
                className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors"
              >
                <p className="font-semibold">{partner.name}</p>
                <p className="text-sm text-slate-500">{partner.description}</p>
              </button>
            )) : (
              <div className="text-center py-10"><p className="text-sm text-slate-500">No partners in this category.</p></div>
            )}
          </div>
        )}
      </div>
    );
  };

  const renderDetailsEntry = () => {
    if (!selectedPartner) return null;
    
    const isBank = selectedPartner.category === 'bank';
    const config = isBank ? bankPartnerConfig[selectedPartner.id] : null;

    return (
      <form onSubmit={handleDetailsSubmit}>
        <h3 className="text-lg font-bold text-slate-800 mb-6 text-center">Redeem {selectedPartner.name}</h3>
        <div className="space-y-4">
            <p className="text-sm text-center text-slate-500 -mt-4 mb-4">
                Enter the details below to add <span className="font-bold text-teal-600">{formatCurrency(selectedPartner.voucherValue)}</span> to your balance.
            </p>

          {isBank && config ? (
            <>
              <div>
                <label htmlFor="reference" className="text-sm font-medium text-slate-700">{config.refLabel}</label>
                <input
                  id="reference"
                  type={config.refType}
                  value={bankDetails.reference}
                  onChange={e => setBankDetails({...bankDetails, reference: e.target.value})}
                  placeholder={config.refPlaceholder}
                  required
                  className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                />
              </div>
               <div>
                <label htmlFor="pin" className="text-sm font-medium text-slate-700">{config.pinLabel}</label>
                <input
                  id="pin"
                  type={config.pinType}
                  value={bankDetails.pin}
                  onChange={e => setBankDetails({...bankDetails, pin: e.target.value})}
                  placeholder={config.pinPlaceholder}
                  required
                  className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                />
              </div>
            </>
          ) : (
             <div>
                <label htmlFor="voucherCode" className="text-sm font-medium text-slate-700">Voucher Code</label>
                <input
                id="voucherCode"
                type="text"
                value={voucherCode}
                onChange={e => setVoucherCode(e.target.value)}
                placeholder={`e.g., ${selectedPartner.exampleCode}`}
                required
                className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                />
            </div>
          )}
        </div>
        {status === 'error' && <p className="mt-4 text-center text-sm text-red-600">{message}</p>}
        <div className="flex gap-2 mt-6">
            <button type="button" onClick={handleBack} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
            <button type="submit" className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Continue</button>
        </div>
      </form>
    );
  };

  const renderConfirmation = () => {
    if (!selectedPartner) return null;
    
    const isBank = selectedPartner.category === 'bank';
    const config = isBank ? bankPartnerConfig[selectedPartner.id] : null;

    return (
        <div className="text-center">
             <h3 className="text-lg font-bold text-slate-800 mb-6">Confirm Redemption</h3>
             <div className="bg-slate-50 p-4 rounded-lg space-y-2 text-left mb-6">
                <div className="flex justify-between items-center"><span className="text-slate-500">Partner:</span><span className="font-semibold text-slate-800">{selectedPartner.name}</span></div>
                
                {isBank && config ? (
                  <>
                    <div className="flex justify-between items-center">
                        <span className="text-slate-500">{config.refLabel}:</span>
                        <span className="font-mono text-sm text-slate-600 bg-slate-200 px-2 py-0.5 rounded">{bankDetails.reference}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-slate-500">{config.pinLabel}:</span>
                        <span className="font-mono text-sm text-slate-600 bg-slate-200 px-2 py-0.5 rounded">{'•'.repeat(bankDetails.pin.length)}</span>
                    </div>
                  </>
                ) : (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500">Voucher Code:</span>
                    <span className="font-mono text-sm text-slate-600 bg-slate-200 px-2 py-0.5 rounded">{voucherCode}</span>
                  </div>
                )}
                
                <div className="flex justify-between border-t border-slate-200 mt-2 pt-2"><span className="text-slate-500 font-semibold">Value:</span><span className="font-bold text-xl text-teal-600">{formatCurrency(selectedPartner.voucherValue)}</span></div>
             </div>
             <div className="flex gap-2 mt-6">
                <button type="button" onClick={handleBack} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
                <button onClick={handleConfirmAndRedeem} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Confirm & Redeem</button>
            </div>
        </div>
    );
  };

  const renderStatus = () => (
    <div>
        <StatusDisplay 
            status={status}
            message={message}
            voucherValue={redeemedValue}
            valueLabel={successMessage ? "PAY CUSTOMER (CASH)" : undefined}
        />
        {status === 'error' && (
             <button onClick={resetFlow} className="w-full mt-4 px-4 py-3 text-base font-bold text-teal-700 bg-teal-100 rounded-lg hover:bg-teal-200">
                Start Over
            </button>
        )}
    </div>
  );

  const renderContent = () => {
    switch (step) {
      case 'select_partner': return renderPartnerSelection();
      case 'enter_details': return renderDetailsEntry();
      case 'confirm': return renderConfirmation();
      case 'status': return renderStatus();
      default: return null;
    }
  };

  const steps = ['Method', 'Details', 'Confirm'];
  const currentStepIndex = step === 'select_partner' ? 0 : step === 'enter_details' ? 1 : 2;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg w-full animate-scaleIn">
        {step !== 'select_partner' && (
             <div className="mb-6">
                <StepIndicator steps={steps} currentStep={currentStepIndex} />
             </div>
        )}
        {step === 'status' && !selectedPartner && <div className="hidden"><StepIndicator steps={steps} currentStep={3} /></div>}
      {renderContent()}
    </div>
  );
};

export default CashInFlow;