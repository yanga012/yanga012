
import React from 'react';

const SkeletonItem: React.FC = () => (
  <li className="flex items-center justify-between py-4 border-b border-slate-100 last:border-b-0 px-2 -mx-2">
    <div className="flex items-center gap-4">
      <div className="h-6 w-6 rounded-full bg-slate-200 animate-pulse flex-shrink-0" />
      <div>
        <div className="h-4 w-32 bg-slate-200 rounded animate-pulse" />
        <div className="h-3 w-24 bg-slate-200 rounded animate-pulse mt-2" />
      </div>
    </div>
    <div className="h-6 w-20 bg-slate-200 rounded animate-pulse" />
  </li>
);

const TransactionHistorySkeleton: React.FC<{ count?: number }> = ({ count = 3 }) => (
  <ul className="animate-pulse">
    {Array.from({ length: count }).map((_, index) => (
      <SkeletonItem key={index} />
    ))}
  </ul>
);

export default TransactionHistorySkeleton;
