
import React from 'react';

const TransactionChartSkeleton: React.FC = () => (
  <div className="animate-pulse">
    <div className="mt-4 h-48 flex items-end justify-around gap-2 p-4 border-b border-slate-200 bg-slate-50 rounded-lg">
      <div className="w-full bg-slate-200 rounded-t-md" style={{ height: '40%' }} />
      <div className="w-full bg-slate-200 rounded-t-md" style={{ height: '70%' }} />
      <div className="w-full bg-slate-200 rounded-t-md" style={{ height: '30%' }} />
      <div className="w-full bg-slate-200 rounded-t-md" style={{ height: '55%' }} />
      <div className="w-full bg-slate-200 rounded-t-md" style={{ height: '80%' }} />
      <div className="w-full bg-slate-200 rounded-t-md" style={{ height: '60%' }} />
      <div className="w-full bg-slate-200 rounded-t-md" style={{ height: '45%' }} />
    </div>
    <div className="h-8 flex justify-around gap-2 px-4">
      {Array.from({ length: 7 }).map((_, index) => (
        <div key={index} className="flex-1 pt-2">
            <div className="h-3 w-10 bg-slate-200 rounded mx-auto" />
        </div>
      ))}
    </div>
  </div>
);

export default TransactionChartSkeleton;
