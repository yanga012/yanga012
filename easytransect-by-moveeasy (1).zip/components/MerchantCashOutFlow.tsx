// Fix: Import 'useRef' from 'react' to fix the 'Cannot find name' error.
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { processCustomerCashOut } from '../services/api';
import type { Status, Transaction, User } from '../types';
import { formatCurrency } from '../types';
import StatusDisplay from './StatusDisplay';
import CameraIcon from './icons/CameraIcon';
import StepIndicator from './StepIndicator';

interface MerchantCashOutFlowProps {
  user: User;
  onPaymentSuccess: (transaction: Transaction) => void;
  onBack: () => void;
}

type Step = 'details' | 'scan_customer' | 'confirm' | 'status';

const MOCK_CUSTOMER_DATA = { id: 'cust-abc-456', name: 'Jane Customer' };

const MerchantCashOutFlow: React.FC<MerchantCashOutFlowProps> = ({ user, onPaymentSuccess, onBack }) => {
  const [step, setStep] = useState<Step>('details');
  const [amount, setAmount] = useState<number | ''>('');
  const [customer, setCustomer] = useState<{id: string, name: string} | null>(null);
  
  const [status, setStatus] = useState<Status>('idle');
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [transactionValue, setTransactionValue] = useState(0);

  const videoRef = useRef<HTMLVideoElement>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const stopCamera = useCallback(() => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  }, []);

  const startCamera = useCallback(async () => {
    setCameraError(null);
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        setCameraError("Could not access camera. Please check permissions and try again.");
      }
    } else {
      setCameraError("Camera not supported on this device.");
    }
  }, []);

  useEffect(() => {
    if (step === 'scan_customer') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [step, startCamera, stopCamera]);

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount === '' || amount <= 0) {
      setError('Please enter a valid amount.');
      return;
    }
    setError(null);
    setStep('scan_customer');
  };

  const handleSimulateScan = () => {
    setCustomer(MOCK_CUSTOMER_DATA);
    setStep('confirm');
  };

  const handleConfirmPayout = async () => {
    if (!customer || amount === '') return;

    setStatus('loading');
    setMessage('Processing payout...');
    setStep('status');

    try {
      const newTransaction = await processCustomerCashOut(user.id, customer, amount);
      setTransactionValue(newTransaction.amount);
      setStatus('success');
      setMessage('Payout successful! Please pay customer cash.');
      setTimeout(() => {
        onPaymentSuccess(newTransaction);
      }, 2500);
    } catch (err: any) {
      setStatus('error');
      setMessage(err.message || 'An unexpected error occurred.');
    }
  };
  
  const resetFlow = () => {
    setStep('details');
    setAmount('');
    setCustomer(null);
    setStatus('idle');
    setError(null);
  }

  const renderStepContent = () => {
    switch (step) {
      case 'details':
        return (
          <form onSubmit={handleDetailsSubmit}>
            <h3 className="text-lg font-bold text-slate-800 mb-6 text-center">Enter Cash Out Details</h3>
            <div className="space-y-4">
              <div>
                <label htmlFor="amount" className="text-sm font-medium text-slate-700">Amount Customer is Withdrawing</label>
                <input id="amount" type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} placeholder="0.00" required className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors" />
              </div>
            </div>
            {error && <p className="mt-4 text-center text-sm text-red-600">{error}</p>}
            <div className="flex gap-2 mt-6">
              <button type="button" onClick={onBack} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
              <button type="submit" className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Continue</button>
            </div>
          </form>
        );

      case 'scan_customer':
        return (
          <div className="text-center">
            <h3 className="text-lg font-bold text-slate-800 mb-2">Scan Customer QR Code</h3>
            <p className="text-sm text-slate-500 mb-4">Ask the customer to show their QR code from the MoveEasy app.</p>
            <div className="relative w-full max-w-sm mx-auto aspect-square bg-slate-900 rounded-lg overflow-hidden mb-4 shadow-inner">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none" aria-hidden="true">
                <div className="w-[70%] h-[70%] border-4 border-white/50 border-dashed rounded-lg" />
              </div>
              {cameraError && <div className="absolute inset-0 flex items-center justify-center bg-black/70"><p className="text-white text-center p-4">{cameraError}</p></div>}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setStep('details')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
              <button onClick={handleSimulateScan} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 flex items-center justify-center gap-2">
                  <CameraIcon className="w-5 h-5" /> Simulate Scan
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-3">(Scanning is simulated in this demo)</p>
          </div>
        );

      case 'confirm':
        if (!customer) return null;
        return (
          <div className="text-center">
            <h3 className="text-lg font-bold text-slate-800 mb-6">Confirm Cash Payout</h3>
            <div className="bg-slate-50 p-4 rounded-lg space-y-2 text-left mb-6">
              <div className="flex justify-between"><span className="text-slate-500">Amount:</span><span className="font-semibold text-slate-800">{formatCurrency(Number(amount))}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">To Customer:</span><span className="font-semibold text-slate-800">{customer.name}</span></div>
            </div>
             <p className="text-xs text-slate-500 mb-6">Confirming will deduct {formatCurrency(Number(amount))} from the customer's wallet and credit your merchant wallet. You must then give the customer cash.</p>
            <div className="flex gap-2 mt-6">
              <button type="button" onClick={() => setStep('scan_customer')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
              <button onClick={handleConfirmPayout} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Confirm & Process</button>
            </div>
          </div>
        );

      case 'status':
        return (
          <div>
            <StatusDisplay 
              status={status}
              message={message}
              voucherValue={transactionValue}
              valueLabel="PAY CUSTOMER (CASH)"
            />
            {status !== 'loading' && (
              <button onClick={resetFlow} className="w-full mt-4 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">
                New Transaction
              </button>
            )}
          </div>
        );

      default: return null;
    }
  };

  const steps = ['Details', 'Scan', 'Confirm'];
  const currentStepIndex = step === 'details' ? 0 : step === 'scan_customer' ? 1 : 2;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg">
       <button onClick={onBack} className="mb-4 text-sm font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
          Back to Services
      </button>
      <div className="mb-6">
        <StepIndicator steps={steps} currentStep={currentStepIndex} />
      </div>
      {renderStepContent()}
    </div>
  );
};

export default MerchantCashOutFlow;
