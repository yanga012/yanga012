


import React, { useState, useEffect } from 'react';
// Fix: Corrected import path for types.
import type { User } from './types';
// Fix: Corrected import path for api service.
import { getSession, signOut } from './services/api';
import Auth from './components/Auth';
// Fix: Corrected import path for Dashboard component.
import Dashboard from './components/Dashboard';
import LoaderIcon from './components/icons/LoaderIcon';
import EmailVerificationHandler from './components/EmailVerificationHandler';
import RoleSelection from './components/RoleSelection';
import MerchantDashboard from './components/MerchantDashboard';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loadingSession, setLoadingSession] = useState(true);
  const [authRole, setAuthRole] = useState<'user' | 'merchant' | null>(null);

  const urlParams = new URLSearchParams(window.location.search);
  const emailForVerification = urlParams.get('email');
  const tokenForVerification = urlParams.get('token');

  useEffect(() => {
    if (emailForVerification && tokenForVerification) {
      setLoadingSession(false);
      return;
    }
    
    const checkSession = async () => {
      try {
        const sessionUser = await getSession();
        setUser(sessionUser);
      } catch (error) {
        // This will now only catch unexpected errors, not the "no session" case.
        console.error("An unexpected error occurred while checking session:", error);
        setUser(null);
      } finally {
        setLoadingSession(false);
      }
    };

    checkSession();
  }, [emailForVerification, tokenForVerification]);

  const handleLogout = async () => {
    await signOut();
    setUser(null);
    setAuthRole(null); // Reset role selection on logout
  };
  
  const handleAuthSuccess = (authedUser: User) => {
    setUser(authedUser);
    setAuthRole(null);
  };

  if (emailForVerification && tokenForVerification) {
    return <EmailVerificationHandler email={emailForVerification} token={tokenForVerification} />;
  }

  if (loadingSession) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoaderIcon className="h-12 w-12 text-teal-600" />
      </div>
    );
  }

  if (user) {
    return user.role === 'merchant' ? (
      <MerchantDashboard user={user} onLogout={handleLogout} />
    ) : (
      <Dashboard user={user} onLogout={handleLogout} />
    );
  }
  
  if (!authRole) {
    return <RoleSelection onSelectRole={setAuthRole} />;
  }
  
  return (
    <Auth
      onAuthSuccess={handleAuthSuccess}
      role={authRole}
      onBack={() => setAuthRole(null)}
    />
  );
};

// Fix: Removed duplicate 'export' keyword.
export default App;