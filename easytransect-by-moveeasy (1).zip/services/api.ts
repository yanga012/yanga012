// Fix: Import GoogleGenAI and Type for AI-powered search.
import { GoogleGenAI, Type } from "@google/genai";
import type { User, Transaction, BankDetails, VoucherPartner } from '../types';
import { formatCurrency } from "../types";

// MOCK DATABASE
const MOCK_USERS: { [email: string]: User & { password_hash: string; verificationToken: string | null; } } = {
  'test@example.com': {
    id: 'user-123',
    email: 'test@example.com',
    password_hash: 'hashed_password',
    balance: 500.75,
    isVerified: true, // This user is pre-verified
    verificationToken: null,
    savedBankDetails: {
      bankName: 'MoveEasy Bank',
      accountNumber: '9876543210',
      branchCode: '654321',
    },
    role: 'user',
  },
  // Added a fully verified test user for easier app testing.
  'tester@moveeasy.app': {
    id: 'user-456',
    email: 'tester@moveeasy.app',
    password_hash: 'password123', // Note: mock auth only checks for password length > 0
    balance: 1250.00,
    isVerified: true,
    verificationToken: null,
    savedBankDetails: {
      bankName: 'Capitec Bank',
      accountNumber: '1234567890',
      branchCode: '470010',
    },
    role: 'user',
  },
  // Added a fully verified merchant user for testing.
  'merchant@moveeasy.app': {
    id: 'merchant-789',
    email: 'merchant@moveeasy.app',
    password_hash: 'password123',
    balance: 10500.00,
    isVerified: true,
    verificationToken: null,
    role: 'merchant',
    businessName: 'The Corner Shop',
  }
};

let MOCK_TRANSACTIONS: Transaction[] = [
    { id: 'txn_1', type: 'redeem', amount: 100, description: '1Voucher Redeem', date: new Date(Date.now() - 86400000 * 5).toISOString() },
    { id: 'txn_2', type: 'payout', amount: 50, description: 'EFT Payout to ABSA', date: new Date(Date.now() - 86400000 * 4).toISOString() },
    { id: 'txn_3', type: 'redeem', amount: 250, description: 'OTT Voucher', date: new Date(Date.now() - 86400000 * 3).toISOString() },
    { id: 'txn_4', type: 'redeem', amount: 75.50, description: 'Blu Voucher', date: new Date(Date.now() - 86400000 * 2).toISOString() },
    { id: 'txn_5', type: 'payout', amount: 120, description: 'PayShap to 0821234567', date: new Date(Date.now() - 86400000 * 1).toISOString() },
];

const MOCK_VOUCHER_PARTNERS: VoucherPartner[] = [
    { id: '1voucher', name: '1Voucher', description: 'Digital prepaid voucher.', exampleCode: '1V-DEMO-100', voucherValue: 100.00, category: 'voucher' },
    { id: 'ott', name: 'OTT Voucher', description: 'Online payment solution.', exampleCode: 'OTT-DEMO-250', voucherValue: 250.00, category: 'voucher' },
    { id: 'blu', name: 'Blu Voucher', description: 'Secure prepaid voucher.', exampleCode: 'BLU-DEMO-75', voucherValue: 75.50, category: 'voucher' },
    { id: 'fnb_ewallet', name: 'FNB eWallet', description: 'Redeem funds sent to your number.', exampleReference: '0821234567', examplePin: '1234', voucherValue: 150.00, category: 'bank' },
    { id: 'absa_cashsend', name: 'Absa CashSend', description: 'Redeem a CashSend voucher.', exampleReference: '1234567890', examplePin: '567890', voucherValue: 200.00, category: 'bank' },
    { id: 'sb_instant_money', name: 'SB Instant Money', description: 'Redeem an Instant Money voucher.', exampleReference: 'SBIM1234567', examplePin: '1122', voucherValue: 120.00, category: 'bank' },
    { id: 'nedbank_mobimoney', name: 'Nedbank MobiMoney', description: 'Redeem a MobiMoney voucher.', exampleReference: 'NEDMM98765', examplePin: '3344', voucherValue: 180.00, category: 'bank' },
];

const SESSION_KEY = 'moveeasy_session';

// API IMPLEMENTATION
export const getSession = async (): Promise<User | null> => {
  const sessionEmail = localStorage.getItem(SESSION_KEY);
  if (!sessionEmail) return null;
  
  const user = MOCK_USERS[sessionEmail];
  if (!user) {
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
  
  const { password_hash, verificationToken, ...userProfile } = user;
  return userProfile;
};

export const getTransactions = async (userId: string): Promise<Transaction[]> => {
    // userId is not used in mock, but would be in a real API
    return Promise.resolve(MOCK_TRANSACTIONS.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
}

export const signIn = async (email: string, password: string): Promise<User> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = MOCK_USERS[email];
      if (user && password.length > 0) { // In real app, compare hashed password
        if (!user.isVerified) {
          return reject(new Error('Please verify your email address before signing in.'));
        }
        localStorage.setItem(SESSION_KEY, email);
        const { password_hash, verificationToken, ...userProfile } = user;
        resolve(userProfile);
      } else {
        reject(new Error('Invalid email or password.'));
      }
    }, 1000);
  });
};

export const signUp = async (email: string, password: string, role: 'user' | 'merchant', businessName?: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (MOCK_USERS[email]) {
                return reject(new Error('An account with this email already exists.'));
            }
            if (password.length < 6) {
                return reject(new Error('Password must be at least 6 characters long.'));
            }
             if (role === 'merchant' && !businessName?.trim()) {
                return reject(new Error('Business name is required for merchant accounts.'));
            }
            
            const token = Math.random().toString(36).substring(2);

            const newUser: User & { password_hash: string; verificationToken: string | null } = {
                id: `${role}-${Date.now()}`,
                email,
                password_hash: 'hashed_' + password,
                balance: 0,
                isVerified: false,
                verificationToken: token,
                role: role,
                businessName: role === 'merchant' ? businessName : undefined,
            };
            MOCK_USERS[email] = newUser;

            // Simulate sending a verification email by logging to console
            const verificationLink = `${window.location.origin}?email=${encodeURIComponent(email)}&token=${token}`;
            console.log("--- EMAIL VERIFICATION SIMULATION ---");
            console.log(`To: ${email}`);
            console.log(`Subject: Verify Your MoveEasy Account`);
            console.log(`Click this link to verify: ${verificationLink}`);
            console.log("-------------------------------------");

            resolve();
        }, 1000);
    });
};

export const signOut = async (): Promise<void> => {
    localStorage.removeItem(SESSION_KEY);
};

export const getVoucherPartners = async (): Promise<VoucherPartner[]> => {
    return new Promise(resolve => {
        setTimeout(() => resolve(MOCK_VOUCHER_PARTNERS), 500);
    });
};

export const redeemVoucher = async (details: { code?: string, reference?: string, pin?: string }, partnerId: string): Promise<Transaction> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const sessionEmail = localStorage.getItem(SESSION_KEY);
            if (!sessionEmail || !MOCK_USERS[sessionEmail]) {
                return reject(new Error('User not authenticated.'));
            }

            const partner = MOCK_VOUCHER_PARTNERS.find(p => p.id === partnerId);
            if (!partner) {
                return reject(new Error('Invalid voucher partner selected.'));
            }

            if (partner.category === 'voucher') {
                if (details.code?.toUpperCase() !== partner.exampleCode?.toUpperCase()) {
                    return reject(new Error('This voucher code is invalid or has expired.'));
                }
            } else if (partner.category === 'bank') {
                if (details.reference !== partner.exampleReference || details.pin !== partner.examplePin) {
                    return reject(new Error('The reference number or PIN is incorrect.'));
                }
            } else {
                 return reject(new Error('Invalid partner type for redemption.'));
            }
            
            const amount = partner.voucherValue;
            const newTransaction: Transaction = {
                id: `txn-${Date.now()}`,
                type: 'redeem',
                amount,
                description: `${partner.name} Redeem`,
                date: new Date().toISOString(),
            };
            MOCK_TRANSACTIONS.push(newTransaction);
            MOCK_USERS[sessionEmail].balance += amount;
            resolve(newTransaction);
        }, 1500);
    });
};

export const requestPayout = async (amount: number, method: 'eft' | 'payshap' | 'fnb_ewallet' | 'absa_cashsend' | 'sb_instant_money' | 'nedbank_mobimoney', details: BankDetails | string, saveDetails?: boolean): Promise<Transaction> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const sessionEmail = localStorage.getItem(SESSION_KEY);
            if (!sessionEmail || !MOCK_USERS[sessionEmail]) {
                return reject(new Error('User not authenticated.'));
            }
            const user = MOCK_USERS[sessionEmail];

            if (!user.isVerified) {
                return reject(new Error('User must be verified to perform payouts.'));
            }
            if (user.balance < amount) {
                return reject(new Error('Insufficient balance for this payout.'));
            }
            
            if (method === 'eft' && saveDetails) {
                user.savedBankDetails = details as BankDetails;
            }

            let description = '';
            switch (method) {
                case 'eft':
                    description = `EFT Payout to ${(details as BankDetails).bankName}`;
                    break;
                case 'payshap':
                    description = `PayShap to ${details as string}`;
                    break;
                case 'fnb_ewallet':
                    description = `FNB eWallet to ${details as string}`;
                    break;
                case 'absa_cashsend':
                    description = `Absa CashSend to ${details as string}`;
                    break;
                case 'sb_instant_money':
                    description = `SB Instant Money to ${details as string}`;
                    break;
                case 'nedbank_mobimoney':
                    description = `Nedbank MobiMoney to ${details as string}`;
                    break;
                default:
                    description = `Payout to ${details}`;
            }

            const newTransaction: Transaction = {
                id: `txn-${Date.now()}`,
                type: 'payout',
                amount,
                description,
                date: new Date().toISOString(),
            };
            MOCK_TRANSACTIONS.push(newTransaction);
            user.balance -= amount;
            resolve(newTransaction);
        }, 2000);
    });
};

export const verifyUserAccount = async (email: string, token: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = Object.values(MOCK_USERS).find(u => u.email === email);
            
            if (!user) {
                return reject(new Error('Verification failed. User not found.'));
            }
            if (user.isVerified) {
                return reject(new Error('This account has already been verified.'));
            }
            if (user.verificationToken !== token) {
                return reject(new Error('Invalid verification token. Please try again.'));
            }

            // Success! Verify the user.
            user.isVerified = true;
            user.verificationToken = null;
            resolve();
        }, 2000);
    });
};

export const performIdentityVerification = async (userId: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = Object.values(MOCK_USERS).find(u => u.id === userId);
            if (user) {
                user.isVerified = true;
                resolve();
            } else {
                reject(new Error("User not found for verification."));
            }
        }, 1500); // Simulate network latency for verification process
    });
};

export const validateBankAccount = async (bankName: string, accountNumber: string): Promise<{ success: boolean }> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Mock validation logic
            if (!bankName.trim() || !accountNumber.trim()) {
                return reject(new Error("Bank name and account number are required."));
            }
            if (/\D/.test(accountNumber)) {
                return reject(new Error("Account number must only contain digits."));
            }
            if (accountNumber.length < 8 || accountNumber.length > 15) {
                return reject(new Error("Please enter a valid account number (8-15 digits)."));
            }
            if (bankName.toLowerCase().includes("invalid")) {
                 return reject(new Error("The provided bank name is not supported."));
            }
            // Simulate a successful validation
            resolve({ success: true });
        }, 1500); // Simulate network latency
    });
};

export const processCustomerCashOut = async (merchantId: string, customerInfo: { id: string, name: string }, amount: number): Promise<Transaction> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const sessionEmail = localStorage.getItem(SESSION_KEY);
            if (!sessionEmail || !MOCK_USERS[sessionEmail]) {
                return reject(new Error('User not authenticated.'));
            }
            const merchant = MOCK_USERS[sessionEmail];

            if (merchant.id !== merchantId || merchant.role !== 'merchant') {
                return reject(new Error('Merchant validation failed.'));
            }
            
            // In a real app, we'd find the customer and deduct from their balance.
            // Here, we just simulate it.
            console.log(`Simulating deduction of ${formatCurrency(amount)} from customer ${customerInfo.name}'s wallet.`);
            
            // We credit the merchant's account
            merchant.balance += amount;

            const newTransaction: Transaction = {
                id: `txn-cashout-${Date.now()}`,
                type: 'redeem', // It's a credit for the merchant
                amount: amount,
                description: `Cash payout to ${customerInfo.name}`,
                date: new Date().toISOString(),
            };
            MOCK_TRANSACTIONS.push(newTransaction);
            resolve(newTransaction);
        }, 2000);
    });
};


// Fix: Initialize the GoogleGenAI client according to the guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const searchTransactionsWithAI = async (query: string, transactions: Transaction[]): Promise<string[]> => {
  const model = 'gemini-2.5-flash';

  const prompt = `
    You are an intelligent transaction search assistant.
    Analyze the following list of transactions and the user's search query.
    Return a JSON array containing only the 'id' strings of the transactions that match the query.
    The query might be a natural language description (e.g., "all my payouts", "vouchers from last week", "transactions over R100").
    Base your filtering on the 'type', 'amount', 'description', and 'date' fields.
    Today's date is ${new Date().toISOString()}.

    User Query: "${query}"

    Transactions:
    ${JSON.stringify(transactions.map(({isNew, ...rest}) => rest), null, 2)}

    Return only the JSON array of matching transaction IDs.
  `;
  
  try {
    // Fix: Call generateContent with the model, contents, and a JSON config.
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING,
          }
        },
      }
    });

    // Fix: Access the 'text' property on the response to get the JSON string.
    const jsonStr = response.text;
    if (!jsonStr) {
      return [];
    }

    const matchingIds = JSON.parse(jsonStr.trim());
    if (Array.isArray(matchingIds) && matchingIds.every(id => typeof id === 'string')) {
      return matchingIds;
    } else {
      throw new Error("AI returned data in an unexpected format.");
    }

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("AI search failed. Please try a different query or check your connection.");
  }
};