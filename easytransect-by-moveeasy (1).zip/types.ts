// Defines the core data structures used throughout the application.

export interface User {
  id: string;
  email: string;
  balance: number;
  isVerified: boolean;
  role: 'user' | 'merchant';
  businessName?: string;
  savedBankDetails?: BankDetails;
}

export interface Transaction {
  id: string;
  type: 'redeem' | 'payout';
  amount: number;
  description: string;
  date: string; // ISO string format
  isNew?: boolean;
}

export type Status = 'idle' | 'loading' | 'success' | 'error';

export interface BankDetails {
  bankName: string;
  accountNumber: string;
  branchCode: string;
}

export interface VoucherPartner {
  id: string;
  name: string;
  description: string;
  exampleCode?: string; // For simple vouchers
  exampleReference?: string; // For bank mobile money
  examplePin?: string; // For bank mobile money
  voucherValue: number;
  category: 'voucher' | 'bank';
}

/**
 * Formats a number as a string with a "R" prefix, thousand separators, and two decimal places.
 * e.g., 1234.5 becomes "R1,234.50"
 * @param amount - The number to format.
 * @returns A string representing the formatted currency.
 */
export const formatCurrency = (amount: number): string => {
  // Use en-US locale for comma separators for thousands and dot for decimal.
  const formattedAmount = amount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `R${formattedAmount}`;
};