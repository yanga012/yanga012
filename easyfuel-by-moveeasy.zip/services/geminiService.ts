import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this example, we'll alert the user and throw an error.
  alert("API_KEY is not set. Please ensure your environment variables are configured correctly.");
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const findNearbyStations = async (
  stationName: string,
  location: { latitude: number; longitude: number }
) => {
  const prompt = `Find ${stationName} fuel stations near me. List their names and addresses.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: {
              latitude: location.latitude,
              longitude: location.longitude,
            },
          },
        },
      },
    });

    const text = response.text;
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    return { text, groundingChunks };
  } catch (error) {
    console.error("Error finding nearby stations:", error);
    // Provide a more user-friendly error message
    if (error instanceof Error && error.message.includes('API key not valid')) {
       throw new Error("The API key is invalid. Please check your configuration.");
    }
    throw new Error("Could not fetch nearby stations. Please try again later.");
  }
};

export const generateImage = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: '1:1',
        },
    });

    if (!response.generatedImages || response.generatedImages.length === 0) {
        throw new Error("No image was generated. The prompt may have been rejected.");
    }
    
    const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
    const imageUrl = `data:image/png;base64,${base64ImageBytes}`;
    return imageUrl;
  } catch (error) {
    console.error("Error generating image:", error);
    if (error instanceof Error && error.message.includes('API key not valid')) {
       throw new Error("The API key is invalid. Please check your configuration.");
    }
    throw new Error("Could not generate image. The prompt may be unsafe or the service is unavailable.");
  }
};
