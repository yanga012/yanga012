import { GoogleGenAI, Type } from "@google/genai";
import type { User, Transaction, BankDetails, VoucherPartner, KycDetails } from '../types';
import { formatCurrency } from '../types';

const TRANSACTIONS_STORAGE_KEY = 'easyfuel_transactions';

type MockDbUser = User & { 
    password_hash: string; 
    verificationToken: string | null;
    phoneOtp: string | null;
    phoneOtpExpiry: Date | null;
};

// MOCK DATABASE
const MOCK_USERS: { [email: string]: MockDbUser } = {
  'test@example.com': {
    id: 'user-123',
    email: 'test@example.com',
    password_hash: 'hashed_password',
    balance: 500.75,
    outstandingBalance: 533.33,
    isVerified: true,
    isPhoneVerified: true,
    isKycVerified: true,
    phoneNumber: '+27821234567',
    verificationToken: null,
    phoneOtp: null,
    phoneOtpExpiry: null,
    savedBankDetails: {
      bankName: 'MoveEasy Bank',
      accountNumber: '9876543210',
      branchCode: '654321',
    }
  },
  'tester@moveeasy.app': {
    id: 'user-456',
    email: 'tester@moveeasy.app',
    password_hash: 'password123',
    balance: 1250.00,
    outstandingBalance: 0,
    isVerified: true,
    isPhoneVerified: true,
    isKycVerified: false,
    phoneNumber: '+27837654321',
    verificationToken: null,
    phoneOtp: null,
    phoneOtpExpiry: null,
    savedBankDetails: {
      bankName: 'Capitec Bank',
      accountNumber: '1234567890',
      branchCode: '470010',
    }
  },
};

// Load transactions from localStorage or use mock data for the first time.
let MOCK_TRANSACTIONS: Transaction[] = [];
try {
  const storedTransactions = localStorage.getItem(TRANSACTIONS_STORAGE_KEY);
  if (storedTransactions) {
    MOCK_TRANSACTIONS = JSON.parse(storedTransactions);
  } else {
    // Default data for first-time users
    MOCK_TRANSACTIONS = [
      { id: 'txn_1', type: 'redeem', amount: 300, description: '1Voucher Redeem', date: new Date(Date.now() - 86400000 * 5).toISOString() },
      { id: 'txn_2', type: 'purchase', amount: 250, description: 'Engen Fuel Voucher', date: new Date(Date.now() - 86400000 * 4).toISOString(), status: 'used' },
      { id: 'txn_3', type: 'redeem', amount: 500, description: 'OTT Voucher', date: new Date(Date.now() - 86400000 * 3).toISOString() },
      { id: 'txn_flex_1', type: 'purchase', amount: 800, description: 'Shell FuelFlex Voucher', date: new Date(Date.now() - 86400000 * 2.5).toISOString(), status: 'used', isFlex: true },
      { id: 'txn_4', type: 'purchase', amount: 400, description: 'Shell V-Power', date: new Date(Date.now() - 86400000 * 2).toISOString(), status: 'active' },
      { id: 'txn_5', type: 'purchase', amount: 150, description: 'BP Fuel Voucher', date: new Date(Date.now() - 86400000 * 1).toISOString(), status: 'used' },
    ];
    localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(MOCK_TRANSACTIONS));
  }
} catch (error) {
  console.error("Could not initialize transactions from localStorage", error);
   MOCK_TRANSACTIONS = [];
}

const _saveTransactions = () => {
    try {
        const transactionsToSave = MOCK_TRANSACTIONS.map(
            ({ isNew, ...persistentData }) => persistentData
        );
        localStorage.setItem(TRANSACTIONS_STORAGE_KEY, JSON.stringify(transactionsToSave));
    } catch (error) {
        console.error("Failed to save transactions to localStorage", error);
    }
};

const MOCK_VOUCHER_PARTNERS: VoucherPartner[] = [
    { id: '1voucher', name: '1Voucher', description: 'Digital prepaid voucher.', exampleCode: '1V-DEMO-100', voucherValue: 100.00, category: 'voucher' },
    { id: 'ott', name: 'OTT Voucher', description: 'Online payment solution.', exampleCode: 'OTT-DEMO-250', voucherValue: 250.00, category: 'voucher' },
    { id: 'blu', name: 'Blu Voucher', description: 'Secure prepaid voucher.', exampleCode: 'BLU-DEMO-75', voucherValue: 75.50, category: 'voucher' },
    { id: 'fnb_ewallet', name: 'FNB eWallet', description: 'Redeem funds sent to your number.', exampleReference: '0821234567', examplePin: '1234', voucherValue: 150.00, category: 'bank' },
    { id: 'absa_cashsend', name: 'Absa CashSend', description: 'Redeem a CashSend voucher.', exampleReference: '1234567890', examplePin: '567890', voucherValue: 200.00, category: 'bank' },
];

const SESSION_KEY = 'moveeasy_session';

const _cleanUserForFrontend = (dbUser: MockDbUser): User => {
    const { password_hash, verificationToken, phoneOtp, phoneOtpExpiry, ...userProfile } = dbUser;
    return userProfile;
};

// --- FuelFlex Constants ---
export const FULL_TANK_VALUE = 800;
export const UPFRONT_PAYMENT = FULL_TANK_VALUE / 3;
export const DEFERRED_PAYMENT = FULL_TANK_VALUE - UPFRONT_PAYMENT;
export const MAX_FLEX_VOUCHERS = 3;

// API IMPLEMENTATION
export const getSession = async (): Promise<User | null> => {
  const sessionEmail = localStorage.getItem(SESSION_KEY);
  if (!sessionEmail) return null;
  
  const user = MOCK_USERS[sessionEmail];
  if (!user) {
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
  
  return _cleanUserForFrontend(user);
};

export const getTransactions = async (userId: string): Promise<Transaction[]> => {
    return Promise.resolve([...MOCK_TRANSACTIONS].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
}

export const addTransaction = async (transaction: Transaction): Promise<Transaction> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            MOCK_TRANSACTIONS.unshift(transaction);
            _saveTransactions();
            resolve(transaction);
        }, 300);
    });
};

export const getPurchaseTransactionCount = async (userId: string): Promise<number> => {
    const purchaseTransactions = MOCK_TRANSACTIONS.filter(tx => tx.type === 'purchase');
    return Promise.resolve(purchaseTransactions.length);
};

export const updateTransaction = async (transactionId: string, updates: Partial<Transaction>): Promise<Transaction> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const txIndex = MOCK_TRANSACTIONS.findIndex(tx => tx.id === transactionId);
            if (txIndex === -1) {
                return reject(new Error('Transaction not found to update.'));
            }
            const updatedTx = { ...MOCK_TRANSACTIONS[txIndex], ...updates };
            MOCK_TRANSACTIONS[txIndex] = updatedTx;
            _saveTransactions();
            resolve(updatedTx);
        }, 300);
    });
};

export const markVoucherAsUsed = async (transactionId: string): Promise<Transaction> => {
    return updateTransaction(transactionId, { status: 'used' });
};


export const signIn = async (email: string, password: string): Promise<User> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = MOCK_USERS[email];
      if (user && password.length > 0) {
        if (!user.isVerified) {
          return reject(new Error('Please verify your email address before signing in.'));
        }
        localStorage.setItem(SESSION_KEY, email);
        resolve(_cleanUserForFrontend(user));
      } else {
        reject(new Error('Invalid email or password.'));
      }
    }, 1000);
  });
};

export const signUp = async (email: string, password: string, phoneNumber: string): Promise<void> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (MOCK_USERS[email]) {
                return reject(new Error('An account with this email already exists.'));
            }
            if (password.length < 6) {
                return reject(new Error('Password must be at least 6 characters long.'));
            }
            if (!/^\+?[1-9]\d{1,14}$/.test(phoneNumber)) {
                return reject(new Error('Please enter a valid phone number.'));
            }
            
            const emailToken = Math.random().toString(36).substring(2);
            const phoneOtp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP

            const newUser: MockDbUser = {
                id: `user-${Date.now()}`,
                email,
                password_hash: 'hashed_' + password,
                balance: 0,
                outstandingBalance: 0,
                phoneNumber,
                isVerified: false,
                isPhoneVerified: false,
                isKycVerified: false,
                verificationToken: emailToken,
                phoneOtp,
                phoneOtpExpiry: new Date(Date.now() + 10 * 60 * 1000), // OTP expires in 10 minutes
            };
            MOCK_USERS[email] = newUser;

            // Simulate sending a verification email
            const verificationLink = `${window.location.origin}?email=${encodeURIComponent(email)}&token=${emailToken}`;
            console.log("--- EMAIL VERIFICATION SIMULATION ---");
            console.log(`To: ${email}`);
            console.log(`Click this link to verify: ${verificationLink}`);
            console.log("-------------------------------------");

            // Simulate sending an SMS with OTP
            console.log("--- PHONE VERIFICATION (SMS) SIMULATION ---");
            console.log(`To: ${phoneNumber}`);
            console.log(`Your MoveEasy verification code is: ${phoneOtp}`);
            console.log("-----------------------------------------");

            resolve();
        }, 1000);
    });
};

export const signOut = async (): Promise<void> => {
    localStorage.removeItem(SESSION_KEY);
};

export const getVoucherPartners = async (): Promise<VoucherPartner[]> => {
    return new Promise(resolve => {
        setTimeout(() => resolve(MOCK_VOUCHER_PARTNERS), 500);
    });
};

export const redeemVoucher = async (details: { code?: string, reference?: string, pin?: string }, partnerId: string): Promise<Transaction> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const sessionEmail = localStorage.getItem(SESSION_KEY);
            if (!sessionEmail || !MOCK_USERS[sessionEmail]) {
                return reject(new Error('User not authenticated.'));
            }
            const partner = MOCK_VOUCHER_PARTNERS.find(p => p.id === partnerId);
            if (!partner) {
                return reject(new Error('Invalid voucher partner selected.'));
            }
            if (partner.category === 'voucher') {
                if (details.code?.toUpperCase() !== partner.exampleCode?.toUpperCase()) {
                    return reject(new Error('This voucher code is invalid or has expired.'));
                }
            } else if (partner.category === 'bank') {
                if (details.reference !== partner.exampleReference || details.pin !== partner.examplePin) {
                    return reject(new Error('The reference number or PIN is incorrect.'));
                }
            } else {
                 return reject(new Error('Invalid partner type for redemption.'));
            }
            
            const amount = partner.voucherValue;
            const newTransaction: Transaction = {
                id: `txn-${Date.now()}`,
                type: 'redeem',
                amount,
                description: `${partner.name} Redeem`,
                date: new Date().toISOString(),
            };
            MOCK_TRANSACTIONS.unshift(newTransaction);
            MOCK_USERS[sessionEmail].balance += amount;
            _saveTransactions();
            resolve(newTransaction);
        }, 1500);
    });
};

export const processAddFunds = async (userId: string, amount: number): Promise<{ newBalance: number; transaction: Transaction; }> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const userEmail = Object.keys(MOCK_USERS).find(key => MOCK_USERS[key].id === userId);
            if (!userEmail) {
                return reject(new Error("User not found. Could not process funds."));
            }
            if (amount > 5000) {
                return reject(new Error("Transaction limit exceeded. Max R 5,000."));
            }
            if (amount < 50) {
                return reject(new Error("Minimum amount to add is R 50."));
            }
            const user = MOCK_USERS[userEmail];
            user.balance += amount;
            const newTransaction: Transaction = {
                id: `txn-add-${Date.now()}`,
                type: 'redeem',
                amount,
                description: `Wallet Top-up`,
                date: new Date().toISOString(),
            };
            MOCK_TRANSACTIONS.unshift(newTransaction);
            _saveTransactions();
            
            resolve({ newBalance: user.balance, transaction: newTransaction });
        }, 1500);
    });
};

export const verifyUserAccount = async (email: string, token: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = MOCK_USERS[email];
            if (!user) {
                return reject(new Error('Verification failed. User not found.'));
            }
            if (user.isVerified) {
                // If already verified, just sign them in.
                localStorage.setItem(SESSION_KEY, email);
                return resolve(_cleanUserForFrontend(user));
            }
            if (user.verificationToken !== token) {
                return reject(new Error('Invalid verification token. Please try again.'));
            }
            user.isVerified = true;
            user.verificationToken = null;
            // Automatically sign in the user after successful email verification
            localStorage.setItem(SESSION_KEY, email);
            resolve(_cleanUserForFrontend(user));
        }, 2000);
    });
};

export const verifyPhoneNumber = async (userId: string, otp: string): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = Object.values(MOCK_USERS).find(u => u.id === userId);
            if (!user) {
                return reject(new Error("User not found."));
            }
            if (new Date() > user.phoneOtpExpiry!) {
                return reject(new Error("OTP has expired. Please request a new one."));
            }
            if (user.phoneOtp !== otp) {
                return reject(new Error("Invalid OTP. Please try again."));
            }
            user.isPhoneVerified = true;
            user.phoneOtp = null;
            user.phoneOtpExpiry = null;

            resolve(_cleanUserForFrontend(user));
        }, 1500);
    });
};

export const submitKycData = async (userId: string, kycData: KycDetails): Promise<User> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = Object.values(MOCK_USERS).find(u => u.id === userId);
            if (user) {
                user.isKycVerified = true;
                user.kycDetails = kycData;
                const userEmail = Object.keys(MOCK_USERS).find(key => MOCK_USERS[key].id === userId);
                if (userEmail) {
                    MOCK_USERS[userEmail] = { ...MOCK_USERS[userEmail], isKycVerified: true, kycDetails: kycData };
                }
                resolve(_cleanUserForFrontend(user));
            } else {
                reject(new Error("User not found for KYC submission."));
            }
        }, 2000);
    });
};

export const getFlexVouchers = async (userId: string): Promise<Transaction[]> => {
    // In a real app, this would be a specific query for the user.
    // Here we just filter all mock transactions.
    return Promise.resolve(MOCK_TRANSACTIONS.filter(tx => tx.type === 'purchase' && tx.isFlex));
};

export const activateFuelFlexVoucher = async (userId: string, stationId: string, stationName: string): Promise<{ newUser: User; newTransaction: Transaction; }> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const user = Object.values(MOCK_USERS).find(u => u.id === userId);
            if (!user) return reject(new Error("User not found."));

            const existingFlexVouchers = MOCK_TRANSACTIONS.filter(tx => tx.type === 'purchase' && tx.isFlex).length;
            if (existingFlexVouchers >= MAX_FLEX_VOUCHERS) {
                return reject(new Error("You have already activated the maximum number of Flex Vouchers."));
            }

            if (user.balance < UPFRONT_PAYMENT) {
                return reject(new Error(`Insufficient balance. You need at least ${formatCurrency(UPFRONT_PAYMENT)} to activate.`));
            }

            user.balance -= UPFRONT_PAYMENT;
            user.outstandingBalance = (user.outstandingBalance || 0) + DEFERRED_PAYMENT;

            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + 90); // 90-day expiry

            const newTransaction: Transaction = {
                id: `txn-flex-${Date.now()}`,
                type: 'purchase',
                amount: FULL_TANK_VALUE,
                description: `${stationName} FuelFlex Voucher`,
                date: new Date().toISOString(),
                status: 'active',
                isFlex: true,
                expiryDate: expiryDate.toISOString(),
                stationId: stationId,
                qrData: JSON.stringify({
                    voucherId: `FLEX-${Date.now()}`,
                    userId: userId,
                    amount: FULL_TANK_VALUE,
                    timestamp: new Date().toISOString(),
                    paymentType: 'flex-voucher',
                }),
            };
            
            MOCK_TRANSACTIONS.unshift(newTransaction);
            _saveTransactions();

            resolve({ newUser: _cleanUserForFrontend(user), newTransaction });

        }, 1500);
    });
};

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const searchTransactionsWithAI = async (query: string, transactions: Transaction[]): Promise<string[]> => {
  const model = 'gemini-2-pro';
  const prompt = `
    You are an intelligent transaction search assistant for a fuel purchasing app.
    Analyze the following list of transactions and the user's search query.
    Return a JSON array containing only the 'id' strings of the transactions that match the query.
    Transaction types are 'redeem' (adding money to the wallet) and 'purchase' (buying a fuel voucher).
    Voucher purchases have a 'status' of either 'active' or 'used'.
    The query might be a natural language description (e.g., "my shell purchases", "all cash-ins", "active vouchers").
    Base your filtering on the 'type', 'amount', 'description', 'date', and 'status' fields.
    Today's date is ${new Date().toISOString()}.
    User Query: "${query}"
    Transactions:
    ${JSON.stringify(transactions.map(({isNew, ...rest}) => rest), null, 2)}
    Return only the JSON array of matching transaction IDs.
  `;
  
  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING,
          }
        },
      }
    });
    const jsonStr = response.text;
    if (!jsonStr) {
      return [];
    }
    const matchingIds = JSON.parse(jsonStr.trim());
    if (Array.isArray(matchingIds) && matchingIds.every(id => typeof id === 'string')) {
      return matchingIds;
    } else {
      throw new Error("AI returned data in an unexpected format.");
    }
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("AI search failed. Please try a different query or check your connection.");
  }
};