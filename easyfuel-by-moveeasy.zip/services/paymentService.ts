import { Station, PaymentResult } from '../types';
import { ROUTING_CONFIG } from '../constants';

// This function simulates a call to a backend service.
export const processPayment = (station: Station, amount: number, userId: string): Promise<PaymentResult> => {
  return new Promise((resolve, reject) => {
    // Simulate network latency
    setTimeout(() => {
      console.log(`Processing R${amount} payment for ${station.name} for user ${userId}...`);
      
      const adapterType = ROUTING_CONFIG[station.id] || 'payment24';
      const transactionId = `EF-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const timestamp = new Date().toISOString();

      console.log(`Routing via: ${adapterType}`);

      if (adapterType === 'direct') {
        // For direct payments, generate a QR code that acts as a digital receipt.
        const receiptData = {
          receiptId: transactionId,
          userId: userId,
          amount: amount,
          stationId: station.id,
          timestamp,
          paymentType: 'receipt',
        };
        const qrData = JSON.stringify(receiptData);

        resolve({
          type: 'direct',
          transactionId,
          amount,
          qrData,
          message: `Payment of R ${amount.toFixed(2)} to ${station.name} was successful.`,
        });
      } else { // payment24
        // The QR code payload contains all necessary data for a secure transaction.
        const voucherData = {
          voucherId: transactionId,
          userId: userId,
          amount: amount,
          stationId: station.id,
          timestamp,
          paymentType: 'voucher',
        };
        
        const qrData = JSON.stringify(voucherData);

        resolve({
          type: 'voucher',
          transactionId,
          amount,
          qrData: qrData,
          message: `Present this QR code to the cashier at ${station.name}. This is a unique, single-use voucher.`,
        });
      }

      // To simulate an error, uncomment the following line:
      // reject(new Error('Payment gateway is currently unavailable. Please try again later.'));

    }, 2000); // 2-second delay
  });
};
