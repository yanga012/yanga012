// Defines the core data structures used throughout the application.
import type React from 'react';

export interface KycDetails {
  selfieUrl: string;
  idType: 'sa_id' | 'passport';
  idNumber: string;
  idImageUrl: string;
  wantsCredit: boolean;
  addressImageUrl?: string;
  bankAccountImageUrl?: string;
}

export interface User {
  id: string;
  email: string;
  balance: number;
  isVerified: boolean; // email verified
  isPhoneVerified: boolean; // phone number verified
  isKycVerified: boolean; // KYC verified
  phoneNumber: string | null;
  savedBankDetails?: BankDetails;
  kycDetails?: KycDetails;
  outstandingBalance?: number;
}

export interface Transaction {
  id: string;
  type: 'redeem' | 'purchase'; // 'redeem' is Cash In, 'purchase' is buying fuel
  amount: number;
  description: string;
  date: string; // ISO string format
  isNew?: boolean;
  qrData?: string; // For voucher payments
  stationId?: string; // To link back to station info
  qrArtUrl?: string; // URL of the generated QR Art
  tokenId?: string; // Unique ID for the tokenized art
  status?: 'active' | 'used'; // Status for purchase vouchers
  expiryDate?: string; // For vouchers with an expiration
  isFlex?: boolean; // For FuelFlex BNPL vouchers
}

export type Status = 'idle' | 'loading' | 'success' | 'error';

export interface BankDetails {
  bankName: string;
  accountNumber: string;
  branchCode: string;
}

// Represents a fuel station brand
export interface Station {
  id: string;
  name: string;
  logo: React.FC<React.SVGProps<SVGSVGElement>> | string;
}

// Represents the result of a payment attempt
interface BasePaymentResult {
  transactionId: string;
  amount: number;
  message: string;
  qrData: string;
}

export interface DirectPaymentResult extends BasePaymentResult {
  type: 'direct';
}

export interface VoucherPaymentResult extends BasePaymentResult {
  type: 'voucher';
}

export type PaymentResult = DirectPaymentResult | VoucherPaymentResult;

// Represents a completed payment transaction in the user's history
export interface TransactionHistoryItem {
  referenceId: string;
  stationId: string;
  stationName: string;
  amount: number;
  date: string; // ISO string format
  type: 'direct' | 'voucher';
  qrData?: string; // Only for voucher types
  qrArtUrl?: string; // URL of the generated QR Art
  tokenId?: string; // Unique ID for the tokenized art
}

// This is for "Cash In" partners
export interface VoucherPartner {
  id:string;
  name: string;
  description: string;
  exampleCode?: string; // For simple vouchers
  exampleReference?: string; // For bank mobile money
  examplePin?: string; // For bank mobile money
  voucherValue: number;
  category: 'voucher' | 'bank';
}

// Represents fuel brands for purchasing vouchers
export interface FuelPartner {
  id: string;
  name: string;
  description: string;
}

/**
 * Formats a number as a string with a "R" prefix, thousand separators, and two decimal places.
 * e.g., 1234.5 becomes "R1,234.50"
 * @param amount - The number to format.
 * @returns A string representing the formatted currency.
 */
export const formatCurrency = (amount: number): string => {
  // Use en-US locale for comma separators for thousands and dot for decimal.
  const formattedAmount = amount.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `R${formattedAmount}`;
};