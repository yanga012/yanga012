import React, { useRef, useEffect, useState } from 'react';
import LoaderIcon from './icons/LoaderIcon';

interface CameraCaptureProps {
  onCapture: (imageDataUrl: string) => void;
  onClose: () => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user' }
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      } catch (err: any) {
        console.error('Camera access error:', err);
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          setError('Camera permission denied. Please enable it in your browser settings.');
        } else {
          setError('Could not access the camera. It might be in use by another application.');
        }
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleCapture = () => {
    setIsCapturing(true);
    setTimeout(() => { // Gives time for the shutter animation
      if (videoRef.current && canvasRef.current) {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const context = canvas.getContext('2d');
        if (context) {
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
          setCapturedImage(canvas.toDataURL('image/jpeg'));
        }
      }
      setIsCapturing(false);
    }, 150);
  };
  
  const handleRetake = () => {
    setCapturedImage(null);
  };
  
  const handleConfirm = () => {
    if (capturedImage) {
      onCapture(capturedImage);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900 z-50 flex flex-col items-center justify-center p-4 animate-fadeIn">
      <div className="relative w-full max-w-sm aspect-[3/4] bg-black rounded-2xl overflow-hidden shadow-2xl border-2 border-slate-700">
        {error ? (
          <div className="w-full h-full flex flex-col items-center justify-center text-center text-red-300 p-4">
            <p className="font-semibold">Camera Error</p>
            <p className="text-sm mt-2">{error}</p>
          </div>
        ) : (
          <>
            <video ref={videoRef} className={`w-full h-full object-cover ${capturedImage ? 'hidden' : 'block'}`} playsInline autoPlay muted />
            {capturedImage && <img src={capturedImage} alt="Captured selfie" className="w-full h-full object-cover" />}
            <canvas ref={canvasRef} className="hidden" />

            {/* Face Oval Overlay */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-[75%] h-[60%] rounded-[50%] border-4 border-white/50 border-dashed" style={{ boxShadow: '0 0 0 9999px rgba(0,0,0,0.5)' }} />
            </div>
             {isCapturing && <div className="absolute inset-0 bg-white animate-shutter"></div>}
          </>
        )}
      </div>
      {!error && (
        <p className="mt-4 text-slate-300 text-center text-sm max-w-sm">
            Position your face inside the oval and ensure you're in a well-lit area.
        </p>
      )}

      <div className="mt-6 w-full max-w-sm space-y-3">
        {capturedImage ? (
          <div className="grid grid-cols-2 gap-3">
             <button onClick={handleRetake} className="w-full py-3 text-base font-bold text-white bg-slate-700 rounded-lg hover:bg-slate-600">Retake</button>
             <button onClick={handleConfirm} className="w-full py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Confirm Selfie</button>
          </div>
        ) : (
           <button onClick={handleCapture} disabled={!stream} className="w-full h-16 bg-white rounded-full flex items-center justify-center disabled:opacity-50">
                <div className="h-14 w-14 rounded-full border-4 border-slate-800"></div>
           </button>
        )}
        <button onClick={onClose} className="w-full py-3 text-base font-bold text-slate-300 bg-transparent rounded-lg hover:bg-slate-800">Cancel</button>
      </div>
       <style>{`
        @keyframes shutter {
          from { opacity: 0.7; }
          to { opacity: 0; }
        }
        .animate-shutter {
          animation: shutter 0.15s ease-out;
        }
      `}</style>
    </div>
  );
};

export default CameraCapture;
