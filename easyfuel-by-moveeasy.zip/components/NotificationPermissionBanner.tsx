import React, { useState, useEffect } from 'react';

const NotificationPermissionBanner: React.FC = () => {
  const [permission, setPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const handleRequestPermission = async () => {
    if ('Notification' in window) {
      const result = await Notification.requestPermission();
      setPermission(result);
    }
  };

  if (permission !== 'default') {
    return null;
  }

  return (
    <div className="bg-white p-4 rounded-2xl shadow-lg mb-6 flex items-center justify-between gap-4 animate-fadeIn">
      <div>
        <h4 className="font-bold text-slate-800">Stay Updated</h4>
        <p className="text-sm text-slate-600">Enable notifications to get real-time alerts for your transactions.</p>
      </div>
      <button 
        onClick={handleRequestPermission}
        className="px-4 py-2 text-sm font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 flex-shrink-0"
      >
        Enable
      </button>
    </div>
  );
};

export default NotificationPermissionBanner;
