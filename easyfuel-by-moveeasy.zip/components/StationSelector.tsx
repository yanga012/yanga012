import React from 'react';
import { Station } from '../types';
import StationLogo from './StationLogo';

interface StationSelectorProps {
  stations: Station[];
  selectedStation: Station | null;
  onSelect: (station: Station) => void;
  onStartUpload: (station: Station) => void;
}

const StationSelector: React.FC<StationSelectorProps> = ({ stations, selectedStation, onSelect, onStartUpload }) => {
  return (
    <div>
      <h3 className="text-md font-semibold text-slate-600 mb-3 text-center">Select Fuel Station</h3>
      <div className="grid grid-cols-3 gap-4">
        {stations.map((station) => (
          <div key={station.id} className="relative group">
            <button
              onClick={() => onSelect(station)}
              className={`w-full flex flex-col items-center justify-center p-3 rounded-lg transition-all duration-200 aspect-square
                ${selectedStation?.id === station.id 
                  ? 'bg-teal-50 border-2 border-teal-500 scale-105 shadow-lg' 
                  : 'bg-slate-100 hover:bg-slate-200 border-2 border-transparent hover:border-slate-300'
                }`}
            >
              <StationLogo logo={station.logo} stationName={station.name} className="h-10 w-10 object-contain" />
              <span className="text-xs text-slate-700 mt-2 font-medium">{station.name}</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onStartUpload(station)
              }}
              aria-label={`Upload logo for ${station.name}`}
              className="absolute top-1 right-1 p-1 bg-slate-200/80 hover:bg-slate-300 rounded-full text-slate-600 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-opacity"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" />
                <path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StationSelector;