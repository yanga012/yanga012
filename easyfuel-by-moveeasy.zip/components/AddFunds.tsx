import React, { useState } from 'react';
import LoaderIcon from './icons/LoaderIcon';

interface AddFundsProps {
  onAdd: (amount: number) => Promise<void>;
  onClose: () => void;
}

const AddFunds: React.FC<AddFundsProps> = ({ onAdd, onClose }) => {
  const [amount, setAmount] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // This regex provides client-side validation for the amount input.
    // It allows:
    // - An empty string.
    // - Whole numbers (e.g., "123").
    // - Numbers with a decimal point (e.g., "123.").
    // - Numbers with up to two decimal places (e.g., "123.45").
    // It prevents non-numeric characters and more than two decimal places.
    if (/^\d*\.?\d{0,2}$/.test(value)) {
      setAmount(value);
    }
  };

  const handleAddClick = async () => {
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      await onAdd(numericAmount);
      // Parent component handles closing on success
    } catch (err: any) {
      setError(err.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 animate-fade-in" onClick={onClose}></div>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-slate-800 rounded-2xl shadow-2xl p-6 w-full max-w-sm border border-slate-700 animate-slide-up-fast">
          <h2 className="text-xl font-bold text-center text-slate-100 mb-4">Add Funds to Wallet</h2>
          
          <div>
            <label htmlFor="add-amount" className="block text-md font-semibold text-slate-300 mb-2 text-center">
              Enter Amount (ZAR)
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 text-2xl font-bold">R</span>
              <input
                type="text"
                id="add-amount"
                inputMode="decimal"
                value={amount}
                onChange={handleInputChange}
                placeholder="0.00"
                className="w-full bg-slate-700 text-white text-3xl font-bold text-center py-4 rounded-lg border-2 border-slate-600 focus:border-emerald-500 focus:ring-emerald-500 transition-colors"
                autoFocus
                disabled={isLoading}
              />
            </div>
          </div>
          
          {error && (
            <div className="mt-4 p-3 bg-red-900/50 border border-red-500 rounded-lg text-center text-sm text-red-300 animate-fadeIn">
              {error}
            </div>
          )}

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              onClick={onClose}
              disabled={isLoading}
              className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              onClick={handleAddClick}
              disabled={!amount || parseFloat(amount) <= 0 || isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 disabled:bg-slate-600 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {isLoading ? (
                <>
                  <LoaderIcon className="h-5 w-5 mr-2" />
                  Processing...
                </>
              ) : (
                'Add Funds'
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddFunds;