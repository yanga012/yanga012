import React, { useState } from 'react';
import { generateImage } from '../services/geminiService';
import LoaderIcon from './icons/LoaderIcon';
import SparklesIcon from './icons/SparklesIcon';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError('Please enter a description for the image.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setImageUrl(null);
    try {
      const resultUrl = await generateImage(prompt);
      setImageUrl(resultUrl);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg w-full max-w-md mx-auto">
      <h2 className="text-2xl font-bold text-slate-800 text-center mb-1">AI Image Generator</h2>
      <p className="text-sm text-slate-500 text-center mb-4">Describe the image you want to create.</p>
      
      <div className="space-y-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., A futuristic car driving on a rainbow road in space, hyperrealistic"
          className="w-full p-3 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
          rows={3}
          disabled={isLoading}
        />
        <button
          onClick={handleGenerate}
          disabled={isLoading}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 text-lg flex items-center justify-center disabled:bg-slate-400 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <LoaderIcon className="h-6 w-6 mr-2" />
              Generating...
            </>
          ) : (
             <>
              <SparklesIcon className="h-6 w-6 mr-2" />
              Generate Image
            </>
          )}
        </button>
      </div>
      
      {error && (
        <div className="mt-4 p-3 bg-red-100 border border-red-400 rounded-lg text-center text-sm text-red-800 animate-fadeIn">
          {error}
        </div>
      )}

      <div className="mt-6">
        {imageUrl && (
            <div className="animate-fadeIn">
                <h3 className="font-semibold text-slate-700 mb-2 text-center">Result:</h3>
                <img 
                    src={imageUrl} 
                    alt="AI generated image" 
                    className="rounded-lg shadow-md w-full aspect-square object-cover border border-slate-200"
                />
            </div>
        )}
         {!isLoading && !imageUrl && (
            <div className="text-center py-8 text-slate-400 border-2 border-dashed border-slate-300 rounded-lg">
                <p>Your generated image will appear here.</p>
            </div>
         )}
      </div>

    </div>
  );
};

export default ImageGenerator;
