import React, { useState, useRef } from 'react';

interface FileUploadProps {
  label: string;
  onFileSelect: (fileName: string, fileDataUrl: string) => void;
  acceptedFileTypes?: string;
  file: { name: string | null; dataUrl: string | null; };
}

const MAX_FILE_SIZE_MB = 5;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

const FileIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

const FileUpload: React.FC<FileUploadProps> = ({ label, onFileSelect, acceptedFileTypes = "image/png, image/jpeg, image/webp, application/pdf", file }) => {
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const selectedFile = event.target.files?.[0];

    if (selectedFile) {
      if (selectedFile.size > MAX_FILE_SIZE_BYTES) {
        setError(`File is too large. Max size is ${MAX_FILE_SIZE_MB}MB.`);
        onFileSelect('', '');
        return;
      }

      if (!acceptedFileTypes.split(', ').includes(selectedFile.type)) {
        setError('Invalid file type.');
        onFileSelect('', '');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        onFileSelect(selectedFile.name, reader.result as string);
      };
      reader.onerror = () => {
        setError('Failed to read the file.');
        onFileSelect('', '');
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const isImage = file.dataUrl?.startsWith('data:image');
  const isPdf = file.dataUrl?.startsWith('data:application/pdf');

  return (
    <div>
      <label className="text-sm font-medium text-slate-700">{label}</label>
      <div 
        onClick={() => fileInputRef.current?.click()}
        className="mt-1 w-full p-4 border-2 border-dashed border-slate-300 rounded-lg text-center cursor-pointer hover:border-teal-500 hover:bg-slate-50 transition-colors"
      >
        <input
          type="file"
          accept={acceptedFileTypes}
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />
        {file.dataUrl ? (
          <div className="flex items-center gap-4">
            {isImage && <img src={file.dataUrl} alt="Preview" className="h-16 w-16 object-cover rounded-md" />}
            {isPdf && <FileIcon className="h-16 w-16 text-slate-500 flex-shrink-0" />}
            <div className="text-left overflow-hidden">
                <p className="font-semibold text-slate-700 truncate">{file.name}</p>
                <p className="text-xs text-slate-500">Click here to change file</p>
            </div>
          </div>
        ) : (
          <div>
            <p className="text-slate-600">Click to upload a file</p>
            <p className="text-xs text-slate-400 mt-1">PNG, JPG, WEBP, or PDF (Max {MAX_FILE_SIZE_MB}MB)</p>
          </div>
        )}
      </div>
       {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
    </div>
  );
};

export default FileUpload;
