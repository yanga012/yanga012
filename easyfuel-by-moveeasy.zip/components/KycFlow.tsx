import React, { useState } from 'react';
import type { User, KycDetails } from '../types';
import { submitKycData } from '../services/api';
import CameraCapture from './CameraCapture';
import FileUpload from './FileUpload';
import LoaderIcon from './icons/LoaderIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import OnboardingProgress from './OnboardingProgress';

// Icons defined locally to avoid creating many small files
const CameraIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
);
const IdCardIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 012-2h2a2 2 0 012 2v1m-6 0h6" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 14h.01" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 14h.01" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 17h.01" /></svg>
);
const DocumentIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
);


interface KycFlowProps {
  user: User;
  onKycSuccess: (user: User) => void;
  onSkip: () => void;
}

type KycStep = 'intro' | 'selfie' | 'id' | 'credit_choice' | 'address' | 'bank' | 'review' | 'submitting' | 'success';

const KycFlow: React.FC<KycFlowProps> = ({ user, onKycSuccess, onSkip }) => {
  const [step, setStep] = useState<KycStep>('intro');
  const [isCapturingSelfie, setIsCapturingSelfie] = useState(false);
  const [kycData, setKycData] = useState({
    selfieUrl: null as string | null,
    idType: 'sa_id' as 'sa_id' | 'passport',
    idNumber: '',
    idImage: { name: null as string | null, dataUrl: null as string | null },
    wantsCredit: false,
    addressImage: { name: null as string | null, dataUrl: null as string | null },
    bankImage: { name: null as string | null, dataUrl: null as string | null },
  });

  const handleSubmit = async () => {
    setStep('submitting');
    try {
      const finalKycData: KycDetails = {
        selfieUrl: kycData.selfieUrl!,
        idType: kycData.idType,
        idNumber: kycData.idNumber,
        idImageUrl: kycData.idImage.dataUrl!,
        wantsCredit: kycData.wantsCredit,
        addressImageUrl: kycData.addressImage.dataUrl,
        bankAccountImageUrl: kycData.bankImage.dataUrl,
      };
      const updatedUser = await submitKycData(user.id, finalKycData);
      setStep('success');
      setTimeout(() => onKycSuccess(updatedUser), 2000); // Give user time to see success message
    } catch (error) {
        console.error("KYC Submission failed", error);
        // In a real app, you'd want to show an error message and allow retry
        setStep('review'); // Go back to review step on failure
    }
  };

  const renderContent = () => {
    switch (step) {
      case 'intro': return (
        <>
          <h2 className="text-2xl font-bold text-slate-800">Verify Your Identity</h2>
          <p className="text-slate-600 mt-2">To unlock all features and keep your account secure, we need to verify your identity. This is a one-time process required by financial regulations.</p>
          
          <div className="mt-6 text-left bg-slate-50 p-4 rounded-lg border border-slate-200">
            <h3 className="font-semibold text-slate-700 mb-3">What you'll need:</h3>
            <ul className="space-y-3 text-sm text-slate-600">
              <li className="flex items-center gap-3">
                <CameraIcon className="h-6 w-6 text-teal-600 flex-shrink-0" />
                <span>A clear, well-lit space to take a selfie.</span>
              </li>
              <li className="flex items-center gap-3">
                <IdCardIcon className="h-6 w-6 text-teal-600 flex-shrink-0" />
                <span>Your valid SA ID or Passport document.</span>
              </li>
            </ul>
          </div>

          <button onClick={() => setStep('selfie')} className="w-full mt-8 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Get Started</button>
          <button onClick={onSkip} className="w-full mt-2 py-2 text-sm font-semibold text-slate-600 hover:text-slate-800">I'll do this later</button>
        </>
      );
      case 'selfie': return (
         <>
          <h2 className="text-2xl font-bold text-slate-800">Take a Selfie</h2>
          <p className="text-slate-600 mt-2">We need a clear photo of your face. Please remove any hats or glasses.</p>
          <div className="mt-6 p-4 border-2 border-dashed border-slate-300 rounded-lg h-48 flex flex-col items-center justify-center">
            {kycData.selfieUrl ? (
                <div className="flex items-center gap-4">
                    <img src={kycData.selfieUrl} alt="Your selfie" className="h-24 w-24 object-cover rounded-full border-4 border-teal-500" />
                    <div>
                        <p className="font-semibold text-green-700">Selfie Captured!</p>
                        <button onClick={() => setIsCapturingSelfie(true)} className="text-sm text-teal-600 hover:underline">Retake Photo</button>
                    </div>
                </div>
            ) : (
                <button onClick={() => setIsCapturingSelfie(true)} className="flex flex-col items-center text-slate-500 hover:text-teal-600">
                    <CameraIcon className="h-12 w-12" />
                    <span className="mt-2 font-semibold">Open Camera</span>
                </button>
            )}
          </div>
          <button onClick={() => setStep('id')} disabled={!kycData.selfieUrl} className="w-full mt-8 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400">Next</button>
        </>
      );
      case 'id': return (
         <>
          <h2 className="text-2xl font-bold text-slate-800">Your Identity Document</h2>
          <p className="text-slate-600 mt-2">Please provide your ID details and a clear picture of the document.</p>
          <div className="mt-6 space-y-4">
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-200 rounded-lg">
                <button onClick={() => setKycData(d => ({...d, idType: 'sa_id'}))} className={`py-2 rounded-md font-semibold ${kycData.idType === 'sa_id' ? 'bg-white shadow' : 'text-slate-600'}`}>SA ID</button>
                <button onClick={() => setKycData(d => ({...d, idType: 'passport'}))} className={`py-2 rounded-md font-semibold ${kycData.idType === 'passport' ? 'bg-white shadow' : 'text-slate-600'}`}>Passport</button>
            </div>
            <div>
              <label htmlFor="idNumber" className="text-sm font-medium text-slate-700">{kycData.idType === 'sa_id' ? 'ID Number' : 'Passport Number'}</label>
              <input id="idNumber" type="text" value={kycData.idNumber} onChange={e => setKycData(d => ({...d, idNumber: e.target.value}))} className="mt-1 w-full px-4 py-2 border rounded-lg"/>
            </div>
            <FileUpload 
              label={kycData.idType === 'sa_id' ? 'Upload ID Document' : 'Upload Passport Photo Page'}
              file={kycData.idImage}
              onFileSelect={(name, dataUrl) => setKycData(d => ({...d, idImage: { name, dataUrl }}))}
            />
          </div>
          <button onClick={() => setStep('credit_choice')} disabled={!kycData.idNumber || !kycData.idImage.dataUrl} className="w-full mt-8 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400">Next</button>
        </>
      );
      case 'credit_choice': return (
         <>
          <h2 className="text-2xl font-bold text-slate-800">Credit Management</h2>
          <p className="text-slate-600 mt-2">Do you intend to use credit management features? This requires providing proof of address and a bank account for verification.</p>
           <div className="mt-6 flex items-center justify-center p-2 bg-slate-200 rounded-lg">
                <button onClick={() => setKycData(d => ({...d, wantsCredit: false}))} className={`w-1/2 py-2 rounded-md font-semibold ${!kycData.wantsCredit ? 'bg-white shadow' : 'text-slate-600'}`}>No</button>
                <button onClick={() => setKycData(d => ({...d, wantsCredit: true}))} className={`w-1/2 py-2 rounded-md font-semibold ${kycData.wantsCredit ? 'bg-white shadow' : 'text-slate-600'}`}>Yes</button>
            </div>
          <button onClick={() => setStep(kycData.wantsCredit ? 'address' : 'review')} className="w-full mt-8 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Next</button>
        </>
      );
       case 'address': return (
         <>
          <h2 className="text-2xl font-bold text-slate-800">Proof of Address</h2>
          <p className="text-slate-600 mt-2">Please upload a utility bill or bank statement showing your name and address (not older than 3 months).</p>
          <div className="mt-6">
            <FileUpload 
                label="Upload Proof of Address"
                file={kycData.addressImage}
                onFileSelect={(name, dataUrl) => setKycData(d => ({...d, addressImage: { name, dataUrl }}))}
            />
          </div>
          <button onClick={() => setStep('bank')} disabled={!kycData.addressImage.dataUrl} className="w-full mt-8 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400">Next</button>
        </>
      );
       case 'bank': return (
         <>
          <h2 className="text-2xl font-bold text-slate-800">Proof of Bank Account</h2>
          <p className="text-slate-600 mt-2">Please upload a bank statement showing your name and account number (not older than 3 months).</p>
          <div className="mt-6">
            <FileUpload 
                label="Upload Proof of Bank Account"
                file={kycData.bankImage}
                onFileSelect={(name, dataUrl) => setKycData(d => ({...d, bankImage: { name, dataUrl }}))}
            />
          </div>
          <button onClick={() => setStep('review')} disabled={!kycData.bankImage.dataUrl} className="w-full mt-8 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400">Next</button>
        </>
      );
      case 'review': return (
        <>
          <h2 className="text-2xl font-bold text-slate-800">Review Your Information</h2>
          <p className="text-slate-600 mt-2">Please confirm your details are correct before submitting.</p>
          <div className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between items-center p-3 bg-slate-100 rounded-lg"><span>Selfie</span><span className="font-semibold text-green-600">Captured</span></div>
            <div className="flex justify-between items-center p-3 bg-slate-100 rounded-lg"><span>ID Type</span><span className="font-semibold">{kycData.idType === 'sa_id' ? 'SA ID' : 'Passport'}</span></div>
            <div className="flex justify-between items-center p-3 bg-slate-100 rounded-lg"><span>ID Number</span><span className="font-semibold">{kycData.idNumber}</span></div>
            <div className="flex justify-between items-center p-3 bg-slate-100 rounded-lg"><span>ID Document</span><span className="font-semibold text-green-600">Uploaded</span></div>
            {kycData.wantsCredit && (
                <>
                <div className="flex justify-between items-center p-3 bg-slate-100 rounded-lg"><span>Proof of Address</span><span className="font-semibold text-green-600">Uploaded</span></div>
                <div className="flex justify-between items-center p-3 bg-slate-100 rounded-lg"><span>Proof of Bank Account</span><span className="font-semibold text-green-600">Uploaded</span></div>
                </>
            )}
          </div>
          <button onClick={handleSubmit} className="w-full mt-8 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Submit Verification</button>
        </>
      );
      case 'submitting':
      case 'success': return (
        <div className="flex flex-col items-center justify-center pt-10 pb-4">
            {step === 'submitting' && <LoaderIcon className="h-12 w-12 text-teal-500" />}
            {step === 'success' && <CheckCircleIcon className="h-12 w-12 text-green-500" />}
            <p className="mt-4 text-lg font-semibold text-slate-800">
                {step === 'submitting' ? 'Submitting your information...' : 'Verification Complete!'}
            </p>
            <p className="text-slate-600 mt-1">
                {step === 'submitting' ? 'This will only take a moment.' : 'Redirecting you to the dashboard.'}
            </p>
        </div>
      );
    }
  };

  const showProgress = step !== 'submitting' && step !== 'success';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <main className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-md w-full">
        {showProgress && <OnboardingProgress currentStep="kyc" />}
        <div className="text-center">
            {renderContent()}
        </div>
      </main>
      {isCapturingSelfie && (
        <CameraCapture 
            onCapture={(img) => {
                setKycData(d => ({...d, selfieUrl: img}));
                setIsCapturingSelfie(false);
            }}
            onClose={() => setIsCapturingSelfie(false)}
        />
      )}
    </div>
  );
};

export default KycFlow;