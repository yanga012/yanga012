import React, { useState } from 'react';
import { signIn, signUp } from '../services/api';
import type { User } from '../types';
import MoveEasyLogo from './icons/MoveEasyLogo';
import LoaderIcon from './icons/LoaderIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';

interface AuthProps {
  onAuthSuccess: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onAuthSuccess }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [signupSuccess, setSignupSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isSignUp) {
        await signUp(email, password, phoneNumber);
        setSignupSuccess(true);
      } else {
        const user = await signIn(email, password);
        onAuthSuccess(user);
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  if (signupSuccess) {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
            <main className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-sm w-full text-center">
                <header className="flex flex-col items-center text-center pb-6 border-b border-slate-200">
                    <CheckCircleIcon className="h-12 w-12 text-green-500 mb-4" />
                    <h1 className="text-2xl font-bold text-slate-800">Registration Successful!</h1>
                </header>
                <div className="mt-6">
                    <p className="text-slate-600">A verification link has been sent to <span className="font-semibold text-slate-800">{email}</span>. Please check your inbox to continue.</p>
                    <p className="text-xs text-slate-400 mt-2">(In this demo, the link is printed in your browser's console).</p>
                    <button
                        onClick={() => {
                            setSignupSuccess(false);
                            setIsSignUp(false);
                            setEmail('');
                            setPassword('');
                            setPhoneNumber('');
                        }}
                        className="w-full mt-6 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
                    >
                        Back to Sign In
                    </button>
                </div>
            </main>
        </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <main className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-sm w-full">
        <header className="flex flex-col items-center text-center pb-6 border-b border-slate-200">
          <MoveEasyLogo className="h-10 w-10 text-teal-600 mb-3" />
          <h1 className="text-2xl font-bold text-slate-800">
            Welcome to MoveEasy
            <span className="block text-lg font-semibold text-teal-600 mt-1">EasyFuel</span>
          </h1>
          <p className="text-sm text-slate-500 mt-2">Sign in or create an account to continue</p>
        </header>

        <div className="mt-8">
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label htmlFor="email" className="text-sm font-medium text-slate-700">Email Address</label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                disabled={loading}
              />
            </div>
             <div>
              <label htmlFor="password"  className="text-sm font-medium text-slate-700">Password</label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                minLength={6}
                className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                disabled={loading}
              />
            </div>
            {isSignUp && (
              <div>
                <label htmlFor="phone" className="text-sm font-medium text-slate-700">Phone Number</label>
                <input
                  id="phone"
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+27821234567"
                  required
                  className="mt-1 w-full px-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                  disabled={loading}
                />
              </div>
            )}
            <button
              type="submit"
              className="w-full mt-2 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 focus:outline-none focus:ring-4 focus:ring-teal-300 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center"
              disabled={loading}
            >
              {loading ? <LoaderIcon className="h-6 w-6" /> : (isSignUp ? 'Create Account' : 'Sign In')}
            </button>
          </form>
          
          {!isSignUp && (
            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-500 text-center animate-fadeIn">
              <p className="font-semibold text-slate-600">Testing Credentials</p>
              <p><span className="font-medium">Email:</span> tester@moveeasy.app</p>
              <p><span className="font-medium">Password:</span> any password</p>
            </div>
          )}

          {error && <p className="mt-4 text-center text-sm text-red-600">{error}</p>}

          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError(null);
              }}
              className="text-sm text-teal-600 hover:text-teal-700 font-medium"
            >
              {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Auth;