import React, { useState, useEffect } from 'react';
import type { VoucherPartner, Status, Transaction } from '../types';
import { getVoucherPartners, redeemVoucher } from '../services/api';
import StepIndicator from './StepIndicator';
import StatusDisplay from './StatusDisplay';
import LoaderIcon from './icons/LoaderIcon';

interface CashInFlowProps {
  onRedeemSuccess: (transaction: Transaction) => void;
}

type Step = 'partner' | 'details' | 'confirm' | 'status';

const CashInFlow: React.FC<CashInFlowProps> = ({ onRedeemSuccess }) => {
  const [step, setStep] = useState<Step>('partner');
  const [partners, setPartners] = useState<VoucherPartner[]>([]);
  const [loadingPartners, setLoadingPartners] = useState(true);
  const [selectedPartner, setSelectedPartner] = useState<VoucherPartner | null>(null);
  
  const [voucherCode, setVoucherCode] = useState('');
  const [reference, setReference] = useState('');
  const [pin, setPin] = useState('');
  
  const [status, setStatus] = useState<Status>('idle');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPartners = async () => {
      try {
        setLoadingPartners(true);
        const voucherPartners = await getVoucherPartners();
        setPartners(voucherPartners);
      } catch (err) {
        setError("Could not load voucher partners.");
      } finally {
        setLoadingPartners(false);
      }
    };
    fetchPartners();
  }, []);

  const steps = ['Partner', 'Details', 'Status'];
  const currentStepIndex = step === 'partner' ? 0 : step === 'details' ? 1 : 2;

  const handleSelectPartner = (partner: VoucherPartner) => {
    setSelectedPartner(partner);
    setStep('details');
  };

  const handleRedeem = async () => {
    if (!selectedPartner) return;
    setStatus('loading');
    setError(null);
    setStep('status');
    
    const details = selectedPartner.category === 'voucher' 
      ? { code: voucherCode } 
      : { reference, pin };

    try {
      const newTransaction = await redeemVoucher(details, selectedPartner.id);
      setStatus('success');
      setTimeout(() => {
        onRedeemSuccess(newTransaction);
      }, 2000); // Delay for user to see success message
    } catch (err: any) {
      setStatus('error');
      setError(err.message || 'An unexpected error occurred.');
    }
  };

  const resetFlow = () => {
    setStep('partner');
    setSelectedPartner(null);
    setVoucherCode('');
    setReference('');
    setPin('');
    setStatus('idle');
    setError(null);
  };
  
  const renderStepContent = () => {
    switch (step) {
      case 'partner':
        return (
          <div className="text-center">
            <h3 className="text-lg font-bold text-slate-800 mb-1">Choose a Voucher</h3>
            <p className="text-sm text-slate-500 mb-6">How would you like to add funds?</p>
            {loadingPartners ? <div className="flex justify-center items-center h-48"><LoaderIcon className="h-8 w-8 text-teal-500" /></div> : (
              <div className="space-y-3">
                {partners.map(p => (
                  <button key={p.id} onClick={() => handleSelectPartner(p)} className="w-full text-left p-4 border border-slate-300 rounded-lg hover:bg-slate-50 hover:border-teal-500 transition-colors">
                    <p className="font-semibold text-lg">{p.name}</p>
                    <p className="text-sm text-slate-500">{p.description}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        );
      case 'details':
        if (!selectedPartner) return null;
        return (
            <div>
                <h3 className="text-lg font-bold text-slate-800 mb-6 text-center">Enter {selectedPartner.name} Details</h3>
                {selectedPartner.category === 'voucher' ? (
                    <div>
                        <label htmlFor="voucherCode" className="text-sm font-medium text-slate-700">Voucher Code</label>
                        <input id="voucherCode" type="text" value={voucherCode} onChange={e => setVoucherCode(e.target.value)} placeholder={selectedPartner.exampleCode} required className="mt-1 w-full px-4 py-2 border rounded-lg"/>
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="reference" className="text-sm font-medium text-slate-700">Reference Number</label>
                            <input id="reference" type="text" value={reference} onChange={e => setReference(e.target.value)} placeholder={selectedPartner.exampleReference} required className="mt-1 w-full px-4 py-2 border rounded-lg"/>
                        </div>
                         <div>
                            <label htmlFor="pin" className="text-sm font-medium text-slate-700">PIN</label>
                            <input id="pin" type="text" value={pin} onChange={e => setPin(e.target.value)} placeholder={selectedPartner.examplePin} required className="mt-1 w-full px-4 py-2 border rounded-lg"/>
                        </div>
                    </div>
                )}
                <div className="flex gap-2 mt-6">
                    <button type="button" onClick={() => setStep('partner')} className="w-full px-4 py-3 text-base font-bold text-slate-700 bg-slate-200 rounded-lg hover:bg-slate-300">Back</button>
                    <button onClick={handleRedeem} className="w-full px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">Redeem</button>
                </div>
            </div>
        );
      case 'status':
        return (
             <div>
                <StatusDisplay 
                    status={status}
                    message={
                        status === 'loading' ? 'Redeeming your voucher...' :
                        status === 'success' ? 'Redemption successful!' :
                        status === 'error' ? error || 'Redemption failed.' : ''
                    }
                    voucherValue={selectedPartner?.voucherValue}
                />
                {status !== 'loading' && status !== 'success' && (
                     <button onClick={resetFlow} className="w-full mt-4 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">
                        Try Again
                    </button>
                )}
            </div>
        );
      default: return null;
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg">
      <div className="mb-6">
        <StepIndicator steps={steps} currentStep={currentStepIndex} />
      </div>
      {renderStepContent()}
    </div>
  );
};

export default CashInFlow;
