import React, { useEffect, useRef, useState } from 'react';

interface QRCodeScannerProps {
  onScanSuccess: (data: string) => void;
  onScanError: (message: string) => void;
  onClose: () => void;
}

const QRCodeScanner: React.FC<QRCodeScannerProps> = ({ onScanSuccess, onScanError, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let animationFrameId: number;
    let stream: MediaStream | null = null;

    const startScan = async () => {
      if (!('BarcodeDetector' in window)) {
        setError('QR code scanning is not supported by your browser.');
        return;
      }
      // @ts-ignore
      const barcodeDetector = new window.BarcodeDetector({ formats: ['qr_code'] });

      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' } 
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }

        const detect = async () => {
          if (videoRef.current && barcodeDetector) {
            try {
              const barcodes = await barcodeDetector.detect(videoRef.current);
              if (barcodes.length > 0) {
                onScanSuccess(barcodes[0].rawValue);
                return; // Stop scanning on success
              }
            } catch (e) {
              console.error('Barcode detection failed:', e);
            }
          }
          animationFrameId = requestAnimationFrame(detect);
        };
        detect();

      } catch (err: any) {
        console.error('Camera access error:', err);
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          setError('Camera permission denied. Please enable it in your browser settings.');
        } else {
          setError('Could not access the camera. Please ensure it is not in use by another application.');
        }
      }
    };

    startScan();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [onScanSuccess]);

  return (
    <>
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 animate-fade-in" onClick={onClose}></div>
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4">
        <div className="relative w-full max-w-sm aspect-square bg-slate-800 rounded-2xl overflow-hidden shadow-2xl border-2 border-slate-700">
          <video ref={videoRef} className="w-full h-full object-cover" playsInline />
          
          {/* Scanning overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-2/3 h-2/3 border-4 border-emerald-500/50 rounded-lg shadow-inner-strong" />
          </div>

           {/* Animated scanning line */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-400 animate-scan-line shadow-[0_0_15px_rgba(52,211,153,0.8)]"></div>
          
          <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-black/50 rounded-full text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        {error ? (
          <div className="mt-4 p-3 bg-red-900/80 rounded-lg text-center text-red-200">{error}</div>
        ) : (
          <p className="mt-4 text-slate-300 text-center">Position the QR code inside the frame</p>
        )}
      </div>
       <style>{`
        @keyframes scan-line {
          0% { top: 0; }
          100% { top: 100%; }
        }
        .animate-scan-line {
          animation: scan-line 2.5s infinite ease-in-out;
        }
        .shadow-inner-strong {
          box-shadow: 0 0 0 9999px rgba(0,0,0,0.6);
        }
      `}</style>
    </>
  );
};

export default QRCodeScanner;