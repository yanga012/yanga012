import React, { useState, useMemo } from 'react';
import { Transaction, formatCurrency, Station } from '../types';
import { searchTransactionsWithAI } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';
import StationLogo from './StationLogo';

interface TransactionItemProps {
    transaction: Transaction;
    stationMap: Map<string, Station>;
    onSelect: () => void;
    isSelectable: boolean;
}

const TransactionItem: React.FC<TransactionItemProps> = ({ transaction, stationMap, onSelect, isSelectable }) => {
    const isRedeem = transaction.type === 'redeem';
    const amountColor = isRedeem ? 'text-green-600' : 'text-slate-800';
    const amountPrefix = isRedeem ? '+' : '-';

    const isPurchaseVoucher = transaction.type === 'purchase' && transaction.qrData;
    let voucherStatus: 'Active' | 'Used' | null = null;
    if (isPurchaseVoucher) {
        // Vouchers are 'active' until marked as 'used'.
        voucherStatus = transaction.status === 'used' ? 'Used' : 'Active';
    }

    const station = transaction.stationId ? stationMap.get(transaction.stationId) : null;

    const content = (
        <div className={`flex items-center justify-between p-3 rounded-lg ${transaction.isNew ? 'bg-teal-50 animate-fadeIn' : ''} ${isSelectable ? 'hover:bg-slate-100' : ''}`}>
            <div className="flex items-center gap-3 overflow-hidden">
                 {station ? 
                    <StationLogo logo={station.logo} stationName={station.name} className="h-10 w-10 object-contain bg-slate-100 rounded-lg p-1 flex-shrink-0" />
                    : <div className="h-10 w-10 bg-slate-100 rounded-lg flex-shrink-0" />
                 }
                 <div className="overflow-hidden">
                    <p className="font-semibold text-slate-800 truncate">{transaction.description}</p>
                    <div className="flex items-center gap-2 mt-1">
                        <p className="text-sm text-slate-500">{new Date(transaction.date).toLocaleDateString()}</p>
                        {voucherStatus && (
                             <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${
                                voucherStatus === 'Active' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-slate-200 text-slate-700'
                            }`}>
                                {voucherStatus}
                             </span>
                        )}
                    </div>
                </div>
            </div>
            <p className={`font-bold text-right text-base whitespace-nowrap pl-2 ${amountColor}`}>{amountPrefix} {formatCurrency(transaction.amount)}</p>
        </div>
    );

    return (
        <li>
            {isSelectable ? (
                <button onClick={onSelect} className="w-full text-left transition-colors">
                    {content}
                </button>
            ) : (
                content
            )}
        </li>
    );
};

interface ActivityProps {
    transactions: Transaction[];
    isLoading: boolean;
    isPreview?: boolean;
    stationMap: Map<string, Station>;
    onTransactionSelect?: (transaction: Transaction) => void;
}

const Activity: React.FC<ActivityProps> = ({ transactions, isLoading, isPreview = false, stationMap, onTransactionSelect }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [isSearching, setIsSearching] = useState(false);
    const [searchError, setSearchError] = useState<string | null>(null);
    const [filteredIds, setFilteredIds] = useState<string[] | null>(null);

    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!searchQuery.trim()) {
            setFilteredIds(null);
            return;
        }
        setIsSearching(true);
        setSearchError(null);
        try {
            const ids = await searchTransactionsWithAI(searchQuery, transactions);
            setFilteredIds(ids);
        } catch (err: any) {
            setSearchError(err.message);
        } finally {
            setIsSearching(false);
        }
    };
    
    const displayedTransactions = useMemo(() => {
        if (filteredIds === null) {
            return transactions;
        }
        return transactions.filter(t => filteredIds.includes(t.id));
    }, [transactions, filteredIds]);

    if (isLoading) {
        return <div className="flex justify-center items-center h-48"><LoaderIcon className="h-8 w-8 text-teal-500" /></div>;
    }
    
    if (transactions.length === 0 && !isPreview) {
        return <div className="text-center text-slate-500 py-12">No transactions yet.</div>;
    }

    return (
        <div>
            {!isPreview && (
                 <form onSubmit={handleSearch} className="mb-4">
                    <div className="relative">
                        <input 
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="AI Search: e.g. 'my active vouchers'"
                            className="w-full pl-10 pr-4 py-2 text-base border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                        />
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                           {isSearching ? <LoaderIcon className="h-5 w-5" /> : '✨'}
                        </div>
                    </div>
                    {searchError && <p className="mt-2 text-xs text-red-600 text-center">{searchError}</p>}
                </form>
            )}
            {displayedTransactions.length > 0 ? (
                <ul className="space-y-2">
                    {displayedTransactions.map(tx => (
                        <TransactionItem
                            key={tx.id}
                            transaction={tx}
                            stationMap={stationMap}
                            isSelectable={!isPreview && !!onTransactionSelect && tx.type === 'purchase'}
                            onSelect={() => onTransactionSelect?.(tx)}
                        />
                    ))}
                </ul>
            ) : (
                 <div className="text-center text-slate-500 py-12">No matching transactions found.</div>
            )}
        </div>
    );
};

export default Activity;