import React from 'react';
import { Station } from '../types';

interface StationLogoProps extends React.HTMLAttributes<HTMLElement> {
  logo: Station['logo'];
  stationName: string;
}

const StationLogo: React.FC<StationLogoProps> = ({ logo, stationName, ...props }) => {
  if (typeof logo === 'string') {
    return <img src={logo} alt={`${stationName} Logo`} {...props} />;
  }
  
  const LogoComponent = logo;
  return <LogoComponent {...props} />;
};

export default StationLogo;
