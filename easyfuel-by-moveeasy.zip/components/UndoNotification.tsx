import React from 'react';

interface UndoNotificationProps {
  amount: number;
  onUndo: () => void;
}

const UndoNotification: React.FC<UndoNotificationProps> = ({ amount, onUndo }) => {
  return (
    <div 
      className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-md p-4 bg-slate-800 rounded-lg shadow-2xl flex items-center justify-between border border-slate-700 z-50 animate-slide-up"
      role="status"
      aria-live="polite"
    >
      <p className="text-slate-200 text-sm">
        Added <span className="font-bold text-emerald-400">R {amount.toFixed(2)}</span> to your wallet.
      </p>
      <button 
        onClick={onUndo}
        className="text-amber-400 hover:text-amber-300 font-bold text-sm px-3 py-1 rounded hover:bg-slate-700 transition-colors"
        aria-label="Undo adding funds"
      >
        Undo
      </button>
    </div>
  );
};

export default UndoNotification;
