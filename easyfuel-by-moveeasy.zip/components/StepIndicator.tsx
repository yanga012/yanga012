import React from 'react';

interface StepIndicatorProps {
  steps: string[];
  currentStep: number;
}

const StepIndicator: React.FC<StepIndicatorProps> = ({ steps, currentStep }) => {
  return (
    <div className="flex items-center justify-center space-x-2">
      {steps.map((label, index) => {
        const isCompleted = index < currentStep;
        const isActive = index === currentStep;

        return (
          <React.Fragment key={index}>
            <div className="flex flex-col items-center">
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  isCompleted ? 'bg-teal-500 text-white' : isActive ? 'bg-teal-100 text-teal-700' : 'bg-slate-200 text-slate-500'
                }`}
              >
                {isCompleted ? '✓' : index + 1}
              </div>
              <span className={`mt-1 text-xs text-center ${isActive ? 'font-bold text-teal-700' : 'text-slate-500'}`}>{label}</span>
            </div>
            {index < steps.length - 1 && <div className="flex-grow h-0.5 bg-slate-200" />}
          </React.Fragment>
        );
      })}
    </div>
  );
};

export default StepIndicator;
