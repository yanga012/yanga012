import React from 'react';

const FuelIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M3 22v-5l2-1v-6c0-1.1.9-2 2-2h4.17a2 2 0 0 1 1.7.73L16 12.3V17H5" />
    <path d="M14 13h1.83a2 2 0 0 0 1.7-.73L20 9.7V6" />
    <path d="M15 9.3V4.5a1.5 1.5 0 0 1 1.5-1.5H18a1.5 1.5 0 0 1 1.5 1.5v1" />
  </svg>
);

export default FuelIcon;
