import React from 'react';

const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
    </svg>
);
  
interface OnboardingProgressProps {
  currentStep: 'phone' | 'kyc';
}

const steps = [
    { id: 'phone', name: 'Verify Phone' },
    { id: 'kyc', name: 'Verify Identity' }
];

const OnboardingProgress: React.FC<OnboardingProgressProps> = ({ currentStep }) => {
    const currentStepIndex = steps.findIndex(step => step.id === currentStep);

    return (
        <div className="w-full mb-8">
            <h2 className="text-2xl font-bold text-slate-800 text-center mb-6">Account Setup</h2>
            <div className="flex items-center w-3/4 mx-auto">
                {steps.map((step, index) => {
                    const isCompleted = index < currentStepIndex;
                    const isActive = index === currentStepIndex;

                    return (
                        <React.Fragment key={step.id}>
                            <div className="flex flex-col items-center text-center">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold transition-colors duration-300 relative z-10 ${
                                    isCompleted ? 'bg-teal-600 text-white' : 
                                    isActive ? 'bg-white border-2 border-teal-600 text-teal-600' : 
                                    'bg-slate-200 text-slate-500'
                                }`}>
                                    {isCompleted ? <CheckIcon className="w-4 h-4" /> : index + 1}
                                </div>
                                <p className={`mt-2 text-xs font-semibold w-20 ${isActive ? 'text-teal-700' : 'text-slate-500'}`}>{step.name}</p>
                            </div>
                            {index < steps.length - 1 && (
                                <div className={`flex-grow h-1 transition-colors duration-300 ${isCompleted ? 'bg-teal-600' : 'bg-slate-200'}`} />
                            )}
                        </React.Fragment>
                    );
                })}
            </div>
        </div>
    );
};

export default OnboardingProgress;
