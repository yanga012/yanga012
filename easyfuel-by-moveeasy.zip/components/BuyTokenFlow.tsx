import React, { useState } from 'react';
import type { Station, Transaction, User } from '../types';
import { STATIONS } from '../constants';
import { formatCurrency } from '../types';
import StationSelector from './StationSelector';
import AmountInput from './AmountInput';
import ConfirmationDialog from './ConfirmationDialog';
import StatusDisplay from './StatusDisplay';

interface BuyTokenFlowProps {
  user: User;
  onPurchaseSuccess: (transaction: Omit<Transaction, 'id'|'date'|'isNew'>) => void;
}

type Step = 'select' | 'confirm' | 'status';

const BuyTokenFlow: React.FC<BuyTokenFlowProps> = ({ user, onPurchaseSuccess }) => {
  const [step, setStep] = useState<Step>('select');
  const [stations, setStations] = useState<Station[]>(STATIONS);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [amount, setAmount] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleNextClick = () => {
    setError(null);
    const numericAmount = parseFloat(amount);
    if (!selectedStation) {
      setError('Please select a fuel station.');
      return;
    }
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setError('Please enter a valid amount.');
      return;
    }
    if (numericAmount > user.balance) {
      setError(`Amount cannot exceed your balance of ${formatCurrency(user.balance)}.`);
      return;
    }
    setStep('confirm');
  };
  
  const handleConfirm = () => {
    if (!selectedStation) return;
    
    setIsLoading(true);

    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 30);

    const voucherData = {
      voucherId: `TKN-${Date.now()}`,
      userId: user.id,
      amount: parseFloat(amount),
      stationId: selectedStation.id,
      timestamp: new Date().toISOString(),
      paymentType: 'token-voucher',
    };

    const newTransaction: Omit<Transaction, 'id'|'date'|'isNew'> = {
        type: 'purchase',
        amount: parseFloat(amount),
        description: `${selectedStation.name} Fuel Token`,
        stationId: selectedStation.id,
        status: 'active',
        expiryDate: expiryDate.toISOString(),
        qrData: JSON.stringify(voucherData),
    };

    // Simulate network delay
    setTimeout(() => {
        setIsLoading(false);
        onPurchaseSuccess(newTransaction);
    }, 1500);
  };

  const renderContent = () => {
    if (step === 'confirm' && selectedStation) {
      return (
        <ConfirmationDialog
          isOpen={true}
          onConfirm={handleConfirm}
          onCancel={() => setStep('select')}
          station={selectedStation}
          amount={parseFloat(amount) || 0}
          isLoading={isLoading}
        />
      );
    }
    
    return (
      <div className="bg-white p-6 rounded-2xl shadow-lg space-y-6 w-full max-w-md mx-auto">
        <h2 className="text-2xl font-bold text-center text-slate-800">Buy Fuel Token</h2>

        <StationSelector
          stations={stations}
          selectedStation={selectedStation}
          onSelect={setSelectedStation}
          onStartUpload={() => {}} // Not used in this flow
        />
        
        <AmountInput
          amount={amount}
          onAmountChange={setAmount}
          onMaxClick={() => setAmount(user.balance.toFixed(2))}
        />
        
        {error && (
          <div className="p-3 bg-red-100 border border-red-400 rounded-lg text-center text-sm text-red-800 animate-fadeIn">
            {error}
          </div>
        )}
        
        <button
          onClick={handleNextClick}
          disabled={!selectedStation || !amount || parseFloat(amount) <= 0}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-4 px-4 rounded-lg transition-all duration-300 text-lg flex items-center justify-center disabled:bg-slate-300 disabled:text-slate-500 disabled:cursor-not-allowed"
        >
          Continue
        </button>
      </div>
    );
  };

  return <>{renderContent()}</>;
};

export default BuyTokenFlow;
