import React, { useState } from 'react';
import type { User } from '../types';
import { verifyPhoneNumber } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';
import OnboardingProgress from './OnboardingProgress';

interface PhoneVerificationProps {
  user: User;
  onSuccess: (updatedUser: User) => void;
}

const PhoneVerification: React.FC<PhoneVerificationProps> = ({ user, onSuccess }) => {
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = async () => {
    if (otp.length !== 6) {
      setError("Please enter a 6-digit code.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const updatedUser = await verifyPhoneNumber(user.id, otp);
      onSuccess(updatedUser);
    } catch (err: any)      {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <main className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-sm w-full">
        <OnboardingProgress currentStep="phone" />
        <div className="text-center">
            <h2 className="text-xl font-bold text-slate-800">Enter Verification Code</h2>
            <p className="text-slate-600 mt-2">
            We sent a 6-digit code to <span className="font-semibold text-slate-800">{user.phoneNumber}</span>.
            </p>
        </div>
        <div className="mt-8">
            <div>
              <label htmlFor="otp" className="text-sm font-medium text-slate-700 sr-only">Verification Code</label>
              <input
                id="otp"
                type="text"
                value={otp}
                onChange={(e) => {
                    const value = e.target.value;
                    if (/^\d{0,6}$/.test(value)) {
                        setOtp(value);
                    }
                }}
                placeholder="••••••"
                maxLength={6}
                required
                className="w-full px-4 py-3 text-center text-3xl tracking-[1em] font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-colors"
                disabled={isLoading}
              />
            </div>
            <button
              onClick={handleVerify}
              className="w-full mt-6 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 flex items-center justify-center"
              disabled={isLoading || otp.length !== 6}
            >
              {isLoading ? <LoaderIcon className="h-6 w-6" /> : 'Verify & Continue'}
            </button>
          
          {error && <p className="mt-4 text-center text-sm text-red-600">{error}</p>}

          <p className="text-xs text-slate-400 mt-4 text-center">
            Didn't receive a code? In this demo, it's in your browser's console.
          </p>
        </div>
      </main>
    </div>
  );
};

export default PhoneVerification;