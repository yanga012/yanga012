// This component is no longer in use and has been replaced by the KycFlow component.
// It is kept in the file system to avoid breaking file-based prompts but is now empty.
import React from 'react';

const VerificationFlow: React.FC = () => {
  return null;
};

export default VerificationFlow;
