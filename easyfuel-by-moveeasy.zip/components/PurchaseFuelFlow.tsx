import React, { useState } from 'react';
import { Station, PaymentResult as PaymentResultType, User, formatCurrency } from '../types';
import { STATIONS } from '../constants';
import { processPayment } from '../services/paymentService';
import { generateImage } from '../services/geminiService';
import StationSelector from './StationSelector';
import AmountInput from './AmountInput';
import ConfirmationDialog from './ConfirmationDialog';
import PaymentResult from './PaymentResult';
import LogoUploader from './LogoUploader';
import QRCodeScanner from './QRCodeScanner';

// Simple UUID v4 generator for creating unique, non-predictable token IDs.
const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

const QrCodeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
    <path d="M4.5 2A2.5 2.5 0 002 4.5v2.5a.5.5 0 001 0V4.5A1.5 1.5 0 014.5 3h2.5a.5.5 0 000-1H4.5zM15.5 2A1.5 1.5 0 0117 3.5v2.5a.5.5 0 001 0V3.5A2.5 2.5 0 0015.5 1h-2.5a.5.5 0 000 1h2.5zM2 13.5v2A2.5 2.5 0 004.5 18h2.5a.5.5 0 000-1H4.5A1.5 1.5 0 013 15.5v-2a.5.5 0 00-1 0zM17 13.5v2A1.5 1.5 0 0115.5 17h-2.5a.5.5 0 000 1h2.5A2.5 2.5 0 0018 15.5v-2a.5.5 0 00-1 0z" />
    <path fillRule="evenodd" d="M3 6a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V6zm11-1a1 1 0 00-1 1v2a1 1 0 001 1h2a1 1 0 001-1V6a1 1 0 00-1-1h-2zM4 12a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1v-2zm7 0a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1h-2a1 1 0 01-1-1v-2z" clipRule="evenodd" />
  </svg>
);


interface PayAtStationFlowProps {
  user: User;
  onPaymentSuccess: (
    paymentResult: PaymentResultType,
    station: Station,
    artData?: { qrArtUrl?: string; tokenId?: string }
  ) => void;
  purchaseCount: number;
}

const PayAtStationFlow: React.FC<PayAtStationFlowProps> = ({ user, onPaymentSuccess, purchaseCount }) => {
  const [stations, setStations] = useState<Station[]>(STATIONS);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [amount, setAmount] = useState('');
  const [isConfirming, setIsConfirming] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [paymentResult, setPaymentResult] = useState<(PaymentResultType & { qrArtUrl?: string }) | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [uploadingLogoStation, setUploadingLogoStation] = useState<Station | null>(null);
  const [isScanning, setIsScanning] = useState(false);

  const handleUploadLogo = (stationId: string, dataUrl: string) => {
    setStations(currentStations =>
      currentStations.map(s => s.id === stationId ? { ...s, logo: dataUrl } : s)
    );
  };

  const handleRemoveLogo = (stationId: string) => {
    const originalStation = STATIONS.find(s => s.id === stationId);
    if (originalStation) {
      setStations(currentStations =>
        currentStations.map(s => s.id === stationId ? { ...s, logo: originalStation.logo } : s)
      );
    }
  };

  const handlePayClick = () => {
    setError(null);
    const numericAmount = parseFloat(amount);
    if (!selectedStation) {
      setError('Please select a fuel station.');
      return;
    }
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setError('Please enter a valid amount.');
      return;
    }
    if (numericAmount > user.balance) {
      setError(`Amount cannot exceed your balance of ${formatCurrency(user.balance)}.`);
      return;
    }
    setIsConfirming(true);
  };
  
  const handleConfirm = async () => {
    if (!selectedStation || !amount) return;

    setIsLoading(true);
    try {
      // 1. Process the payment to get the base result and transaction ID
      const result = await processPayment(selectedStation, parseFloat(amount), user.id);

      let qrArtUrl: string | undefined = undefined;
      let tokenId: string | undefined = undefined;

      // 2. For all voucher payments, attempt to generate bonus QR Art
      if (result.type === 'voucher') {
        try {
          const artPrompt = `A hyper-realistic, artistic digital voucher for a ${formatCurrency(parseFloat(amount))} fuel purchase at ${selectedStation.name}, created on ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}. The art should evoke a sense of speed, technological advancement, and the vibrant brand colors of ${selectedStation.name}. Cinematic lighting, dramatic angles.`;
          qrArtUrl = await generateImage(artPrompt);
          tokenId = `ME-EFT-V1-${generateUUID()}`;
        } catch (artError) {
          console.error("QR Art generation failed, but payment was successful. Displaying standard QR.", artError);
          // Art generation is optional, so we continue without it on failure.
        }
      }

      // 3. Call the single success handler with all available data to be persisted.
      onPaymentSuccess(result, selectedStation, { qrArtUrl, tokenId });

      // 4. Update local state to display the result screen to the user.
      setPaymentResult({ ...result, qrArtUrl });

    } catch (paymentError: any) {
      setError(paymentError.message || 'An unexpected error occurred during payment.');
    } finally {
      setIsLoading(false);
      setIsConfirming(false);
    }
  };

  const resetFlow = () => {
    setSelectedStation(null);
    setAmount('');
    setPaymentResult(null);
    setError(null);
  };

  const handlePayAgain = (station: Station, newAmount: number) => {
    resetFlow();
    // Use a short timeout to ensure the state update from resetFlow has propagated
    // before setting the new pre-filled values for the next payment.
    setTimeout(() => {
        setSelectedStation(station);
        setAmount(newAmount.toFixed(2));
    }, 50);
  };
  
  const handleScanSuccess = (data: string) => {
    setIsScanning(false);
    setError(null);
    try {
      const parsed = JSON.parse(data);
      let stationFound = false;
      let amountSet = false;

      if (parsed.stationId && typeof parsed.stationId === 'string') {
        const station = stations.find(s => s.id === parsed.stationId);
        if (station) {
          setSelectedStation(station);
          stationFound = true;
        } else {
          setError(`Scanned station ID "${parsed.stationId}" is not recognized.`);
          return;
        }
      }

      if (parsed.amount) {
        const numericAmount = parseFloat(parsed.amount);
        if (!isNaN(numericAmount) && numericAmount > 0) {
          setAmount(numericAmount.toFixed(2));
          amountSet = true;
        } else {
          setError(`Scanned amount "${parsed.amount}" is not a valid number.`);
          return;
        }
      }

      if (!stationFound && !amountSet) {
        setError("QR code does not contain a valid station or amount.");
      }
    } catch (e) {
      setError("Invalid QR code. Could not read the data.");
      console.error("Failed to parse QR code data:", e);
    }
  };

  const handleScanError = (message: string) => {
    setIsScanning(false);
    setError(message);
  };

  if (paymentResult && selectedStation) {
      return <PaymentResult result={paymentResult} station={selectedStation} onDone={resetFlow} onPayAgain={handlePayAgain} />;
  }

  return (
    <>
      <div className="bg-white p-6 rounded-2xl shadow-lg space-y-6 w-full max-w-md mx-auto">
        <div className="flex justify-center items-center relative">
          <h2 className="text-2xl font-bold text-center text-slate-800">Pay at Station</h2>
          <button 
            onClick={() => setIsScanning(true)}
            className="absolute right-0 p-2 bg-slate-100 hover:bg-slate-200 rounded-full text-slate-500 hover:text-slate-800 transition-colors"
            aria-label="Scan QR to pre-fill"
          >
            <QrCodeIcon className="h-6 w-6" />
          </button>
        </div>

        <StationSelector
          stations={stations}
          selectedStation={selectedStation}
          onSelect={setSelectedStation}
          onStartUpload={setUploadingLogoStation}
        />
        
        <AmountInput
          amount={amount}
          onAmountChange={setAmount}
          onMaxClick={() => setAmount(user.balance.toFixed(2))}
        />
        
        {error && (
          <div className="p-3 bg-red-100 border border-red-400 rounded-lg text-center text-sm text-red-800 animate-fadeIn">
            {error}
          </div>
        )}
        
        <button
          onClick={handlePayClick}
          disabled={!selectedStation || !amount || parseFloat(amount) <= 0}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-4 px-4 rounded-lg transition-all duration-300 text-lg flex items-center justify-center disabled:bg-slate-300 disabled:text-slate-500 disabled:cursor-not-allowed"
        >
          Continue to Pay
        </button>
      </div>

      {selectedStation && (
        <ConfirmationDialog
          isOpen={isConfirming}
          onConfirm={handleConfirm}
          onCancel={() => setIsConfirming(false)}
          station={selectedStation}
          amount={parseFloat(amount) || 0}
          isLoading={isLoading}
        />
      )}

      {uploadingLogoStation && (
        <LogoUploader
          station={uploadingLogoStation}
          onUpload={handleUploadLogo}
          onRemove={handleRemoveLogo}
          onClose={() => setUploadingLogoStation(null)}
        />
      )}
      
      {isScanning && (
        <QRCodeScanner 
          onScanSuccess={handleScanSuccess}
          onScanError={handleScanError}
          onClose={() => setIsScanning(false)}
        />
      )}
    </>
  );
};

export default PayAtStationFlow;