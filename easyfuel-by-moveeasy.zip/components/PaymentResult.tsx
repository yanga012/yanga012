import React from 'react';
import { PaymentResult as PaymentResultType, Station } from '../types';
import QRCode from './QRCode';
import StationLogo from './StationLogo';
import SparklesIcon from './icons/SparklesIcon';

interface PaymentResultProps {
  result: PaymentResultType & { qrArtUrl?: string };
  station: Station;
  onDone: () => void;
  onPayAgain: (station: Station, amount: number) => void;
}

const PaymentResult: React.FC<PaymentResultProps> = ({ result, station, onDone, onPayAgain }) => {
  const isVoucher = result.type === 'voucher';
  
  const handlePayAgainClick = () => {
    onPayAgain(station, result.amount);
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-lg text-center animate-fadeIn space-y-4 w-full">
      <h2 className="text-2xl font-bold text-teal-600">
        {isVoucher ? 'Voucher Generated!' : 'Digital Receipt'}
      </h2>
      <p className="text-slate-600">
        {isVoucher 
          ? result.message 
          : 'Your payment was successful. Scan the QR code for transaction details.'}
      </p>
      
      <div className="flex justify-center">
        <button 
          onClick={handlePayAgainClick}
          className="group transition-transform duration-300 ease-in-out hover:scale-105 focus:scale-105 focus:outline-none focus:ring-4 focus:ring-teal-300 rounded-2xl"
          aria-label={`Pay ${station.name} R${result.amount.toFixed(2)} again`}
        >
          <div className="p-4 bg-slate-100 rounded-xl animate-scale-in pointer-events-none">
            {result.qrArtUrl ? (
              <div className="relative w-full max-w-[256px] aspect-square rounded-lg overflow-hidden border-2 border-slate-200 shadow-lg">
                <img src={result.qrArtUrl} alt="AI generated background" className="absolute inset-0 w-full h-full object-cover" />
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm">
                  <QRCode data={result.qrData} />
                </div>
              </div>
            ) : (
              <QRCode data={result.qrData} />
            )}
          </div>
        </button>
      </div>

      <p className="text-xs text-slate-500 -mt-2">Tap the QR code to make this payment again.</p>
      
      {result.qrArtUrl && (
        <div className="!mt-4 text-center animate-fadeIn">
          <p className="text-teal-600 font-semibold flex items-center justify-center gap-2">
            <SparklesIcon className="h-5 w-5" /> AI-Generated Voucher Art
          </p>
          <p className="text-xs text-slate-500">View it anytime in your transaction history.</p>
        </div>
      )}

      <div className="!mt-6 pt-4 border-t border-slate-200 text-left text-sm space-y-2">
        <div className="flex justify-between">
          <span className="text-slate-500">Station:</span>
          <span className="font-medium flex items-center text-slate-800">
            <StationLogo logo={station.logo} stationName={station.name} className="h-5 w-5 object-contain mr-2"/>
            {station.name}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-slate-500">Amount:</span>
          <span className="font-bold text-lg text-teal-600">R {result.amount.toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-500">Date:</span>
          <span className="font-medium text-slate-800">{new Date().toLocaleString('en-ZA', { dateStyle: 'medium', timeStyle: 'short' })}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-500">Reference:</span>
          <span className="font-mono text-xs bg-slate-200 text-slate-700 px-2 py-1 rounded">{result.transactionId}</span>
        </div>
      </div>

      <button
        onClick={onDone}
        className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 text-lg !mt-8"
      >
        New Payment
      </button>
    </div>
  );
};

export default PaymentResult;