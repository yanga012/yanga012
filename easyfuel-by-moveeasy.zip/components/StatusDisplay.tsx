import React from 'react';
import type { Status } from '../types';
import { formatCurrency } from '../types';
import LoaderIcon from './icons/LoaderIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';

interface StatusDisplayProps {
  status: Status;
  message: string;
  voucherValue?: number;
}

const StatusDisplay: React.FC<StatusDisplayProps> = ({ status, message, voucherValue }) => {
  const icon = {
    loading: <LoaderIcon className="h-12 w-12 text-teal-500" />,
    success: <CheckCircleIcon className="h-12 w-12 text-green-500" />,
    error: <div className="h-12 w-12 flex items-center justify-center rounded-full bg-red-100 text-red-500 text-3xl font-bold">!</div>,
    idle: null,
  }[status];

  return (
    <div className="flex flex-col items-center text-center py-8">
      {icon}
      <p className="mt-4 text-lg font-semibold text-slate-800">{message}</p>
      {status === 'success' && voucherValue && (
        <p className="text-2xl font-bold text-green-600 mt-1">{formatCurrency(voucherValue)}</p>
      )}
    </div>
  );
};

export default StatusDisplay;
