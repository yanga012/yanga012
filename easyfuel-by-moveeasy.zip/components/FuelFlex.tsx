import React, { useState, useEffect } from 'react';
import type { User, Transaction, Station } from '../types';
import { formatCurrency } from '../types';
import { STATIONS } from '../constants';
import { getFlexVouchers, activateFuelFlexVoucher } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';
import StationSelector from './StationSelector';
import ConfirmationDialog from './ConfirmationDialog';
import CheckCircleIcon from './icons/CheckCircleIcon';

const FULL_TANK_VALUE = 800;
const UPFRONT_PAYMENT = FULL_TANK_VALUE / 3;
const MAX_VOUCHERS = 3;

const RocketIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
    </svg>
);


interface FuelFlexProps {
  user: User;
  onActivationSuccess: (data: { newUser: User; newTransaction: Transaction }) => void;
}

const FuelFlex: React.FC<FuelFlexProps> = ({ user, onActivationSuccess }) => {
    const [flexVouchers, setFlexVouchers] = useState<Transaction[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string|null>(null);
    
    // Activation state
    const [activatingSlot, setActivatingSlot] = useState<number | null>(null);
    const [selectedStation, setSelectedStation] = useState<Station | null>(null);
    const [isConfirming, setIsConfirming] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        const fetchVouchers = async () => {
            try {
                const vouchers = await getFlexVouchers(user.id);
                setFlexVouchers(vouchers);
            } catch (err) {
                setError("Could not load your FuelFlex plan details.");
            } finally {
                setIsLoading(false);
            }
        };
        fetchVouchers();
    }, [user.id]);
    
    const handleActivate = (slotIndex: number) => {
        setError(null);
        setActivatingSlot(slotIndex);
    };

    const handleConfirm = async () => {
        if (!selectedStation) return;
        setIsSubmitting(true);
        setError(null);
        try {
            const result = await activateFuelFlexVoucher(user.id, selectedStation.id, selectedStation.name);
            onActivationSuccess(result);
        } catch (err: any) {
            setError(err.message || 'An unexpected error occurred.');
            setActivatingSlot(null);
            setSelectedStation(null);
        } finally {
            setIsSubmitting(false);
            setIsConfirming(false);
        }
    };

    const renderVoucherSlot = (index: number) => {
        const voucher = flexVouchers[index];
        const isBeingActivated = activatingSlot === index;

        if (voucher) {
            const statusText = voucher.status === 'used' ? 'Used' : 'Active';
            return (
                <div key={index} className="bg-slate-100 p-4 rounded-lg text-center opacity-70">
                    <CheckCircleIcon className="h-10 w-10 mx-auto text-slate-400" />
                    <h4 className="font-bold text-slate-700 mt-2">Voucher {index + 1}</h4>
                    <p className="text-sm text-slate-500 font-semibold">{statusText}</p>
                </div>
            );
        }
        
        if (isBeingActivated) {
            return (
                 <div key={index} className="bg-white p-4 rounded-lg border-2 border-teal-500 shadow-lg">
                    <h4 className="font-bold text-slate-800 text-center mb-4">Activate Voucher {index + 1}</h4>
                    <div className="bg-slate-50 p-3 rounded-lg text-center mb-4">
                        <p className="text-sm text-slate-600">Upfront Payment</p>
                        <p className="text-2xl font-bold text-teal-600">{formatCurrency(UPFRONT_PAYMENT)}</p>
                    </div>
                    <StationSelector 
                        stations={STATIONS}
                        selectedStation={selectedStation}
                        onSelect={setSelectedStation}
                        onStartUpload={()=>{}}
                    />
                     <div className="mt-4 grid grid-cols-2 gap-2">
                        <button onClick={() => setActivatingSlot(null)} className="w-full text-center py-2 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300">Cancel</button>
                        <button 
                            onClick={() => setIsConfirming(true)}
                            disabled={!selectedStation || isSubmitting}
                            className="w-full text-center py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 disabled:bg-slate-400"
                        >
                            Next
                        </button>
                    </div>
                 </div>
            );
        }

        return (
            <div key={index} className="bg-white p-4 rounded-lg text-center border-2 border-dashed border-slate-300">
                <RocketIcon className="h-10 w-10 mx-auto text-slate-400" />
                <h4 className="font-bold text-slate-700 mt-2">Voucher {index + 1}</h4>
                <p className="text-sm text-slate-500 mb-3">Available</p>
                <button 
                    onClick={() => handleActivate(index)}
                    disabled={!!activatingSlot}
                    className="w-full text-center py-2 bg-slate-700 text-white font-semibold rounded-lg hover:bg-slate-800 disabled:bg-slate-400"
                >
                    Activate
                </button>
            </div>
        );
    };

    return (
        <div className="bg-slate-800 text-white rounded-2xl shadow-2xl p-6 w-full max-w-lg border border-slate-700">
            <h2 className="text-2xl font-bold text-center mb-1">FuelFlex Plan</h2>
            <p className="text-center text-sm text-slate-300 mb-2">Unlock up to 3 full tank vouchers ({formatCurrency(FULL_TANK_VALUE)} each).</p>
            {user.outstandingBalance && user.outstandingBalance > 0 && (
                <p className="text-center text-sm font-semibold text-red-400 mb-4">
                    Outstanding Balance: {formatCurrency(user.outstandingBalance)}
                </p>
            )}

            {isLoading && <div className="flex justify-center p-8"><LoaderIcon className="h-8 w-8" /></div>}
            
            {!isLoading && (
                <div className="mt-4 space-y-4">
                    {error && <div className="p-3 bg-red-900/50 border border-red-500 rounded-lg text-center text-sm text-red-300 animate-fadeIn">{error}</div>}
                    {[...Array(MAX_VOUCHERS)].map((_, i) => renderVoucherSlot(i))}
                </div>
            )}
             {selectedStation && (
                <ConfirmationDialog
                    isOpen={isConfirming}
                    onConfirm={handleConfirm}
                    onCancel={() => setIsConfirming(false)}
                    station={selectedStation}
                    amount={UPFRONT_PAYMENT}
                    isLoading={isSubmitting}
                />
            )}
        </div>
    );
};

export default FuelFlex;
