import React from 'react';
import { QRCodeCanvas } from 'qrcode.react';

interface QRCodeProps {
  data: string;
  className?: string;
}

const QRCode: React.FC<QRCodeProps> = ({ data, className }) => {
  // Using client-side library `qrcode.react` to generate the QR code.
  // This removes the external API dependency for better performance and reliability.
  
  return (
    // The outer div provides a clean, light background for the QR code.
    <div className={`p-3 bg-slate-100 rounded-xl border border-slate-200 w-full max-w-[256px] aspect-square ${className || ''}`}>
      <QRCodeCanvas
        value={data}
        size={256} // The intrinsic size of the QR code in pixels
        bgColor="#FFFFFF"
        fgColor="#0f172a" // Tailwind's slate-900
        level="Q" // Error correction level
        includeMargin={true}
        // The canvas is styled to fit within the padded container.
        className={`rounded-lg w-full h-full`}
        role="img"
        aria-label="Voucher QR Code"
      />
    </div>
  );
};

export default QRCode;