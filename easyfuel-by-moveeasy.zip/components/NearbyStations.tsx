import React from 'react';

// A simple utility to render Gemini's text response, which may contain markdown.
const SimpleMarkdown: React.FC<{ text: string }> = ({ text }) => {
  const html = text
    .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-slate-200">$1</strong>')
    .replace(/^\* (.*$)/gim, '<ul class="list-disc list-inside ml-2"><li>$1</li></ul>')
    .replace(/<\/ul>\n<ul/g, '')
    .replace(/\n/g, '<br />');

  return <div className="space-y-2" dangerouslySetInnerHTML={{ __html: html.replace(/<\/ul><br \/>/g, '</ul>') }} />;
};


interface NearbyStationsProps {
  isLoading: boolean;
  error: string | null;
  data: { text: string; groundingChunks: any[] } | null;
}

const NearbyStations: React.FC<NearbyStationsProps> = ({ isLoading, error, data }) => {
  // No rendering if not loading, no error, and no data.
  if (!isLoading && !error && !data) {
    return null;
  }

  return (
    <div className="mt-4 p-4 bg-slate-800/50 rounded-lg animate-fade-in">
        {isLoading && (
            <div className="text-center text-slate-300">Finding nearby stations...</div>
        )}

        {error && (
            <div className="p-4 bg-red-900/50 border border-red-500 rounded-lg text-center text-red-300">
                {error}
            </div>
        )}

        {data && (
            <div className="space-y-3 text-slate-300">
                <h4 className="font-semibold text-slate-100">Nearby Locations</h4>
                <div className="text-sm">
                    <SimpleMarkdown text={data.text} />
                </div>

                {data.groundingChunks?.some(chunk => chunk.maps) && (
                    <div className="pt-3 border-t border-slate-700">
                    <h5 className="text-xs font-bold uppercase text-slate-400 mb-2">Sources from Google Maps</h5>
                    <div className="space-y-2">
                        {data.groundingChunks.map((chunk, index) => {
                        if (!chunk.maps) return null;
                        
                        const title = chunk.maps.title || 'View on Google Maps';
                        const uri = chunk.maps.uri;

                        return (
                            <a
                            key={`${uri}-${index}`}
                            href={uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block p-2 bg-slate-700/50 hover:bg-slate-700 rounded-md text-sm text-emerald-400 transition-colors"
                            >
                            {title}
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 inline-block ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                            </a>
                        );
                        })}
                    </div>
                    </div>
                )}
            </div>
        )}
    </div>
  );
};

export default NearbyStations;