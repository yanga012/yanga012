
import React from 'react';

interface AmountInputProps {
  amount: string;
  onAmountChange: (value: string) => void;
  onMaxClick: () => void;
}

const AmountInput: React.FC<AmountInputProps> = ({ amount, onAmountChange, onMaxClick }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // This regex provides client-side validation for the amount input.
    // It allows:
    // - An empty string.
    // - Whole numbers (e.g., "123").
    // - Numbers with a decimal point (e.g., "123.").
    // - Numbers with up to two decimal places (e.g., "123.45").
    // It prevents non-numeric characters and more than two decimal places.
    if (/^\d*\.?\d{0,2}$/.test(value)) {
      onAmountChange(value);
    }
  };

  return (
    <div>
      <label htmlFor="amount" className="block text-md font-semibold text-slate-600 mb-2 text-center">
        Enter Amount (ZAR)
      </label>
      <div className="relative">
        <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 text-2xl font-bold">R</span>
        <input
          type="text"
          id="amount"
          inputMode="decimal"
          value={amount}
          onChange={handleInputChange}
          placeholder="0.00"
          className="w-full bg-slate-100 text-slate-800 text-3xl font-bold text-center py-4 rounded-lg border-2 border-slate-300 focus:border-teal-500 focus:ring-teal-500 transition-colors"
        />
        <button
          onClick={onMaxClick}
          className="absolute inset-y-0 right-0 flex items-center pr-4 text-teal-600 hover:text-teal-700 font-bold text-sm"
        >
          MAX
        </button>
      </div>
    </div>
  );
};

export default AmountInput;