import React, { useState, useEffect, useCallback, useMemo } from 'react';
import type { User, Transaction, PaymentResult, Station } from '../types';
import { formatCurrency } from '../types';
import { signOut, getTransactions, processAddFunds, getPurchaseTransactionCount, markVoucherAsUsed, addTransaction } from '../services/api';
import MoveEasyLogo from './icons/MoveEasyLogo';
import CashInFlow from './CashInFlow';
import PayAtStationFlow from './PurchaseFuelFlow';
import Activity from './Activity';
import BottomNavBar, { type View } from './BottomNavBar';
import LoaderIcon from './icons/LoaderIcon';
import EyeIcon from './icons/EyeIcon';
import EyeSlashIcon from './icons/EyeSlashIcon';
import NotificationPermissionBanner from './NotificationPermissionBanner';
import ShieldCheckIcon from './icons/ShieldCheckIcon';
import KycFlow from './KycFlow';
import { STATIONS } from '../constants';
import QRCode from './QRCode';
import TransactionDetail from './TransactionDetail';
import StationLogo from './StationLogo';
import AddFunds from './AddFunds';
import LockClosedIcon from './icons/LockClosedIcon';
import PhoneVerification from './PhoneVerification';
import BuyTokenFlow from './BuyTokenFlow';
import ExclamationCircleIcon from './icons/ExclamationCircleIcon';
import FuelFlex from './FuelFlex';

// --- START OF TOKENS VIEW DEFINITION ---
// This component and its helpers are defined here to avoid creating new files.

const RocketIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
    </svg>
);


// Helper to check expiry and calculate days remaining
const getExpiryInfo = (expiryDate: string) => {
    const now = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return {
        isExpired: diffTime < 0,
        daysRemaining: diffDays,
    };
};


// The card for displaying a single active voucher
interface VoucherCardProps {
    voucher: Transaction & { station: Station };
    onMarkAsUsed: (transactionId: string) => void;
}
const VoucherCard: React.FC<VoucherCardProps> = ({ voucher, onMarkAsUsed }) => {
    const expiryInfo = voucher.expiryDate ? getExpiryInfo(voucher.expiryDate) : null;
    const canBeUsed = !expiryInfo || !expiryInfo.isExpired;

    return (
        <div className={`relative bg-white p-4 rounded-2xl shadow-lg flex flex-col items-center gap-4 animate-fadeIn ${!canBeUsed ? 'opacity-60' : ''}`}>
             {voucher.isFlex && (
                <div className="absolute top-3 right-3 text-xs font-bold bg-purple-100 text-purple-800 px-2 py-1 rounded-full flex items-center gap-1">
                    <RocketIcon className="h-3 w-3" />
                    FLEX
                </div>
            )}
            <div className="w-full flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <StationLogo logo={voucher.station.logo} stationName={voucher.station.name} className="h-10 w-10 object-contain" />
                    <div>
                        <p className="font-bold text-slate-800">{voucher.station.name}</p>
                        <p className="text-sm font-semibold text-teal-600">{formatCurrency(voucher.amount)}</p>
                    </div>
                </div>
                <button
                    onClick={() => onMarkAsUsed(voucher.id)}
                    className="px-3 py-2 text-xs font-bold text-white bg-slate-700 rounded-lg hover:bg-slate-800 disabled:bg-slate-400 disabled:cursor-not-allowed"
                    title="Simulate this voucher being redeemed at a station."
                    disabled={!canBeUsed}
                >
                    Simulate Use
                </button>
            </div>

            {voucher.qrData && <QRCode data={voucher.qrData} className={!canBeUsed ? 'grayscale' : ''} />}
            
            {expiryInfo && (
                <div className={`w-full text-center text-xs font-semibold px-2 py-1 rounded-md ${
                    expiryInfo.isExpired 
                    ? 'bg-red-100 text-red-700' 
                    : expiryInfo.daysRemaining <= 7 
                    ? 'bg-amber-100 text-amber-700' 
                    : 'bg-slate-100 text-slate-600'
                }`}>
                    {expiryInfo.isExpired 
                        ? 'Expired' 
                        : `Expires in ${expiryInfo.daysRemaining} ${expiryInfo.daysRemaining === 1 ? 'day' : 'days'}`
                    }
                </div>
            )}
        </div>
    );
};

// The main view for listing all active tokens
interface TokensViewProps {
  transactions: Transaction[];
  stationMap: Map<string, Station>;
  onMarkAsUsed: (transactionId: string) => void;
}
const TokensView: React.FC<TokensViewProps> = ({ transactions, stationMap, onMarkAsUsed }) => {
    const activeVouchers = useMemo(() => {
        return transactions
            .filter(tx => {
                const isPurchase = tx.type === 'purchase';
                const isActive = tx.status === 'active';
                const hasQr = !!tx.qrData;
                const isExpired = tx.expiryDate ? new Date(tx.expiryDate) < new Date() : false;
                return isPurchase && isActive && hasQr && !isExpired;
            })
            .map(tx => {
                const station = tx.stationId ? stationMap.get(tx.stationId) : undefined;
                if (!station) return null;
                return { ...tx, station };
            })
            .filter((v): v is Transaction & { station: Station } => !!v)
            .sort((a, b) => new Date(a.expiryDate || 0).getTime() - new Date(b.expiryDate || 0).getTime());
    }, [transactions, stationMap]);
    
    return (
        <div className="space-y-4">
             <h2 className="text-2xl font-bold text-slate-800">Active Fuel Tokens</h2>
             {activeVouchers.length > 0 ? (
                 <div className="space-y-4">
                    {activeVouchers.map(voucher => (
                        <VoucherCard key={voucher.id} voucher={voucher} onMarkAsUsed={onMarkAsUsed} />
                    ))}
                 </div>
             ) : (
                <div className="text-center py-16 bg-white rounded-2xl shadow-lg">
                    <svg className="mx-auto h-16 w-16 text-slate-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M2 9a3 3 0 0 1 0 6v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3a3 3 0 0 1 0-6V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z" /><path d="M13 5v2" /><path d="M13 17v2" /><path d="M13 11v2" /></svg>
                    <h3 className="mt-4 text-xl font-semibold text-slate-700">No Active Tokens</h3>
                    <p className="text-slate-500 mt-2 max-w-xs mx-auto">Vouchers you purchase will appear here until they are used.</p>
                </div>
             )}
        </div>
    );
};
// --- END OF TOKENS VIEW DEFINITION ---

// --- START OF PROFILE VIEW DEFINITION ---
interface ArtViewerModalProps {
  transaction: Transaction;
  onClose: () => void;
}
const ArtViewerModal: React.FC<ArtViewerModalProps> = ({ transaction, onClose }) => {
    if (!transaction.qrArtUrl) return null;
    return (
        <>
            <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 animate-fadeIn" onClick={onClose}></div>
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
                <div className="bg-slate-800 rounded-2xl shadow-2xl p-4 w-full max-w-md border border-slate-700 animate-slide-up-fast text-center" onClick={e => e.stopPropagation()}>
                    <h3 className="text-lg font-bold text-white mb-3">Milestone Reward</h3>
                    <img src={transaction.qrArtUrl} alt="QR Art Collectible" className="w-full aspect-square rounded-lg object-cover" />
                    {transaction.tokenId && (
                        <div className="mt-3 text-left">
                            <p className="text-xs text-slate-400">Token ID</p>
                            <p className="font-mono text-xs bg-slate-700 text-slate-300 p-2 rounded-md break-all">{transaction.tokenId}</p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
};

const VerificationStatusItem: React.FC<{ label: string; isVerified: boolean; }> = ({ label, isVerified }) => (
    <div className="flex items-center justify-between p-3 bg-slate-100 rounded-lg">
        <div className="flex items-center gap-3">
            {isVerified 
                ? <ShieldCheckIcon className="h-6 w-6 text-green-500" />
                : <ExclamationCircleIcon className="h-6 w-6 text-orange-500" />
            }
            <span className="font-semibold text-slate-700">{label}</span>
        </div>
        <span className={`px-3 py-1 text-xs font-bold rounded-full ${
            isVerified ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'
        }`}>
            {isVerified ? 'Verified' : 'Required'}
        </span>
    </div>
);


interface ProfileViewProps {
  user: User;
  transactions: Transaction[];
  onLogout: () => void;
  onViewArt: (transaction: Transaction) => void;
}
const ProfileView: React.FC<ProfileViewProps> = ({ user, transactions, onLogout, onViewArt }) => {
    const collectibles = useMemo(() => {
        return transactions.filter(tx => tx.qrArtUrl && tx.tokenId);
    }, [transactions]);

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-lg font-bold text-slate-800 mb-4 text-center">Account Status</h3>
                <div className="space-y-3">
                    <VerificationStatusItem label="Email Address" isVerified={user.isVerified} />
                    <VerificationStatusItem label="Phone Number" isVerified={user.isPhoneVerified} />
                    <VerificationStatusItem label="Identity (KYC)" isVerified={user.isKycVerified} />
                </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-lg font-bold text-slate-800 mb-4 text-center">My Collectibles</h3>
                {collectibles.length > 0 ? (
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-4">
                        {collectibles.map(tx => (
                            <button
                                key={tx.id}
                                onClick={() => onViewArt(tx)}
                                className="aspect-square bg-slate-100 rounded-lg overflow-hidden focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-transform hover:scale-105"
                                title={`View collectible from ${new Date(tx.date).toLocaleDateString()}`}
                            >
                                <img src={tx.qrArtUrl} alt={`Collectible badge for transaction ${tx.id}`} className="w-full h-full object-cover" />
                            </button>
                        ))}
                    </div>
                ) : (
                    <div className="text-center text-slate-500 py-6">
                        <p>Milestone rewards you earn will appear here.</p>
                        <p className="text-xs mt-1">Make your 1st and 100th fuel purchase to earn one!</p>
                    </div>
                )}
            </div>

            <button
                onClick={onLogout}
                className="w-full px-4 py-3 text-base font-bold text-red-600 bg-red-50 rounded-lg hover:bg-red-100"
            >
                Logout
            </button>
        </div>
    );
};
// --- END OF PROFILE VIEW DEFINITION ---


interface DashboardProps {
  user: User;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user: initialUser, onLogout }) => {
  const [user, setUser] = useState<User>(initialUser);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<View>('home');
  const [showBalance, setShowBalance] = useState(true);
  const [isCashInModalOpen, setCashInModalOpen] = useState(false);
  const [isAddFundsModalOpen, setAddFundsModalOpen] = useState(false);
  const [isBuyTokenModalOpen, setBuyTokenModalOpen] = useState(false);
  const [isFuelFlexOpen, setFuelFlexOpen] = useState(false);
  const [purchaseCount, setPurchaseCount] = useState(0);
  const [viewingArt, setViewingArt] = useState<Transaction | null>(null);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [kycSkipped, setKycSkipped] = useState(false);

  const stationMap = useMemo(() => new Map(STATIONS.map(s => [s.id, s])), []);

  const selectedStationForDetail = useMemo(() => {
    if (!selectedTransaction?.stationId) return undefined;
    return stationMap.get(selectedTransaction.stationId);
  }, [selectedTransaction, stationMap]);

  const fetchTransactions = useCallback(async () => {
    try {
      setLoading(true);
      const userTransactions = await getTransactions(user.id);
      setTransactions(userTransactions);
    } catch (error)
 {
      console.error("Failed to fetch transactions:", error);
    } finally {
      setLoading(false);
    }
  }, [user.id]);
  
  useEffect(() => {
    fetchTransactions();
    const fetchPurchaseCount = async () => {
        const count = await getPurchaseTransactionCount(user.id);
        setPurchaseCount(count);
    };
    fetchPurchaseCount();
  }, [fetchTransactions, user.id]);

  const handleCashInSuccess = (newTransaction: Transaction) => {
    setTransactions(prev => [{ ...newTransaction, isNew: true }, ...prev]);
    const newBalance = user.balance + newTransaction.amount;
    setUser(currentUser => ({...currentUser, balance: newBalance }));
    setView('activity');
    setCashInModalOpen(false);

    if (Notification.permission === 'granted') {
      const title = 'Cash In Successful';
      const body = `Amount: ${formatCurrency(newTransaction.amount)}\nDescription: ${newTransaction.description}`;
      new Notification(title, { body });
    }
  };

  const handleAddFunds = async (amount: number) => {
    try {
        const { newBalance, transaction } = await processAddFunds(user.id, amount);
        setTransactions(prev => [{ ...transaction, isNew: true }, ...prev]);
        setUser(currentUser => ({...currentUser, balance: newBalance }));
        setAddFundsModalOpen(false);

        if (Notification.permission === 'granted') {
            const title = 'Funds Added';
            const body = `${formatCurrency(amount)} has been added to your wallet.`;
            new Notification(title, { body });
        }
    } catch (error) {
        console.error("Failed to add funds:", error);
        throw error;
    }
  };

  const handlePaymentSuccess = async (
    paymentResult: PaymentResult,
    station: Station,
    artData?: { qrArtUrl?: string; tokenId?: string }
  ) => {
    const newTransaction: Transaction = {
      id: paymentResult.transactionId,
      type: 'purchase',
      amount: paymentResult.amount,
      description: `Payment to ${station.name}`,
      date: new Date().toISOString(),
      isNew: true,
      qrData: paymentResult.type === 'voucher' ? paymentResult.qrData : undefined,
      stationId: station.id,
      qrArtUrl: artData?.qrArtUrl,
      tokenId: artData?.tokenId,
      status: 'active',
    };

    try {
        const savedTx = await addTransaction(newTransaction);
        setTransactions(prev => [{ ...savedTx, isNew: true }, ...prev]);
        const newBalance = user.balance - paymentResult.amount;
        setUser(currentUser => ({...currentUser, balance: newBalance }));
        setPurchaseCount(prev => prev + 1);

        if (Notification.permission === 'granted') {
          const title = 'Payment Successful';
          const body = `Amount: ${formatCurrency(paymentResult.amount)}\nDescription: ${newTransaction.description}`;
          new Notification(title, { body });
        }
    } catch (error) {
        console.error("Failed to save transaction", error);
    }
  };

  const handleTokenPurchaseSuccess = async (tokenData: Omit<Transaction, 'id'|'date'|'isNew'>) => {
     const newTransaction: Transaction = {
      ...tokenData,
      id: `txn-tok-${Date.now()}`,
      date: new Date().toISOString(),
      isNew: true,
    };
    
    try {
        const savedTx = await addTransaction(newTransaction);
        setTransactions(prev => [{ ...savedTx, isNew: true }, ...prev]);
        const newBalance = user.balance - newTransaction.amount;
        setUser(currentUser => ({...currentUser, balance: newBalance }));
        setBuyTokenModalOpen(false);
        setView('tokens');

        if (Notification.permission === 'granted') {
          const title = 'Token Purchased';
          const body = `A ${formatCurrency(newTransaction.amount)} token for ${tokenData.description} has been added to your wallet.`;
          new Notification(title, { body });
        }
    } catch (error) {
      console.error("Failed to save token transaction", error);
    }
  };

  const handleFlexActivationSuccess = ({ newUser, newTransaction }: { newUser: User, newTransaction: Transaction }) => {
    setUser(newUser);
    setTransactions(prev => [{ ...newTransaction, isNew: true }, ...prev]);
    setFuelFlexOpen(false);
    setView('tokens');

    if (Notification.permission === 'granted') {
        const title = 'FuelFlex Voucher Activated!';
        const body = `Your ${formatCurrency(newTransaction.amount)} voucher is now available in your Tokens.`;
        new Notification(title, { body });
    }
  };

  const handleMarkAsUsed = async (transactionId: string) => {
    try {
        const updatedTx = await markVoucherAsUsed(transactionId);
        setTransactions(currentTxs => 
            currentTxs.map(tx => (tx.id === transactionId ? updatedTx : tx))
        );
    } catch (error) {
        console.error("Failed to mark voucher as used:", error);
    }
  };

  const handleLogout = async () => {
    await signOut();
    onLogout();
  };

  // Onboarding step handlers
  const handlePhoneVerified = (updatedUser: User) => {
    setUser(updatedUser); // This will cause a re-render, moving to the next step
  };
  const handleKycSuccess = (updatedUser: User) => {
    setUser(updatedUser); // Re-render to show the full dashboard
  };

  // Onboarding Flow Logic
  if (!user.isPhoneVerified) {
    return <PhoneVerification user={user} onSuccess={handlePhoneVerified} />;
  }
  if (!user.isKycVerified && !kycSkipped) {
    return <KycFlow user={user} onKycSuccess={handleKycSuccess} onSkip={() => setKycSkipped(true)} />;
  }

  const renderHomeView = () => {
    const handleProtectedAction = (action: () => void) => {
      if (user.isKycVerified) {
        action();
      } else {
        setView('profile');
      }
    };

    return (
      <>
        <div className="bg-white p-6 rounded-2xl shadow-lg mb-6">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-slate-500">Available Balance</p>
              <div className="flex items-center gap-2">
                <p className="text-3xl font-bold text-slate-800">
                  {showBalance ? formatCurrency(user.balance) : 'R ••••••'}
                </p>
                <button
                  onClick={() => setShowBalance(!showBalance)}
                  className="text-slate-500 hover:text-slate-800"
                  aria-label={showBalance ? 'Hide balance' : 'Show balance'}
                >
                  {showBalance ? (
                    <EyeSlashIcon className="h-5 w-5" />
                  ) : (
                    <EyeIcon className="h-5 w-5" />
                  )}
                </button>
              </div>
               {user.outstandingBalance && user.outstandingBalance > 0 && (
                    <div className="text-xs text-red-600 font-semibold mt-1">
                        Outstanding: {formatCurrency(user.outstandingBalance)}
                    </div>
                )}
            </div>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-4">
             <button
              onClick={() => handleProtectedAction(() => setAddFundsModalOpen(true))}
              className={`w-full px-4 py-3 text-base font-bold rounded-lg flex items-center justify-center gap-2 transition-colors ${
                user.isKycVerified
                  ? 'bg-teal-600 hover:bg-teal-700 text-white'
                  : 'bg-slate-400 text-white'
              }`}
            >
              {!user.isKycVerified && <LockClosedIcon className="h-4 w-4" />}
              Add Funds
            </button>
            <button
              onClick={() => handleProtectedAction(() => setBuyTokenModalOpen(true))}
              className={`w-full px-4 py-3 text-base font-bold rounded-lg flex items-center justify-center gap-2 transition-colors ${
                user.isKycVerified
                  ? 'bg-teal-600 hover:bg-teal-700 text-white'
                  : 'bg-slate-400 text-white'
              }`}
            >
              {!user.isKycVerified && <LockClosedIcon className="h-4 w-4" />}
              Buy Fuel Token
            </button>
            <button
              onClick={() => handleProtectedAction(() => setCashInModalOpen(true))}
              className={`w-full px-4 py-3 text-base font-bold rounded-lg flex items-center justify-center gap-2 transition-colors ${
                user.isKycVerified
                  ? 'text-teal-700 bg-teal-100 hover:bg-teal-200'
                  : 'text-slate-500 bg-slate-200'
              }`}
            >
              {!user.isKycVerified && <LockClosedIcon className="h-4 w-4" />}
              Cash In Voucher
            </button>
            <button
              onClick={() => handleProtectedAction(() => setView('pay-station'))}
              className={`w-full px-4 py-3 text-base font-bold rounded-lg flex items-center justify-center gap-2 transition-colors ${
                user.isKycVerified
                  ? 'text-teal-700 bg-teal-100 hover:bg-teal-200'
                  : 'text-slate-500 bg-slate-200'
              }`}
            >
              {!user.isKycVerified && <LockClosedIcon className="h-4 w-4" />}
              Pay at Station
            </button>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-600 to-indigo-700 p-6 rounded-2xl shadow-lg mb-6 text-white text-center animate-fadeIn">
            <h3 className="text-2xl font-bold flex items-center justify-center gap-2">
                <RocketIcon className="h-6 w-6" />
                FuelFlex Plan
            </h3>
            <p className="mt-2 opacity-90 text-sm">Get 3 full tanks of fuel now and pay in installments. Unlock each voucher with just 1/3rd of the amount.</p>
            <button 
                onClick={() => handleProtectedAction(() => setFuelFlexOpen(true))}
                className={`w-full max-w-xs mx-auto mt-4 px-4 py-3 text-base font-bold rounded-lg flex items-center justify-center gap-2 transition-colors ${
                    user.isKycVerified
                    ? 'bg-white/20 hover:bg-white/30 text-white'
                    : 'bg-slate-400 text-white cursor-not-allowed'
                }`}
            >
                {!user.isKycVerified && <LockClosedIcon className="h-4 w-4" />}
                {user.isKycVerified ? 'Manage Plan' : 'Verify to Unlock'}
            </button>
        </div>


        <div className="mt-4">
          <h3 className="text-lg font-bold text-slate-800 mb-2">Recent Activity</h3>
          <div className="bg-white p-4 rounded-2xl shadow-lg">
            <Activity
              transactions={transactions.slice(0, 3)}
              isLoading={loading}
              isPreview={true}
              stationMap={stationMap}
              onTransactionSelect={setSelectedTransaction}
            />
          </div>
        </div>
      </>
    );
  };

  const renderView = () => {
    const KycRequiredView: React.FC = () => (
      <div className="bg-white p-6 rounded-2xl shadow-lg text-center animate-fadeIn">
        <ShieldCheckIcon className="h-16 w-16 mx-auto text-orange-500" />
        <h2 className="text-2xl font-bold text-slate-800 mt-4">Identity Verification Required</h2>
        <p className="text-slate-600 mt-2 max-w-sm mx-auto">
          To access secure features like payments and fuel tokens, you need to complete identity
          verification.
        </p>
        <button
          onClick={() => setView('profile')}
          className="w-full max-w-xs mx-auto mt-6 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
        >
          Go to Profile to Verify
        </button>
      </div>
    );

    switch (view) {
      case 'pay-station':
        if (!user.isKycVerified) {
          return <KycRequiredView />;
        }
        return (
          <PayAtStationFlow
            user={user}
            onPaymentSuccess={handlePaymentSuccess}
            purchaseCount={purchaseCount}
          />
        );
      case 'tokens':
        if (!user.isKycVerified) {
          return <KycRequiredView />;
        }
        return (
          <TokensView
            transactions={transactions}
            stationMap={stationMap}
            onMarkAsUsed={handleMarkAsUsed}
          />
        );
      case 'activity':
        return (
          <Activity
            transactions={transactions}
            isLoading={loading}
            stationMap={stationMap}
            onTransactionSelect={setSelectedTransaction}
          />
        );
      case 'profile':
        return (
          <ProfileView
            user={user}
            transactions={transactions}
            onLogout={handleLogout}
            onViewArt={setViewingArt}
          />
        );
      case 'home':
      default:
        return renderHomeView();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white/80 backdrop-blur-lg sticky top-0 z-10 p-4 border-b border-slate-200">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <MoveEasyLogo className="h-8 w-8 text-teal-600" />
            <h1 className="text-xl font-bold text-slate-800">EasyFuel</h1>
          </div>
          <p className="text-sm font-semibold text-slate-600 hidden sm:block">
            {user.email}
          </p>
        </div>
      </header>
      
      <main className="flex-grow max-w-3xl w-full mx-auto p-4 sm:p-6 pb-24">
        {view === 'home' && <NotificationPermissionBanner />}
        {renderView()}
      </main>

      <BottomNavBar currentView={view} setView={setView} isVerified={user.isKycVerified} />
      
      {isAddFundsModalOpen && (
          <AddFunds 
              onAdd={handleAddFunds}
              onClose={() => setAddFundsModalOpen(false)}
          />
      )}

      {isCashInModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fadeIn" onClick={() => setCashInModalOpen(false)}>
              <div className="relative w-full max-w-md" onClick={(e) => e.stopPropagation()}>
                <CashInFlow onRedeemSuccess={handleCashInSuccess} />
                <button 
                    onClick={() => setCashInModalOpen(false)}
                    className="absolute -top-2 -right-2 h-8 w-8 bg-white rounded-full flex items-center justify-center shadow-lg text-slate-600 hover:text-slate-900 text-2xl"
                    aria-label="Close cash in modal"
                >
                    &times;
                </button>
              </div>
          </div>
      )}
       {isBuyTokenModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fadeIn" onClick={() => setBuyTokenModalOpen(false)}>
              <div className="relative w-full max-w-md" onClick={(e) => e.stopPropagation()}>
                <BuyTokenFlow 
                    user={user}
                    onPurchaseSuccess={handleTokenPurchaseSuccess} 
                />
                 <button 
                    onClick={() => setBuyTokenModalOpen(false)}
                    className="absolute -top-2 -right-2 h-8 w-8 bg-white rounded-full flex items-center justify-center shadow-lg text-slate-600 hover:text-slate-900 text-2xl"
                    aria-label="Close buy token modal"
                >
                    &times;
                </button>
              </div>
          </div>
      )}
       {isFuelFlexOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fadeIn" onClick={() => setFuelFlexOpen(false)}>
              <div className="relative w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
                <FuelFlex 
                    user={user}
                    onActivationSuccess={handleFlexActivationSuccess} 
                />
                 <button 
                    onClick={() => setFuelFlexOpen(false)}
                    className="absolute -top-2 -right-2 h-8 w-8 bg-slate-800 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-slate-700 text-2xl"
                    aria-label="Close FuelFlex modal"
                >
                    &times;
                </button>
              </div>
          </div>
      )}
      {viewingArt && <ArtViewerModal transaction={viewingArt} onClose={() => setViewingArt(null)} />}
      
      {selectedTransaction && selectedStationForDetail && (
        <>
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 animate-fade-in" onClick={() => setSelectedTransaction(null)}></div>
          <div className="fixed inset-x-0 bottom-0 z-50 bg-slate-900 rounded-t-2xl shadow-2xl max-h-[80vh] flex flex-col animate-slide-up">
            <TransactionDetail 
              item={selectedTransaction} 
              station={selectedStationForDetail}
              onClose={() => setSelectedTransaction(null)}
            />
          </div>
        </>
      )}

    </div>
  );
};
export default Dashboard;