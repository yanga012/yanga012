import React, { useState, useEffect, useRef } from 'react';

interface WalletCardProps {
  balance: number;
  onAddFundsClick: () => void;
}

// Easing function for a more natural animation curve
function easeOutCubic(t: number): number {
  return (--t) * t * t + 1;
}

const WalletCard: React.FC<WalletCardProps> = ({ balance, onAddFundsClick }) => {
  const [displayedBalance, setDisplayedBalance] = useState(balance);
  const [animationClass, setAnimationClass] = useState('');
  const prevBalanceRef = useRef(balance);
  const animationFrameRef = useRef<number>();

  useEffect(() => {
    const startBalance = prevBalanceRef.current;
    const endBalance = balance;

    // Only animate if the balance has actually changed
    if (startBalance === endBalance) {
      return;
    }

    // Determine animation type based on whether funds were added or spent
    const isAddingFunds = endBalance > startBalance;
    const animationType = isAddingFunds ? 'animate-balance-add' : 'animate-balance-spend';
    setAnimationClass(animationType);
    
    // The duration of the CSS animation (0.6s for add, 0.4s for spend)
    const animationDuration = isAddingFunds ? 600 : 400;
    const bounceTimer = setTimeout(() => setAnimationClass(''), animationDuration);

    // Animate the numbers counting up/down
    const duration = 1200; // 1.2 seconds for the count animation
    let startTime: number | null = null;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / duration, 1);
      const easedPercentage = easeOutCubic(percentage);

      const currentBalance = startBalance + (endBalance - startBalance) * easedPercentage;
      setDisplayedBalance(currentBalance);

      if (progress < duration) {
        animationFrameRef.current = requestAnimationFrame(animate);
      } else {
        // Ensure final balance is precise
        setDisplayedBalance(endBalance);
        prevBalanceRef.current = endBalance;
      }
    };

    animationFrameRef.current = requestAnimationFrame(animate);

    // Cleanup function to cancel animations if the component unmounts or the balance changes again
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      clearTimeout(bounceTimer);
    };
  }, [balance]);

  return (
    <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700">
      <div className="text-center">
        <h2 className="text-lg font-medium text-slate-400">Wallet Balance</h2>
        <p className={`text-4xl font-bold text-emerald-400 mt-2 tracking-tight ${animationClass}`}>
          R {displayedBalance.toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </p>
      </div>
      <button 
        onClick={onAddFundsClick}
        className="w-full mt-4 bg-slate-700/50 hover:bg-slate-700 text-emerald-400 font-bold py-3 px-4 rounded-lg transition-colors duration-300 flex items-center justify-center gap-2"
        aria-label="Add funds to wallet"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
        </svg>
        <span>Add Funds</span>
      </button>
    </div>
  );
};

export default WalletCard;