import React, { useEffect, useState } from 'react';

interface NotificationProps {
  id: number;
  title: string;
  message: string;
  onDismiss: (id: number) => void;
}

const NOTIFICATION_TIMEOUT = 5000;

const Notification: React.FC<NotificationProps> = ({ id, title, message, onDismiss }) => {
    const [isExiting, setIsExiting] = useState(false);

    useEffect(() => {
        const timerId = setTimeout(() => {
            setIsExiting(true);
        }, NOTIFICATION_TIMEOUT);

        return () => clearTimeout(timerId);
    }, [id]);

    const handleAnimationEnd = () => {
        if (isExiting) {
            onDismiss(id);
        }
    };

    const handleClose = () => {
        setIsExiting(true);
    };

  return (
    <div
      className={`relative w-full max-w-sm p-4 bg-slate-800 rounded-lg shadow-2xl border border-slate-700 flex items-start gap-4 animate-slide-in-right ${isExiting ? 'animate-slide-out-right' : ''}`}
      onAnimationEnd={handleAnimationEnd}
      role="alert"
      aria-live="assertive"
    >
      <div className="flex-shrink-0 text-emerald-400">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </div>
      <div className="flex-grow">
        <h3 className="font-bold text-slate-100">{title}</h3>
        <p className="text-sm text-slate-300">{message}</p>
      </div>
      <button onClick={handleClose} aria-label="Close notification" className="p-1 text-slate-400 hover:text-white rounded-full flex-shrink-0 -mt-1 -mr-1">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
};

export default Notification;
