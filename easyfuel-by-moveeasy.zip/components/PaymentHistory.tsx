import React, { useState } from 'react';
import { TransactionHistoryItem, Station } from '../types';
import TransactionDetail from './TransactionDetail';
import StationLogo from './StationLogo';

interface PaymentHistoryProps {
  history: TransactionHistoryItem[];
  onClose: () => void;
  stationMap: Map<string, Station>;
}

const HistoryItem: React.FC<{ item: TransactionHistoryItem; station?: Station; onSelect: () => void }> = ({ item, station, onSelect }) => {
  const date = new Date(item.date);

  return (
    <li className="list-none">
        <button onClick={onSelect} className="w-full flex items-center justify-between p-3 bg-slate-800 hover:bg-slate-700/50 rounded-lg transition-colors text-left">
            <div className="flex items-center">
                {station && <StationLogo logo={station.logo} stationName={station.name} className="h-8 w-8 object-contain mr-4" />}
                <div>
                <p className="font-semibold text-slate-200">{item.stationName}</p>
                <p className="text-xs text-slate-400">
                    {date.toLocaleDateString('en-ZA')} at {date.toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' })}
                </p>
                </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                  <p className="font-bold text-emerald-400">
                  - R {item.amount.toFixed(2)}
                  </p>
                  <p className={`text-xs capitalize ${item.type === 'voucher' ? 'text-amber-400' : 'text-sky-400'}`}>
                  {item.type}
                  </p>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
        </button>
    </li>
  );
};


const PaymentHistory: React.FC<PaymentHistoryProps> = ({ history, onClose, stationMap }) => {
  const [selectedItem, setSelectedItem] = useState<TransactionHistoryItem | null>(null);

  const selectedStation = selectedItem ? stationMap.get(selectedItem.stationId) : undefined;

  return (
    <>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 animate-fade-in" onClick={onClose}></div>
      <div className="fixed inset-x-0 bottom-0 z-50 bg-slate-900 rounded-t-2xl shadow-2xl max-h-[80vh] flex flex-col animate-slide-up">
        
        {selectedItem && selectedStation ? (
            <TransactionDetail item={selectedItem} station={selectedStation} onClose={() => setSelectedItem(null)} />
        ) : (
            <>
                <header className="flex items-center justify-between p-4 border-b border-slate-700 sticky top-0 bg-slate-900">
                    <h2 className="text-xl font-bold">Payment History</h2>
                    <button onClick={onClose} className="p-2 text-slate-400 hover:text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </header>

                <div className="flex-grow overflow-y-auto p-4">
                    {history.length > 0 ? (
                        <ul className="space-y-3">
                        {history.map(item => {
                          const station = stationMap.get(item.stationId);
                          return <HistoryItem key={item.referenceId} item={item} station={station} onSelect={() => setSelectedItem(item)} />
                        })}
                        </ul>
                    ) : (
                        <div className="text-center py-12 text-slate-500">
                            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            <p className="mt-4 text-lg">No transactions yet.</p>
                            <p className="text-sm">Your payment history will appear here.</p>
                        </div>
                    )}
                </div>
            </>
        )}
      </div>
    </>
  );
};

export default PaymentHistory;