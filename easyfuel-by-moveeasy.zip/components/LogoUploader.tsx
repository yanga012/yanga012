import React, { useState, useRef } from 'react';
import { Station } from '../types';
import StationLogo from './StationLogo';

interface LogoUploaderProps {
  station: Station;
  onUpload: (stationId: string, dataUrl: string) => void;
  onRemove: (stationId: string) => void;
  onClose: () => void;
}

const MAX_FILE_SIZE_MB = 1;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

const LogoUploader: React.FC<LogoUploaderProps> = ({ station, onUpload, onRemove, onClose }) => {
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    setPreview(null);
    const file = event.target.files?.[0];

    if (file) {
      if (file.size > MAX_FILE_SIZE_BYTES) {
        setError(`File is too large. Max size is ${MAX_FILE_SIZE_MB}MB.`);
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.onerror = () => {
        setError('Failed to read the file.');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpload = () => {
    if (preview) {
      onUpload(station.id, preview);
      onClose();
    }
  };

  const handleRemove = () => {
    onRemove(station.id);
    onClose();
  };
  
  const isCustomLogo = typeof station.logo === 'string';

  return (
    <>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 animate-fade-in" onClick={onClose}></div>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-slate-800 rounded-2xl shadow-2xl p-6 w-full max-w-sm border border-slate-700 animate-slide-up-fast">
          <h2 className="text-xl font-bold text-center text-slate-100 mb-2">Custom Logo</h2>
          <p className="text-center text-slate-400 text-sm mb-4">for {station.name}</p>

          <div className="flex justify-center items-center my-4">
            <div className="flex flex-col items-center mx-2">
                <p className="text-xs text-slate-500 mb-2">Current</p>
                <StationLogo logo={station.logo} stationName={station.name} className="h-16 w-16 object-contain bg-slate-700/50 p-1 rounded-lg"/>
            </div>
            {preview && (
                 <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                    <div className="flex flex-col items-center mx-2">
                        <p className="text-xs text-emerald-400 mb-2">New</p>
                        <img src={preview} alt="New logo preview" className="h-16 w-16 object-contain bg-slate-700/50 p-1 rounded-lg" />
                    </div>
                </>
            )}
          </div>
          
          {error && <div className="p-2 my-2 bg-red-900/50 border border-red-500 rounded-lg text-center text-xs text-red-300">{error}</div>}

          <input
            type="file"
            accept="image/png, image/jpeg, image/svg+xml, image/webp"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
          <button
             onClick={() => fileInputRef.current?.click()}
             className="w-full bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300"
          >
            Choose Image...
          </button>
          
          <div className="mt-4 grid grid-cols-2 gap-3">
            <button
              onClick={onClose}
              className="w-full bg-slate-600/50 hover:bg-slate-600 text-slate-300 font-bold py-3 px-4 rounded-lg transition-colors duration-300"
            >
              Cancel
            </button>
            <button
              onClick={handleUpload}
              disabled={!preview || !!error}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 disabled:bg-slate-600 disabled:cursor-not-allowed"
            >
              Save
            </button>
          </div>
          
          {isCustomLogo && (
             <button
              onClick={handleRemove}
              className="w-full text-center text-red-400 hover:text-red-300 text-xs mt-4"
            >
              Remove Custom Logo
            </button>
          )}
        </div>
      </div>
    </>
  );
};

export default LogoUploader;
