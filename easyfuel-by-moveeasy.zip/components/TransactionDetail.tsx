import React from 'react';
import { TransactionHistoryItem, Station, Transaction } from '../types';
import QRCode from './QRCode';
import StationLogo from './StationLogo';

interface TransactionDetailProps {
  item: Transaction | TransactionHistoryItem;
  station: Station;
  onClose: () => void;
}

const DetailRow: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="flex justify-between items-center py-3 border-b border-slate-700/50">
    <span className="text-slate-400 text-sm">{label}</span>
    <span className="font-medium text-slate-100 text-right">{children}</span>
  </div>
);

const TransactionDetail: React.FC<TransactionDetailProps> = ({ item, station, onClose }) => {
  const date = new Date(item.date);
  const referenceId = 'referenceId' in item ? item.referenceId : item.id;
  const status = 'status' in item ? item.status : undefined;

  const isVoucherUsed = item.type === 'purchase' && status === 'used';

  return (
    <div className="absolute inset-0 bg-slate-900 z-10 flex flex-col animate-fade-in">
        <header className="flex items-center justify-between p-4 border-b border-slate-700 sticky top-0 bg-slate-900">
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
            </button>
            <h3 className="text-xl font-bold">Details</h3>
            <div className="w-10"></div> {/* Spacer */}
        </header>

        <div className="flex-grow overflow-y-auto p-4">
            <div className="flex flex-col items-center mb-6">
                <StationLogo logo={station.logo} stationName={station.name} className="h-16 w-16 object-contain mb-3" />
                <p className="text-2xl font-bold">{station?.name}</p>
                <p className="text-4xl font-bold text-emerald-400 mt-2">
                    - R {item.amount.toFixed(2)}
                </p>
            </div>
            
            {(item.qrData || item.qrArtUrl) && (
                <div className="mb-6 space-y-3">
                    <h4 className="text-md font-semibold text-slate-300 text-center">Payment Voucher</h4>
                    <div className="flex justify-center p-4 bg-slate-800 rounded-xl relative">
                        {item.qrArtUrl ? (
                            <div className={`relative w-full max-w-[256px] aspect-square rounded-lg overflow-hidden border-2 border-slate-600 shadow-lg ${isVoucherUsed ? 'opacity-40' : ''}`}>
                                <img src={item.qrArtUrl} alt="QR Art background" className="absolute inset-0 w-full h-full object-cover" />
                                <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm">
                                    {item.qrData && <QRCode data={item.qrData} />}
                                </div>
                            </div>
                        ) : item.qrData ? (
                            <div className={isVoucherUsed ? 'opacity-40' : ''}>
                                <QRCode data={item.qrData} />
                            </div>
                        ) : null}

                        {isVoucherUsed && (
                            <div className="absolute inset-0 flex items-center justify-center">
                                <span className="bg-slate-900 text-slate-200 font-bold text-lg px-6 py-2 rounded-lg transform -rotate-12 border-2 border-slate-600 shadow-lg">USED</span>
                            </div>
                        )}
                    </div>
                    {item.type === 'purchase' && item.qrData && (
                        <p className="text-xs text-slate-500 text-center">
                            Status: <span className="font-semibold capitalize">{status || 'Active'}</span>
                        </p>
                    )}
                </div>
            )}


            <div className="bg-slate-800 rounded-lg p-4 space-y-1">
                <DetailRow label="Date & Time">
                    {date.toLocaleString('en-ZA', { dateStyle: 'long', timeStyle: 'short' })}
                </DetailRow>
                <DetailRow label="Payment Type">
                    <span className={`capitalize px-2 py-1 rounded-full text-xs font-semibold ${item.type === 'voucher' ? 'bg-amber-500/20 text-amber-300' : 'bg-sky-500/20 text-sky-300'}`}>
                        {item.type}
                    </span>
                </DetailRow>
                {item.tokenId && (
                    <DetailRow label="Token ID">
                        <span className="font-mono text-xs bg-slate-700 px-2 py-1 rounded">{item.tokenId}</span>
                    </DetailRow>
                )}
                <DetailRow label="Reference ID">
                    <span className="font-mono text-xs bg-slate-700 px-2 py-1 rounded">{referenceId}</span>
                </DetailRow>
            </div>
        </div>
    </div>
  );
};

export default TransactionDetail;
