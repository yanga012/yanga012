import React, { useState, useEffect } from 'react';
import { getSession, signOut, verifyUserAccount } from './services/api';
import type { User } from './types';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import LoaderIcon from './components/icons/LoaderIcon';
import CheckCircleIcon from './components/icons/CheckCircleIcon';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [verificationStatus, setVerificationStatus] = useState<{ status: 'idle' | 'loading' | 'success' | 'error', message: string }>({ status: 'idle', message: '' });

  useEffect(() => {
    const checkSession = async () => {
      try {
        const sessionUser = await getSession();
        setUser(sessionUser);
      } catch (error) {
        console.error("Session check failed", error);
      } finally {
        setLoading(false);
      }
    };

    const checkVerification = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const email = urlParams.get('email');
      const token = urlParams.get('token');

      if (email && token) {
        setVerificationStatus({ status: 'loading', message: 'Verifying your account...' });
        try {
          const verifiedUser = await verifyUserAccount(email, token);
          // Automatically sign in the user and proceed
          handleAuthSuccess(verifiedUser);
        } catch (err: any) {
          setVerificationStatus({ status: 'error', message: err.message || 'Verification failed.' });
        }
        // Clean the URL
        window.history.replaceState({}, document.title, window.location.pathname);
      } else {
        checkSession();
      }
    };

    checkVerification();
  }, []);

  const handleAuthSuccess = (authedUser: User) => {
    setUser(authedUser);
    setVerificationStatus({ status: 'idle', message: '' });
  };

  const handleLogout = () => {
    signOut();
    setUser(null);
  };
  
  const renderVerificationMessage = () => (
     <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <main className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg max-w-sm w-full text-center">
            <header className="flex flex-col items-center text-center pb-6 border-b border-slate-200">
                {verificationStatus.status === 'loading' && <LoaderIcon className="h-12 w-12 text-teal-500 mb-4" />}
                {verificationStatus.status === 'success' && <CheckCircleIcon className="h-12 w-12 text-green-500 mb-4" />}
                {verificationStatus.status === 'error' && <div className="h-12 w-12 flex items-center justify-center text-red-500 mb-4 text-4xl font-bold">!</div>}
                <h1 className="text-2xl font-bold text-slate-800">Account Verification</h1>
            </header>
            <div className="mt-6">
                <p className="text-slate-600">{verificationStatus.message}</p>
                 <button
                    onClick={() => {
                        setVerificationStatus({ status: 'idle', message: '' });
                        setLoading(true);
                        getSession().then(setUser).finally(() => setLoading(false));
                    }}
                    className="w-full mt-6 px-4 py-3 text-base font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700"
                >
                    Continue to Sign In
                </button>
            </div>
        </main>
    </div>
  );

  if (verificationStatus.status !== 'idle') {
    return renderVerificationMessage();
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoaderIcon className="h-12 w-12 text-teal-500" />
      </div>
    );
  }

  return user ? (
    <Dashboard user={user} onLogout={handleLogout} />
  ) : (
    <Auth onAuthSuccess={handleAuthSuccess} />
  );
}

export default App;