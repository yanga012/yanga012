import React from 'react';
import { Station } from './types';

const EngenLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="60" height="40" rx="4" fill="#E6332A"/>
    <path d="M15 10H25L20 20L25 30H15L20 20L15 10Z" fill="white"/>
    <text x="30" y="26" fontFamily="Arial, sans-serif" fontSize="14" fontWeight="bold" fill="white">ENGEN</text>
  </svg>
);

const ShellLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="60" height="40" rx="4" fill="#FFD500"/>
    <path d="M30 10 C 20 10, 15 20, 15 25 C 15 35, 30 40, 30 30 C 30 40, 45 35, 45 25 C 45 20, 40 10, 30 10 Z" fill="#D83128"/>
    <path d="M30 13 V 30 M 20 18 H 40 M 22 22 H 38 M 24 26 H 36" stroke="white" strokeWidth="2"/>
  </svg>
);

const BPLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
 <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="60" height="40" rx="4" fill="#009B4D"/>
    <circle cx="30" cy="20" r="12" fill="#FFD100"/>
    <path d="M30 8 L 30 32" stroke="#009B4D" strokeWidth="4" />
    <path d="M18 20 L 42 20" stroke="#009B4D" strokeWidth="4" />
    <circle cx="30" cy="20" r="6" fill="#009B4D"/>
    <circle cx="30" cy="20" r="3" fill="#FFD100"/>
  </svg>
);

const SasolLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="60" height="40" rx="4" fill="#0072CE"/>
    <path d="M20 10 L 40 10 L 30 30 Z" fill="white"/>
    <path d="M25 20 L 35 20" stroke="#0072CE" strokeWidth="2"/>
  </svg>
);

const TotalLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="60" height="40" rx="4" fill="#EF4036"/>
    <path d="M15 20 A 15 10 0 0 1 45 20" stroke="white" strokeWidth="5" fill="none"/>
    <path d="M20 20 A 10 7 0 0 1 40 20" stroke="#00559F" strokeWidth="5" fill="none"/>
    <path d="M25 20 A 5 4 0 0 1 35 20" stroke="#FFCD00" strokeWidth="4" fill="none"/>
  </svg>
);

const CaltexLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="60" height="40" rx="4" fill="#E30613"/>
    <rect y="20" width="60" height="20" fill="#003893"/>
    <text x="30" y="26" fontFamily="Arial, sans-serif" fontSize="14" fontWeight="bold" fill="white" textAnchor="middle">CALTEX</text>
  </svg>
);

const PioneerLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg width="60" height="40" viewBox="0 0 60 40" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="60" height="40" rx="4" fill="#228B22"/>
    <text x="30" y="26" fontFamily="Arial, sans-serif" fontSize="14" fontWeight="bold" fill="white" textAnchor="middle">PIONEER</text>
  </svg>
);


export const STATIONS: Station[] = [
  { id: 'engen', name: 'Engen', logo: EngenLogo },
  { id: 'shell', name: 'Shell', logo: ShellLogo },
  { id: 'bp', name: 'BP', logo: BPLogo },
  { id: 'sasol', name: 'Sasol', logo: SasolLogo },
  { id: 'total', name: 'TotalEnergies', logo: TotalLogo },
  { id: 'caltex', name: 'Caltex', logo: CaltexLogo },
  { id: 'pioneer', name: 'Pioneer', logo: PioneerLogo },
];

export const ROUTING_CONFIG: Record<string, 'direct' | 'payment24'> = {
  'engen': 'direct',
  'shell': 'payment24',
  'bp': 'payment24',
  'sasol': 'direct',
  'total': 'payment24',
  'caltex': 'payment24',
  'pioneer': 'direct',
};