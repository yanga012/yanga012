// components/EmailVerification.tsx
import React, { useState, useEffect } from 'react';
import MailIcon from './icons/MailIcon';
import LoaderIcon from './icons/LoaderIcon';
import type { User } from '../types';
import * as api from '../services/api';

interface EmailVerificationProps {
  user: User;
  onVerified: (user: User) => void;
  onLogout: () => void;
}

const EmailVerification: React.FC<EmailVerificationProps> = ({ user, onVerified, onLogout }) => {
  const [code, setCode] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [resendMessage, setResendMessage] = useState('');

  const handleSendCode = async () => {
    setIsSending(true);
    setError('');
    setResendMessage('');
    try {
      await api.sendVerificationCode(user.email);
      setResendMessage('A new verification code has been sent.');
    } catch (err) {
      setError('Failed to send code. Please try again.');
    } finally {
      setIsSending(false);
    }
  };
  
  // Send code on initial component mount
  useEffect(() => {
    handleSendCode();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      setIsVerifying(true);
      setError('');
      try {
          const updatedUser = await api.verifyEmailCode(user.email, code);
          onVerified(updatedUser);
      } catch (err) {
          setError(err instanceof Error ? err.message : 'Verification failed.');
      } finally {
          setIsVerifying(false);
      }
  };

  return (
    <div className="w-full max-w-md">
      <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
        <p className="text-sm font-semibold text-teal-600 mb-2">STEP 1 OF 2</p>
        <div className="flex justify-center mb-4">
          <div className="p-3 bg-teal-100 rounded-full">
            <MailIcon className="h-8 w-8 text-teal-600" />
          </div>
        </div>
        <h1 className="text-2xl font-bold text-slate-800">Verify Your Email</h1>
        <p className="text-sm text-slate-500 mt-2">
          We've sent a 6-digit code to <span className="font-semibold text-slate-700">{user.email}</span>. Please enter it below.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
                <label htmlFor="code" className="sr-only">Verification Code</label>
                <input 
                    id="code"
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    maxLength={6}
                    className="w-full px-4 py-3 text-center text-lg tracking-[0.5em] font-bold border rounded-lg focus:ring-teal-500 focus:border-teal-500"
                    placeholder="______"
                    required
                />
            </div>
             {error && <p className="text-sm text-red-600">{error}</p>}
            <button
                type="submit"
                disabled={isVerifying || code.length < 6}
                className="w-full px-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-teal-400 flex items-center justify-center"
            >
                {isVerifying ? <LoaderIcon className="h-5 w-5"/> : 'Verify Email'}
            </button>
        </form>
        <div className="mt-4 text-sm">
             <button onClick={handleSendCode} disabled={isSending} className="text-teal-600 hover:underline disabled:text-slate-500">
                {isSending ? 'Sending...' : 'Resend Code'}
            </button>
            {resendMessage && <p className="text-green-600 mt-1">{resendMessage}</p>}
        </div>
      </div>
      <div className="text-center mt-4">
        <p className="text-sm text-slate-600">
          Wrong account?{' '}
          <button onClick={onLogout} className="font-semibold text-teal-600 hover:underline">
            Log Out
          </button>
        </p>
      </div>
    </div>
  );
};

export default EmailVerification;