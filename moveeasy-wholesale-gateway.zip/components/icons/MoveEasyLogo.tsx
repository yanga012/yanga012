
import React from 'react';
const MoveEasyLogo: React.FC<{ className?: string }> = ({ className }) => (
    <div className={`flex items-center font-bold text-2xl ${className}`}>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-7 w-7 mr-2">
            <path d="M5 18H3c-.6 0-1-.4-1-1V8c0-.6.4-1 1-1h10c.6 0 1 .4 1 1v1"/>
            <path d="M14 9h4c.6 0 1 .4 1 1v4c0 .6-.4 1-1 1h-2"/>
            <path d="M20 17.5c0 .9-.7 1.6-1.6 1.6h-1.8a1.6 1.6 0 0 1-1.6-1.6V16c0-.9.7-1.6 1.6-1.6h1.8a1.6 1.6 0 0 1 1.6 1.6v.1"/>
            <path d="M7.5 17.5c0 .9-.7 1.6-1.6 1.6H4.1c-.9 0-1.6-.7-1.6-1.6V16c0-.9.7-1.6 1.6-1.6h1.8c.9 0 1.6.7 1.6 1.6v.1"/>
            <path d="M16 8V5c0-.6-.4-1-1-1H6.5a1 1 0 0 0-1 1v3"/>
            <path d="m10 14-1.3-1.3"/>
            <path d="M8 12.5 5 10"/>
        </svg>
        <span className="text-slate-800">MoveEasy</span>
    </div>
);
export default MoveEasyLogo;
