
import React from 'react';
const StoreIcon: React.FC<{ className?: string }> = ({ className = "h-6 w-6" }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 6L2 6" />
    <path d="M2 6L2 22" />
    <path d="M18 6V22" />
    <path d="M10 12L10 22" />
    <path d="M6 12L6 22" />
    <path d="M14 12L14 22" />
    <path d="M18 6L10 2 2 6" />
  </svg>
);
export default StoreIcon;
