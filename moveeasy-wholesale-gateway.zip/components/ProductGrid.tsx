import React, { useState } from 'react';
import type { Product, Category } from '../types';
import ProductCard from './ProductCard';
import LoaderIcon from './icons/LoaderIcon';

interface ProductGridProps {
  products: Product[];
  categories: Category[];
  isLoading: boolean;
  onSearch: (query: string, category: string) => void;
  onAddToCart: (productId: number, quantity: number) => void;
  onSelectProduct: (productId: number) => void;
  isLimitedAccess: boolean;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, categories, isLoading, onSearch, onAddToCart, onSelectProduct, isLimitedAccess }) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query, selectedCategory);
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-white p-4 sm:p-6 rounded-2xl shadow-lg">
        <h2 className="text-2xl font-bold text-slate-800">Product Catalog</h2>
        <p className="text-sm text-slate-500 mt-1">Browse verified wholesale products.</p>
        <form onSubmit={handleSearch} className="mt-4 flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products..."
            className="flex-grow px-4 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500"
          />
          <select 
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="px-4 py-2 border rounded-lg bg-white focus:ring-teal-500 focus:border-teal-500"
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
                <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
          <button type="submit" className="px-6 py-2 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700">
            Search
          </button>
        </form>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center p-12">
          <LoaderIcon className="h-12 w-12 text-teal-600"/>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map(product => (
            <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} onSelectProduct={onSelectProduct} isLimitedAccess={isLimitedAccess}/>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductGrid;
