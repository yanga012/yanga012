import React, { useState } from 'react';
import type { User, KycDetails } from '../types';
import * as api from '../services/api';
import ShieldCheckIcon from './icons/ShieldCheckIcon';
import LoaderIcon from './icons/LoaderIcon';

interface VerificationGateProps {
  user: User;
  onKycSubmitted: (user: User) => void;
  onSkip: () => void;
}

const VerificationGate: React.FC<VerificationGateProps> = ({ user, onKycSubmitted, onSkip }) => {
    const [kycDetails, setKycDetails] = useState<KycDetails>({
        businessName: '',
        registrationNumber: '',
        vatNumber: '',
        permitUrl: '',
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setKycDetails({ ...kycDetails, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');
        try {
            const updatedUser = await api.submitKyc(user.id, kycDetails);
            onKycSubmitted(updatedUser);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'KYC submission failed.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="w-full max-w-md">
            <div className="bg-white rounded-2xl shadow-xl">
                <div className="p-8 text-center border-b">
                    <p className="text-sm font-semibold text-teal-600 mb-2">STEP 2 OF 2</p>
                     <div className="flex justify-center mb-4">
                        <div className="p-3 bg-teal-100 rounded-full">
                            <ShieldCheckIcon className="h-8 w-8 text-teal-600" />
                        </div>
                    </div>
                    <h1 className="text-2xl font-bold text-slate-800">Complete Verification</h1>
                    <p className="text-sm text-slate-500 mt-2">
                        To ensure a secure B2B marketplace, we need to verify your business identity. This quick step helps build a trusted network and unlocks full access to placing orders and starting group buys.
                    </p>
                    <div className="text-left mt-4 bg-slate-50 p-4 rounded-lg text-sm">
                      <p className="font-semibold text-slate-700 mb-2">Please have the following ready:</p>
                      <ul className="list-disc list-inside text-slate-600 space-y-1">
                          <li>Your Business Name</li>
                          {user.role === 'Source' && <li>Business Registration Number</li>}
                      </ul>
                    </div>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-8 space-y-4">
                        <div>
                            <label htmlFor="businessName" className="block text-sm font-medium text-slate-600 mb-1">Business Name</label>
                            <input id="businessName" name="businessName" type="text" value={kycDetails.businessName} onChange={handleChange} required className="w-full px-3 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500" />
                        </div>
                        {user.role === 'Source' && (
                             <>
                                <div>
                                    <label htmlFor="registrationNumber" className="block text-sm font-medium text-slate-600 mb-1">Business Registration No.</label>
                                    <input id="registrationNumber" name="registrationNumber" type="text" value={kycDetails.registrationNumber} onChange={handleChange} required className="w-full px-3 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500" />
                                </div>
                                <div>
                                    <label htmlFor="vatNumber" className="block text-sm font-medium text-slate-600 mb-1">VAT Number (Optional)</label>
                                    <input id="vatNumber" name="vatNumber" type="text" value={kycDetails.vatNumber} onChange={handleChange} className="w-full px-3 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500" />
                                </div>
                                <div>
                                    <label htmlFor="permitUrl" className="block text-sm font-medium text-slate-600 mb-1">Supplier Permit URL (Optional)</label>
                                    <input id="permitUrl" name="permitUrl" type="url" value={kycDetails.permitUrl} onChange={handleChange} className="w-full px-3 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500" />
                                </div>
                             </>
                        )}
                        {error && <p className="text-sm text-red-600">{error}</p>}
                    </div>
                    <div className="bg-slate-50 p-4 flex flex-col sm:flex-row-reverse justify-between items-center gap-3 rounded-b-2xl">
                        <button type="submit" disabled={isLoading} className="w-full sm:w-auto px-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-teal-400 flex items-center justify-center min-w-[120px]">
                           {isLoading ? <LoaderIcon className="h-5 w-5" /> : 'Submit for Verification'}
                        </button>
                        <button type="button" onClick={onSkip} className="w-full sm:w-auto px-4 py-3 font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100">
                            Skip for now
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default VerificationGate;