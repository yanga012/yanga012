import React, { useState } from 'react';
import type { Product } from '../types';
import { formatCurrency } from '../types';
import ShoppingCartIcon from './icons/ShoppingCartIcon';
import CheckIcon from './icons/CheckIcon';

interface ProductCardProps {
  product: Product;
  onAddToCart: (productId: number, quantity: number) => void;
  onSelectProduct: (productId: number) => void;
  isLimitedAccess?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onSelectProduct, isLimitedAccess }) => {
  const [quantity, setQuantity] = useState(product.minOrderQuantity);
  const [added, setAdded] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isLimitedAccess) return;
    onAddToCart(product.id, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setQuantity(Math.max(product.minOrderQuantity, Number(e.target.value)));
  };

  const handleCardClick = () => {
    onSelectProduct(product.id);
  };

  return (
    <div onClick={handleCardClick} className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col cursor-pointer overflow-hidden">
      <div className="h-48 overflow-hidden">
        <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="font-bold text-slate-800 text-md truncate flex-grow">{product.name}</h3>
        <p className="text-sm text-slate-500 mt-1">MOQ: {product.minOrderQuantity} units</p>
        <p className="text-xl font-extrabold text-slate-900 mt-2">{formatCurrency(product.price)}</p>
      </div>
      <div className="p-4 bg-slate-50/50 flex items-center gap-2">
         <input
          type="number"
          value={quantity}
          min={product.minOrderQuantity}
          onChange={handleQuantityChange}
          onClick={(e) => e.stopPropagation()} // Prevent card click
          className="w-20 p-2 border rounded-lg text-center font-semibold"
          disabled={isLimitedAccess}
        />
        <button
          onClick={handleAddToCart}
          disabled={isLimitedAccess || added}
          title={isLimitedAccess ? "Verify your account to transact" : "Add to cart"}
          className={`w-full px-3 py-2 font-bold text-white rounded-lg flex items-center justify-center transition-colors ${
            added ? 'bg-green-500' : isLimitedAccess ? 'bg-slate-400 cursor-not-allowed' : 'bg-teal-600 hover:bg-teal-700'
          }`}
        >
          {added ? <CheckIcon className="h-5 w-5"/> : <ShoppingCartIcon className="h-5 w-5"/>}
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
