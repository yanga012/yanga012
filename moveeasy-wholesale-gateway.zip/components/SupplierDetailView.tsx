import React from 'react';
import type { Supplier, Product } from '../types';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import BadgeCheckIcon from './icons/BadgeCheckIcon';
import ProductCard from './ProductCard';

interface SupplierDetailViewProps {
  supplier: Supplier;
  products: Product[];
  onBack: () => void;
  onSelectProduct: (productId: number) => void;
  onAddToCart: (productId: number, quantity: number) => void;
  isLimitedAccess: boolean;
}

const SupplierDetailView: React.FC<SupplierDetailViewProps> = ({ supplier, products, onBack, onSelectProduct, onAddToCart, isLimitedAccess }) => {
  const supplierProducts = products.filter(p => p.supplierId === supplier.id);

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-800 mb-4">
        <ArrowLeftIcon className="h-4 w-4" />
        Back
      </button>

      <div className="bg-white p-6 rounded-2xl shadow-lg mb-6">
        <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold text-slate-800">{supplier.name}</h1>
            {supplier.isVerified && <BadgeCheckIcon className="h-6 w-6 text-blue-500" />}
        </div>
        <p className="text-slate-500 mt-1">{supplier.location}</p>
        {supplier.isVerified ? (
            <p className="text-sm text-green-700 mt-2 font-medium">This supplier is verified by MoveEasy.</p>
        ) : (
            <p className="text-sm text-yellow-700 mt-2 font-medium">This supplier has not yet been verified.</p>
        )}
      </div>

      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Products from this supplier</h2>
        {supplierProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {supplierProducts.map(product => (
                    <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} onSelectProduct={onSelectProduct} isLimitedAccess={isLimitedAccess}/>
                ))}
            </div>
        ) : (
            <div className="text-center py-8 bg-white rounded-lg shadow-sm">
                <p className="text-slate-500">No products found for this supplier.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default SupplierDetailView;
