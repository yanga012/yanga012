import React, { useState } from 'react';
import type { Stokvel, Product, Supplier, User } from '../types';
import { formatCurrency } from '../types';
import * as api from '../services/api';
import LoaderIcon from './icons/LoaderIcon';
import MapPinIcon from './icons/MapPinIcon';
import UsersIcon from './icons/UsersIcon';

interface StokvelCardProps {
    user: User;
    stokvel: Stokvel;
    product: Product;
    supplier: Supplier | undefined;
    onJoinSuccess: () => void;
    isLimitedAccess: boolean;
}

const StokvelCard: React.FC<StokvelCardProps> = ({ user, stokvel, product, supplier, onJoinSuccess, isLimitedAccess }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    
    const progressPercentage = Math.min((stokvel.currentQuantity / stokvel.targetQuantity) * 100, 100);
    const hasJoined = stokvel.members.some(member => member.userId === user.id);

    const handleJoin = async () => {
        if (isLimitedAccess) return;
        setIsLoading(true);
        setError('');
        try {
            await api.joinStokvel(user.id, stokvel.id);
            onJoinSuccess();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to join group buy.');
        } finally {
            setIsLoading(false);
        }
    };

    const daysLeft = Math.max(0, Math.ceil((new Date(stokvel.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)));

    return (
        <div className="bg-white rounded-2xl shadow-lg flex flex-col overflow-hidden">
            <img src={product.imageUrl} alt={product.name} className="w-full h-40 object-cover" />
            <div className="p-4 flex-grow flex flex-col">
                <p className="text-xs font-bold text-teal-600 uppercase">{daysLeft} Days Left</p>
                <h4 className="font-bold text-slate-800 mt-1 flex-grow">{product.name}</h4>
                
                <div className="text-sm text-slate-500 mt-2">
                    <div className="flex items-center gap-1.5">
                        <UsersIcon className="h-4 w-4 flex-shrink-0" />
                        <span>{stokvel.members.length} Merchants</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                        <MapPinIcon className="h-4 w-4 flex-shrink-0" />
                        <span>{stokvel.region}</span>
                    </div>
                </div>

                <div className="mt-4">
                    <div className="flex justify-between items-baseline text-xs font-medium text-slate-600">
                        <span>{formatCurrency(stokvel.currentQuantity * product.price)} raised</span>
                        <span className="font-bold">{formatCurrency(stokvel.targetQuantity * product.price)}</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                        <div 
                            className="bg-teal-500 h-2 rounded-full" 
                            style={{ width: `${progressPercentage}%` }}
                        ></div>
                    </div>
                    <p className="text-xs text-center text-slate-500 mt-1">{progressPercentage.toFixed(0)}% of target</p>
                </div>

                {error && <p className="text-xs text-red-600 mt-2">{error}</p>}
                
                <div className="mt-4">
                    {hasJoined ? (
                        <button disabled className="w-full px-4 py-2 font-bold text-green-800 bg-green-100 rounded-lg text-sm">
                            You've Joined!
                        </button>
                    ) : (
                         <button 
                            onClick={handleJoin}
                            disabled={isLoading || isLimitedAccess}
                            title={isLimitedAccess ? "Verify your account to join group buys" : ""}
                            className="w-full px-4 py-2 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-teal-400 disabled:cursor-not-allowed text-sm flex items-center justify-center min-h-[36px]"
                        >
                           {isLoading ? <LoaderIcon className="h-5 w-5"/> : `Join (Contribute MOQ: ${product.minOrderQuantity})`}
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default StokvelCard;
