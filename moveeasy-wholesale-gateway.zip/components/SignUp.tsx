import React, { useState } from 'react';
import MoveEasyLogo from './icons/MoveEasyLogo';
import LoaderIcon from './icons/LoaderIcon';
import { User } from '../types';

interface SignUpProps {
  onSignUp: (name: string, email: string, pass: string, region: User['region'], role: User['role']) => Promise<void>;
  onSwitchToLogin: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ onSignUp, onSwitchToLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [region, setRegion] = useState<User['region']>('Gauteng');
  const [role, setRole] = useState<User['role']>('Trader');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (password.length < 6) {
        setError('Password must be at least 6 characters long.');
        return;
    }
    setIsLoading(true);
    try {
      await onSignUp(name, email, password, region, role);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const roleCardClasses = (selectedRole: User['role']) => 
    `p-4 text-left rounded-lg border-2 transition-colors cursor-pointer w-full ${
        role === selectedRole 
        ? 'bg-teal-50 border-teal-600' 
        : 'bg-white border-slate-300 hover:border-teal-400'
    }`;

  return (
    <div className="w-full max-w-sm">
      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex flex-col items-center mb-6">
            <MoveEasyLogo className="text-teal-600 mb-2"/>
            <h1 className="text-2xl font-bold text-slate-800">Create Account</h1>
            <p className="text-sm text-slate-500">Join the MoveEasy merchant network.</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-2">I am a...</label>
            <div className="grid grid-cols-1 gap-2">
                <button type="button" onClick={() => setRole('Trader')} className={roleCardClasses('Trader')}>
                    <h3 className="font-semibold text-slate-800">Trader (Merchant)</h3>
                    <p className="text-xs text-slate-500">I buy wholesale products for my business.</p>
                </button>
                <button type="button" onClick={() => setRole('Source')} className={roleCardClasses('Source')}>
                    <h3 className="font-semibold text-slate-800">Source (Supplier)</h3>
                    <p className="text-xs text-slate-500">I supply wholesale products and deals.</p>
                </button>
            </div>
          </div>
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-slate-600 mb-1">Full Name</label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500"
              required
            />
          </div>
          <div>
            <label htmlFor="email-signup" className="block text-sm font-medium text-slate-600 mb-1">Email Address</label>
            <input
              id="email-signup"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500"
              required
            />
          </div>
          <div>
            <label htmlFor="password-signup" className="block text-sm font-medium text-slate-600 mb-1">Password</label>
            <input
              id="password-signup"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500"
              required
            />
          </div>
           <div>
            <label htmlFor="region" className="block text-sm font-medium text-slate-600 mb-1">Region</label>
            <select
                id="region"
                value={region}
                onChange={(e) => setRegion(e.target.value as User['region'])}
                className="w-full px-4 py-2 border rounded-lg bg-white focus:ring-teal-500 focus:border-teal-500"
                required
            >
                <option>Gauteng</option>
                <option>Western Cape</option>
                <option>KwaZulu-Natal</option>
                <option>Eastern Cape</option>
            </select>
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full px-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-teal-400 flex items-center justify-center"
          >
            {isLoading ? <LoaderIcon className="h-5 w-5"/> : 'Sign Up'}
          </button>
        </form>
      </div>
      <div className="text-center mt-4">
        <p className="text-sm text-slate-600">
          Already have an account?{' '}
          <button onClick={onSwitchToLogin} className="font-semibold text-teal-600 hover:underline">
            Log In
          </button>
        </p>
      </div>
    </div>
  );
};

export default SignUp;