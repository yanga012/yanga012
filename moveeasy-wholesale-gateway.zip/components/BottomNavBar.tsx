// Fix: Added full content for the BottomNavBar component.
import React from 'react';
import StoreIcon from './icons/StoreIcon';
import SparklesIcon from './icons/SparklesIcon';
import UsersIcon from './icons/UsersIcon';
import ListIcon from './icons/ListIcon';
import ShoppingCartIcon from './icons/ShoppingCartIcon';

type View = 'catalog' | 'sourcing' | 'stokvels' | 'orders' | 'cart';

interface NavItemProps {
    label: string;
    icon: React.ReactNode;
    isActive: boolean;
    onClick: () => void;
    badgeCount?: number;
}

const NavItem: React.FC<NavItemProps> = ({ label, icon, isActive, onClick, badgeCount }) => {
    const activeClass = isActive ? 'text-teal-600' : 'text-slate-500 hover:text-teal-600';
    return (
        <button onClick={onClick} className={`flex flex-col items-center justify-center gap-1 text-xs font-medium transition-colors relative ${activeClass}`}>
            {badgeCount && badgeCount > 0 ? (
                <span className="absolute -top-1 right-1.5 h-4 w-4 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center">
                    {badgeCount}
                </span>
            ) : null}
            {icon}
            <span>{label}</span>
        </button>
    );
};

interface BottomNavBarProps {
  activeView: View;
  onSwitchView: (view: View) => void;
  cartCount: number;
}

const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeView, onSwitchView, cartCount }) => {
  const navItems: { view: View; label: string; icon: React.ReactNode, badge?: number }[] = [
    { view: 'catalog', label: 'Catalog', icon: <StoreIcon /> },
    { view: 'sourcing', label: 'AI Source', icon: <SparklesIcon /> },
    { view: 'stokvels', label: 'Group Buys', icon: <UsersIcon /> },
    { view: 'orders', label: 'Orders', icon: <ListIcon /> },
    { view: 'cart', label: 'Cart', icon: <ShoppingCartIcon />, badge: cartCount },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-slate-200 shadow-t-lg z-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex justify-around items-center">
        {navItems.map(item => (
            <NavItem 
                key={item.view}
                label={item.label}
                icon={item.icon}
                isActive={activeView === item.view}
                onClick={() => onSwitchView(item.view)}
                badgeCount={item.badge}
            />
        ))}
      </div>
    </nav>
  );
};

export default BottomNavBar;