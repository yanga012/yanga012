import React, { useState } from 'react';
import type { Product, Supplier, User } from '../types';
import { formatCurrency } from '../types';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import BadgeCheckIcon from './icons/BadgeCheckIcon';
import BuildingStorefrontIcon from './icons/BuildingStorefrontIcon';
import MapPinIcon from './icons/MapPinIcon';
import CreateStokvelModal from './CreateStokvelModal';

interface ProductDetailViewProps {
  user: User;
  product: Product;
  supplier: Supplier;
  onBack: () => void;
  onAddToCart: (productId: number, quantity: number) => void;
  onSelectSupplier: (supplierId: number) => void;
  onStokvelCreated: () => void;
  isLimitedAccess: boolean;
}

const ProductDetailView: React.FC<ProductDetailViewProps> = ({ user, product, supplier, onBack, onAddToCart, onSelectSupplier, onStokvelCreated, isLimitedAccess }) => {
  const [quantity, setQuantity] = useState(product.minOrderQuantity);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const handleInitiateStokvel = () => {
      if (isLimitedAccess) return;
      setIsModalOpen(true);
  }

  return (
    <div>
        {isModalOpen && <CreateStokvelModal user={user} product={product} onClose={() => setIsModalOpen(false)} onStokvelCreated={onStokvelCreated} />}
      
      <button onClick={onBack} className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-800 mb-4">
        <ArrowLeftIcon className="h-4 w-4" />
        Back to catalog
      </button>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <img src={product.imageUrl} alt={product.name} className="w-full h-auto rounded-2xl shadow-lg object-cover aspect-square" />
        </div>
        
        <div className="space-y-6">
            <div className="p-6 bg-white rounded-2xl shadow-lg">
                <h1 className="text-3xl font-bold text-slate-800">{product.name}</h1>
                <p className="text-3xl font-extrabold text-slate-900 mt-2">{formatCurrency(product.price)} <span className="text-base font-normal text-slate-500">/ unit</span></p>
                <p className="text-md text-slate-600 mt-1">Minimum Order: <span className="font-semibold">{product.minOrderQuantity} units</span></p>
                <p className="text-sm text-slate-500 mt-4">{product.description}</p>
            </div>
            
            <div className="p-6 bg-white rounded-2xl shadow-lg">
                <h2 className="font-bold text-slate-800 mb-3">Purchase Options</h2>
                <div className="flex items-center gap-2 mb-4">
                    <label htmlFor="quantity" className="text-sm font-medium">Quantity:</label>
                    <input 
                        id="quantity"
                        type="number"
                        value={quantity}
                        onChange={e => setQuantity(Math.max(product.minOrderQuantity, Number(e.target.value)))}
                        min={product.minOrderQuantity}
                        className="w-24 p-2 border rounded-lg text-center font-semibold"
                        disabled={isLimitedAccess}
                    />
                </div>
                 <button 
                    onClick={() => onAddToCart(product.id, quantity)}
                    disabled={isLimitedAccess}
                    title={isLimitedAccess ? "Verify your account to add to cart" : ""}
                    className="w-full px-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 disabled:cursor-not-allowed"
                 >
                    Add to Cart
                </button>
                <button 
                    onClick={handleInitiateStokvel}
                    disabled={isLimitedAccess}
                    title={isLimitedAccess ? "Verify your account to start a group buy" : ""}
                    className="w-full mt-2 px-4 py-3 font-bold text-teal-700 bg-teal-100 rounded-lg hover:bg-teal-200 disabled:bg-slate-200 disabled:text-slate-500 disabled:cursor-not-allowed"
                >
                    Start a Group Buy
                </button>
            </div>
            
             <div className="p-6 bg-white rounded-2xl shadow-lg cursor-pointer hover:bg-slate-50" onClick={() => onSelectSupplier(supplier.id)}>
                <h2 className="font-bold text-slate-800 mb-3">Supplier Information</h2>
                <div className="flex items-center gap-3">
                    <BuildingStorefrontIcon className="h-8 w-8 text-teal-600"/>
                    <div>
                        <div className="flex items-center gap-2">
                            <p className="font-semibold text-slate-700">{supplier.name}</p>
                            {supplier.isVerified && <BadgeCheckIcon className="h-5 w-5 text-blue-500" />}
                        </div>
                         <div className="flex items-center gap-1.5 text-sm text-slate-500">
                             <MapPinIcon className="h-4 w-4" />
                             {supplier.location}
                         </div>
                    </div>
                </div>
                 <p className="text-sm text-right text-teal-600 font-semibold mt-2">View all products from this supplier &rarr;</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailView;
