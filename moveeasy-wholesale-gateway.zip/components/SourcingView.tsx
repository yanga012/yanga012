
import React, { useState } from 'react';
import type { User, SourcingRequest, Product } from '../types';
import { formatCurrency } from '../types';
import { createSourcingRequest } from '../services/api';
import LoaderIcon from './icons/LoaderIcon';

const FoundProductCard: React.FC<{ product: Product; onAddToCart: (productId: number, quantity: number) => void; }> = ({ product, onAddToCart }) => {
    const [quantity, setQuantity] = useState(product.minOrderQuantity);

    const handleAddToCartClick = () => {
        onAddToCart(product.id, quantity);
    };

    return (
        <div className="flex items-center gap-4 p-2 bg-slate-50 rounded-lg">
            <img src={product.imageUrl} alt={product.name} className="w-16 h-16 rounded-md object-cover flex-shrink-0" />
            <div className="flex-grow min-w-0">
                <p className="font-semibold text-slate-800 text-sm truncate">{product.name}</p>
                <p className="text-slate-600 font-bold text-sm">{formatCurrency(product.price)}</p>
                <p className="text-xs text-slate-500">MOQ: {product.minOrderQuantity}</p>
            </div>
            <div className="flex items-center gap-2">
                 <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(product.minOrderQuantity, Number(e.target.value)))}
                    min={product.minOrderQuantity}
                    className="w-16 p-1 border rounded-lg text-center text-sm"
                />
                <button
                    onClick={handleAddToCartClick}
                    className="px-3 py-2 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 text-xs"
                >
                    Add
                </button>
            </div>
        </div>
    );
};


interface SourcingViewProps {
  user: User;
  requests: SourcingRequest[];
  onNewRequest: () => void;
  products: Product[];
  onAddToCart: (productId: number, quantity: number) => void;
}

const SourcingView: React.FC<SourcingViewProps> = ({ user, requests, onNewRequest, products, onAddToCart }) => {
  const [query, setQuery] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsSubmitting(true);
    
    // createSourcingRequest resolves immediately after adding the 'pending' request
    await createSourcingRequest(user.id, query);
    
    // Clear the input and refresh the list to show the new "pending" request
    setQuery('');
    onNewRequest();
    
    // The AI simulation runs for 5 seconds in the background.
    // After it's done, refresh the list again and re-enable the form.
    setTimeout(() => {
      onNewRequest();
      setIsSubmitting(false);
    }, 5100); // 5s for simulation + 100ms buffer
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-lg">
        <h2 className="text-2xl font-bold text-slate-800">Source with AI</h2>
        <p className="text-sm text-slate-500 mt-1">Can't find a product? Let our AI search factories and suppliers for you.</p>
        <form onSubmit={handleSubmit} className="mt-4 flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g., '1000L of sunflower oil from a factory in Gauteng'"
            className="flex-grow px-4 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500"
            disabled={isSubmitting}
          />
          <button type="submit" className="px-6 py-2 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-teal-400 flex items-center justify-center" disabled={isSubmitting}>
            {isSubmitting ? <LoaderIcon className="h-5 w-5" /> : 'Request'}
          </button>
        </form>
      </div>
      
      <div>
        <h3 className="text-xl font-bold text-slate-800 mb-4">Your Sourcing Requests</h3>
        {requests.length > 0 ? (
          <div className="space-y-3">
            {requests.map(req => (
              <div key={req.id} className="bg-white p-4 rounded-lg shadow-sm">
                <div className="flex justify-between items-start">
                    <div className="flex-grow pr-4">
                        <p className="font-semibold text-slate-700">{req.query}</p>
                        <p className="text-xs text-slate-500 mt-1">{new Date(req.date).toLocaleString()}</p>
                    </div>
                   <span className={`flex-shrink-0 capitalize text-xs font-bold px-2 py-1 rounded-full ${
                      req.status === 'complete' ? 'bg-green-100 text-green-800' :
                      req.status === 'sourcing' ? 'bg-blue-100 text-blue-800 animate-pulse' :
                      'bg-slate-100 text-slate-800'
                   }`}>{req.status}</span>
                </div>

                {req.status === 'complete' && req.foundProductIds && req.foundProductIds.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-slate-200">
                        <h4 className="text-sm font-semibold text-slate-600 mb-2">AI Found Product:</h4>
                        <div className="space-y-2">
                           {req.foundProductIds.map(productId => {
                                const product = products.find(p => p.id === productId);
                                if (!product) return null;
                                return <FoundProductCard key={product.id} product={product} onAddToCart={onAddToCart} />;
                            })}
                        </div>
                    </div>
                )}
              </div>
            ))}
          </div>
        ) : (
            <div className="text-center py-8 bg-white rounded-lg shadow-sm">
                <p className="text-slate-500">You haven't made any sourcing requests yet.</p>
            </div>
        )}
      </div>
    </div>
  );
};
export default SourcingView;
