
import React from 'react';
import type { Order } from '../types';
import { formatCurrency } from '../types';
import LoaderIcon from './icons/LoaderIcon';

interface OrderHistoryProps {
  orders: Order[];
  isLoading: boolean;
}

const OrderHistory: React.FC<OrderHistoryProps> = ({ orders, isLoading }) => {
  
  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'Delivered': return 'bg-green-100 text-green-800';
      case 'Shipped': return 'bg-blue-100 text-blue-800';
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      case 'Cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center p-12">
        <LoaderIcon className="h-12 w-12 text-teal-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
        <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-slate-800">Your Orders</h2>
            <p className="text-md text-slate-500 mt-2">Review your purchase history.</p>
        </div>
        {orders.length > 0 ? (
            <div className="space-y-4">
            {orders.map(order => (
                <div key={order.id} className="bg-white p-4 sm:p-6 rounded-2xl shadow-lg">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <p className="font-bold text-slate-800">Order #{order.id.split('-')[1]}</p>
                            <p className="text-sm text-slate-500">{new Date(order.date).toLocaleDateString()}</p>
                        </div>
                        <span className={`text-xs font-bold px-3 py-1 rounded-full ${getStatusColor(order.status)}`}>
                            {order.status}
                        </span>
                    </div>
                    <div className="space-y-2 border-t pt-4">
                        {order.items.map(item => (
                            <div key={item.productId} className="flex justify-between items-center text-sm">
                                <p className="text-slate-600">{item.name} <span className="text-slate-400">x {item.quantity}</span></p>
                                <p className="text-slate-800 font-medium">{formatCurrency(item.price * item.quantity)}</p>
                            </div>
                        ))}
                    </div>
                    <div className="border-t mt-4 pt-2 text-right">
                        <p className="font-bold text-slate-800">Total: {formatCurrency(order.totalAmount)}</p>
                    </div>
                </div>
            ))}
            </div>
        ) : (
             <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                <p className="text-slate-500">You have no past orders.</p>
            </div>
        )}
    </div>
  );
};

export default OrderHistory;
