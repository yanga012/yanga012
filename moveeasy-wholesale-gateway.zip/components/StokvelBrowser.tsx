import React from 'react';
import type { Stokvel, Product, Deal, Supplier, User } from '../types';
import { formatCurrency } from '../types';
import StokvelCard from './StokvelCard';
import LoaderIcon from './icons/LoaderIcon';
import TagIcon from './icons/TagIcon';

// DealCard Component (nested for simplicity)
const DealCard: React.FC<{ deal: Deal, product: Product, onSelectProduct: (id: number) => void }> = ({ deal, product, onSelectProduct }) => (
    <div className="bg-white rounded-2xl shadow-lg p-4 flex flex-col sm:flex-row items-center gap-4">
        <img src={product.imageUrl} alt={product.name} className="w-full sm:w-24 h-24 rounded-lg object-cover" />
        <div className="flex-grow text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-2">
                <TagIcon className="h-4 w-4 text-red-500"/>
                <h4 className="font-bold text-red-600 text-sm">EXCLUSIVE DEAL</h4>
            </div>
            <p className="font-bold text-slate-800 mt-1">{product.name}</p>
            <div className="flex items-baseline justify-center sm:justify-start gap-2 mt-1">
                <span className="text-xl font-extrabold text-red-600">{formatCurrency(deal.dealPrice)}</span>
                <span className="text-sm text-slate-500 line-through">{formatCurrency(product.price)}</span>
            </div>
             <p className="text-xs text-slate-500">Deal ends: {new Date(deal.expiryDate).toLocaleDateString()}</p>
        </div>
        <button 
            onClick={() => onSelectProduct(product.id)}
            className="w-full sm:w-auto mt-2 sm:mt-0 flex-shrink-0 px-4 py-2 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 text-sm"
        >
            View & Start Group Buy
        </button>
    </div>
);


interface StokvelBrowserProps {
  user: User;
  deals: Deal[];
  stokvels: Stokvel[];
  products: Product[];
  suppliers: Supplier[];
  isLoading: boolean;
  onSelectProduct: (productId: number) => void;
  onStokvelJoined: () => void;
  isLimitedAccess: boolean;
}

const StokvelBrowser: React.FC<StokvelBrowserProps> = ({ user, deals, stokvels, products, suppliers, isLoading, onSelectProduct, onStokvelJoined, isLimitedAccess }) => {
  if (isLoading) {
    return (
      <div className="flex justify-center p-12">
        <LoaderIcon className="h-12 w-12 text-teal-600" />
      </div>
    );
  }
  
  const regionalStokvels = stokvels.filter(s => s.region === user.region);
  const otherStokvels = stokvels.filter(s => s.region !== user.region);

  return (
    <div className="space-y-12">
      <div>
        <h2 className="text-3xl font-bold text-slate-800 text-center">Group Buys & Deals</h2>
        <p className="text-md text-slate-500 mt-2 text-center">Pool capital with other merchants to unlock factory-direct pricing.</p>
      </div>

      {/* Featured Deals Section */}
      <div>
        <h3 className="text-2xl font-bold text-slate-800 mb-4">Featured Supplier Deals</h3>
        {deals.length > 0 ? (
            <div className="space-y-4">
                {deals.map(deal => {
                    const product = products.find(p => p.id === deal.productId);
                    if (!product) return null;
                    return <DealCard key={deal.id} deal={deal} product={product} onSelectProduct={onSelectProduct} />;
                })}
            </div>
        ) : (
            <div className="text-center py-8 bg-white rounded-lg shadow-sm">
                <p className="text-slate-500">No exclusive supplier deals available right now.</p>
            </div>
        )}
      </div>

      {/* Active Group Buys Section */}
      <div>
         <h3 className="text-2xl font-bold text-slate-800 mb-4">Active Group Buys</h3>
         {regionalStokvels.length > 0 && (
            <div className="mb-8">
                <h4 className="font-semibold text-slate-600 mb-3">In Your Region ({user.region})</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {regionalStokvels.map(stokvel => {
                         const product = products.find(p => p.id === stokvel.productId);
                         const supplier = product ? suppliers.find(s => s.id === product.supplierId) : undefined;
                         if (!product) return null;
                         return <StokvelCard key={stokvel.id} user={user} stokvel={stokvel} product={product} supplier={supplier} onJoinSuccess={onStokvelJoined} isLimitedAccess={isLimitedAccess}/>;
                    })}
                </div>
            </div>
         )}
         
         {otherStokvels.length > 0 && (
            <div>
                <h4 className="font-semibold text-slate-600 mb-3">Other Regions</h4>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {otherStokvels.map(stokvel => {
                         const product = products.find(p => p.id === stokvel.productId);
                         const supplier = product ? suppliers.find(s => s.id === product.supplierId) : undefined;
                         if (!product) return null;
                         return <StokvelCard key={stokvel.id} user={user} stokvel={stokvel} product={product} supplier={supplier} onJoinSuccess={onStokvelJoined} isLimitedAccess={isLimitedAccess}/>;
                    })}
                </div>
            </div>
         )}

         {stokvels.length === 0 && (
             <div className="text-center py-8 bg-white rounded-lg shadow-sm">
                <p className="text-slate-500">No active group buys yet. Start one from a product page!</p>
            </div>
         )}
      </div>
    </div>
  );
};

export default StokvelBrowser;
