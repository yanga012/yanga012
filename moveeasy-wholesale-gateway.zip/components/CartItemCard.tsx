
import React from 'react';
import type { CartItem, Product } from '../types';
import { formatCurrency } from '../types';

interface CartItemCardProps {
  item: CartItem & { product: Product };
  onUpdateQuantity: (productId: number, newQuantity: number) => void;
  onRemoveItem: (productId: number) => void;
}

const CartItemCard: React.FC<CartItemCardProps> = ({ item, onUpdateQuantity, onRemoveItem }) => {
  const { product, quantity } = item;
  
  const minQuantity = product.minOrderQuantity || 1;

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let newQuantity = Number(e.target.value);
      if (newQuantity < minQuantity) {
          // Do not update if below min, or reset to min in blur event
          return;
      }
      onUpdateQuantity(product.id, newQuantity);
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
      let newQuantity = Number(e.target.value);
      if (newQuantity < minQuantity) {
          onUpdateQuantity(product.id, minQuantity);
      }
  }

  const handleRemove = () => {
      onRemoveItem(product.id);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-4 flex items-center gap-4">
      <img src={product.imageUrl} alt={product.name} className="w-24 h-24 rounded-lg object-cover flex-shrink-0" />
      <div className="flex-grow min-w-0">
        <h4 className="font-bold text-slate-800 truncate">{product.name}</h4>
        <p className="text-sm text-slate-500">{formatCurrency(product.price)} / unit</p>
        <div className="mt-2 flex items-center gap-2">
          <label htmlFor={`cart-qty-${product.id}`} className="text-sm font-medium text-slate-600">Qty:</label>
          <input
            id={`cart-qty-${product.id}`}
            type="number"
            value={quantity}
            min={minQuantity}
            onChange={handleQuantityChange}
            onBlur={handleBlur}
            className="w-20 p-1 border rounded-lg text-center"
          />
        </div>
      </div>
      <div className="text-right flex-shrink-0">
        <p className="font-bold text-slate-800 text-lg">{formatCurrency(product.price * quantity)}</p>
        <button onClick={handleRemove} className="text-sm text-red-500 hover:text-red-700 font-medium mt-2">
          Remove
        </button>
      </div>
    </div>
  );
};

export default CartItemCard;
