
import React, { useState } from 'react';
import type { User, Product } from '../types';
import * as api from '../services/api';
import LoaderIcon from './icons/LoaderIcon';

interface CreateStokvelModalProps {
  user: User;
  product: Product;
  onClose: () => void;
  onStokvelCreated: () => void;
}

const CreateStokvelModal: React.FC<CreateStokvelModalProps> = ({ user, product, onClose, onStokvelCreated }) => {
    const [targetQuantity, setTargetQuantity] = useState(product.minOrderQuantity * 10);
    const [endDate, setEndDate] = useState(() => {
        const date = new Date();
        date.setDate(date.getDate() + 14); // Default to 2 weeks
        return date.toISOString().split('T')[0];
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (targetQuantity <= product.minOrderQuantity) {
            setError(`Target must be greater than the minimum order quantity of ${product.minOrderQuantity}.`);
            return;
        }

        setIsLoading(true);
        try {
            await api.createStokvel(user.id, product.id, targetQuantity, new Date(endDate).toISOString(), user.region);
            onStokvelCreated();
            onClose();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to create group buy.');
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <div className="fixed inset-0 bg-black/50 z-30 flex justify-center items-center p-4" onClick={onClose}>
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                <div className="p-6 border-b">
                    <h2 className="text-xl font-bold text-slate-800">Start a Group Buy</h2>
                    <p className="text-sm text-slate-500 mt-1">Create a Stokvel for <span className="font-semibold">{product.name}</span></p>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="p-6 space-y-4">
                        <div>
                            <label htmlFor="targetQuantity" className="block text-sm font-medium text-slate-600 mb-1">Target Quantity</label>
                            <input 
                                id="targetQuantity"
                                type="number"
                                value={targetQuantity}
                                onChange={e => setTargetQuantity(Number(e.target.value))}
                                min={product.minOrderQuantity + 1}
                                className="w-full px-3 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500"
                                required
                            />
                            <p className="text-xs text-slate-500 mt-1">Your contribution will be the product's MOQ ({product.minOrderQuantity} units).</p>
                        </div>
                        <div>
                            <label htmlFor="endDate" className="block text-sm font-medium text-slate-600 mb-1">End Date</label>
                            <input 
                                id="endDate"
                                type="date"
                                value={endDate}
                                onChange={e => setEndDate(e.target.value)}
                                min={new Date().toISOString().split('T')[0]}
                                className="w-full px-3 py-2 border rounded-lg focus:ring-teal-500 focus:border-teal-500"
                                required
                            />
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-slate-600 mb-1">Region</label>
                            <input 
                                type="text"
                                value={user.region}
                                disabled
                                className="w-full px-3 py-2 border rounded-lg bg-slate-100"
                            />
                         </div>
                        {error && <p className="text-sm text-red-600">{error}</p>}
                    </div>
                    <div className="bg-slate-50 p-4 flex justify-end items-center gap-2 rounded-b-2xl">
                        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-bold text-slate-700 bg-white border rounded-lg hover:bg-slate-100">Cancel</button>
                        <button type="submit" disabled={isLoading} className="px-4 py-2 text-sm font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-teal-400 flex items-center justify-center min-w-[120px]">
                           {isLoading ? <LoaderIcon className="h-5 w-5" /> : 'Create Group Buy'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateStokvelModal;
