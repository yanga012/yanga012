// components/Dashboard.tsx
import React, { useState, useEffect, useCallback } from 'react';
import type { User, Product, Category, SourcingRequest, Stokvel, Deal, Supplier, CartItem, Order } from '../types';
import * as api from '../services/api';
import BottomNavBar from './BottomNavBar';
import ProductGrid from './ProductGrid';
import SourcingView from './SourcingView';
import StokvelBrowser from './StokvelBrowser';
import OrderHistory from './OrderHistory';
import CartView from './CartView';
import ProductDetailView from './ProductDetailView';
import SupplierDetailView from './SupplierDetailView';
import LoaderIcon from './icons/LoaderIcon';
import MailIcon from './icons/MailIcon';
import ShieldCheckIcon from './icons/ShieldCheckIcon';

type View = 'catalog' | 'sourcing' | 'stokvels' | 'orders' | 'cart';
type DetailView = { type: 'product'; id: number } | { type: 'supplier'; id: number } | null;

interface DashboardProps {
  user: User;
  onLogout: () => void;
  isLimitedAccess: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout, isLimitedAccess }) => {
  const [activeView, setActiveView] = useState<View>('catalog');
  const [detailView, setDetailView] = useState<DetailView>(null);

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [sourcingRequests, setSourcingRequests] = useState<SourcingRequest[]>([]);
  const [stokvels, setStokvels] = useState<Stokvel[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  const [isLoading, setIsLoading] = useState(true);

  const fetchData = useCallback(async (showLoader = true) => {
    if (showLoader) setIsLoading(true);
    try {
      const [productsData, categoriesData, suppliersData, sourcingRequestsData, stokvelsData, dealsData, cartData, ordersData] = await Promise.all([
        api.getProducts('', ''),
        api.getCategories(),
        api.getSuppliers(),
        api.getSourcingRequests(user.id),
        api.getStokvels(),
        api.getDeals(),
        api.getCart(user.id),
        api.getOrders(user.id),
      ]);
      setProducts(productsData);
      setCategories(categoriesData);
      setSuppliers(suppliersData);
      setSourcingRequests(sourcingRequestsData);
      setStokvels(stokvelsData);
      setDeals(dealsData);
      setCart(cartData);
      setOrders(ordersData);
    } catch (error) {
      console.error("Failed to fetch data", error);
    } finally {
      if (showLoader) setIsLoading(false);
    }
  }, [user.id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleSearch = async (query: string, category: string) => {
    setIsLoading(true);
    const productsData = await api.getProducts(query, category);
    setProducts(productsData);
    setIsLoading(false);
  };

  const handleAddToCart = async (productId: number, quantity: number) => {
    const newCart = await api.addToCart(user.id, productId, quantity);
    setCart(newCart);
  };
  
  const handleCartUpdate = (newCart: CartItem[]) => {
      setCart(newCart);
  }
  
  const handleOrderPlaced = () => {
      setActiveView('orders');
      fetchData(false); // Refetch all data without main loader
  }

  const handleSwitchView = (view: View) => {
    setActiveView(view);
    setDetailView(null);
  };
  
  const renderDetailView = () => {
    if (!detailView) return null;
    
    if (detailView.type === 'product') {
        const product = products.find(p => p.id === detailView.id);
        const supplier = product ? suppliers.find(s => s.id === product.supplierId) : undefined;
        if (!product || !supplier) return <div>Product not found</div>;
        return <ProductDetailView 
            user={user}
            product={product} 
            supplier={supplier} 
            onBack={() => setDetailView(null)}
            onAddToCart={handleAddToCart}
            onSelectSupplier={(id) => setDetailView({type: 'supplier', id})}
            onStokvelCreated={() => {
                fetchData(false);
                setActiveView('stokvels');
                setDetailView(null);
            }}
            isLimitedAccess={isLimitedAccess}
        />
    }
    
    if (detailView.type === 'supplier') {
        const supplier = suppliers.find(s => s.id === detailView.id);
        if (!supplier) return <div>Supplier not found</div>;
        return <SupplierDetailView 
            supplier={supplier}
            products={products}
            onBack={() => setDetailView(null)}
            onSelectProduct={(id) => setDetailView({type: 'product', id})}
            onAddToCart={handleAddToCart}
            isLimitedAccess={isLimitedAccess}
        />;
    }

    return null;
  }

  const renderActiveView = () => {
    if (isLoading) {
        return <div className="flex justify-center items-center h-64"><LoaderIcon className="h-12 w-12 text-teal-600"/></div>;
    }
      
    if(detailView) {
        return renderDetailView();
    }

    switch (activeView) {
      case 'catalog':
        return <ProductGrid products={products} categories={categories} isLoading={isLoading} onSearch={handleSearch} onAddToCart={handleAddToCart} onSelectProduct={(id) => setDetailView({type: 'product', id})} isLimitedAccess={isLimitedAccess} />;
      case 'sourcing':
        return <SourcingView user={user} requests={sourcingRequests} onNewRequest={() => fetchData(false)} products={products} onAddToCart={handleAddToCart}/>;
      case 'stokvels':
        return <StokvelBrowser user={user} deals={deals} stokvels={stokvels} products={products} suppliers={suppliers} isLoading={isLoading} onSelectProduct={(id) => setDetailView({type: 'product', id})} onStokvelJoined={() => fetchData(false)} isLimitedAccess={isLimitedAccess}/>;
      case 'orders':
        return <OrderHistory orders={orders} isLoading={isLoading}/>;
      case 'cart':
        const cartItemsWithProducts = cart
            .map(item => ({...item, product: products.find(p => p.id === item.productId)}))
            .filter(item => item.product) as (CartItem & {product: Product})[];
        return <CartView user={user} items={cartItemsWithProducts} onCartUpdate={handleCartUpdate} onOrderPlaced={handleOrderPlaced} isLimitedAccess={isLimitedAccess} />;
      default:
        return <ProductGrid products={products} categories={categories} isLoading={isLoading} onSearch={handleSearch} onAddToCart={handleAddToCart} onSelectProduct={(id) => setDetailView({type: 'product', id})} isLimitedAccess={isLimitedAccess} />;
    }
  };

  return (
    <div className="pb-20">
        <header className="bg-white shadow-sm sticky top-0 z-10 p-4 mb-6">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
                <div>
                  <h1 className="font-bold text-xl text-slate-800">Welcome, {user.name.split(' ')[0]}!</h1>
                  <div className="flex items-center gap-3 mt-1 text-xs">
                      <div className="flex items-center gap-1" title={`Email: ${user.isEmailVerified ? 'Verified' : 'Unverified'}`}>
                          <MailIcon className={`h-4 w-4 ${user.isEmailVerified ? 'text-green-500' : 'text-slate-400'}`} />
                          <span className={`${user.isEmailVerified ? 'text-slate-600' : 'text-slate-500'}`}>Email</span>
                      </div>
                      <div className="flex items-center gap-1" title={`KYC: ${user.isKycVerified ? 'Verified' : 'Unverified'}`}>
                          <ShieldCheckIcon className={`h-4 w-4 ${user.isKycVerified ? 'text-green-500' : 'text-slate-400'}`} />
                          <span className={`${user.isKycVerified ? 'text-slate-600' : 'text-slate-500'}`}>KYC</span>
                      </div>
                  </div>
                </div>
                <button onClick={onLogout} className="text-sm font-semibold text-teal-600 hover:underline self-start">Log Out</button>
            </div>
            {isLimitedAccess && (
                <div className="max-w-7xl mx-auto mt-3 bg-yellow-50 border border-yellow-200 text-yellow-800 text-xs font-semibold p-2 rounded-md text-center">
                    LIMITED ACCESS: Please complete KYC verification to unlock all features.
                </div>
            )}
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {renderActiveView()}
        </main>

        <BottomNavBar activeView={activeView} onSwitchView={handleSwitchView} cartCount={cart.length}/>
    </div>
  );
};

export default Dashboard;
