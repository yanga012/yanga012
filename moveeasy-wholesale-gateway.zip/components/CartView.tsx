import React, { useState } from 'react';
import type { CartItem, Product, User } from '../types';
import { formatCurrency } from '../types';
import * as api from '../services/api';
import CartItemCard from './CartItemCard';
import LoaderIcon from './icons/LoaderIcon';
import ShoppingCartIcon from './icons/ShoppingCartIcon';

interface CartViewProps {
  user: User;
  items: (CartItem & { product: Product })[];
  onCartUpdate: (newCart: CartItem[]) => void;
  onOrderPlaced: () => void;
  isLimitedAccess: boolean;
}

const CartView: React.FC<CartViewProps> = ({ user, items, onCartUpdate, onOrderPlaced, isLimitedAccess }) => {
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  
  const handleUpdateQuantity = async (productId: number, newQuantity: number) => {
    const updatedCart = await api.updateCartItemQuantity(user.id, productId, newQuantity);
    onCartUpdate(updatedCart);
  };
  
  const handleRemoveItem = async (productId: number) => {
    const updatedCart = await api.removeFromCart(user.id, productId);
    onCartUpdate(updatedCart);
  };

  const handlePlaceOrder = async () => {
    if (isLimitedAccess) return;
    setIsPlacingOrder(true);
    try {
        await api.placeOrder(user.id, items);
        onOrderPlaced(); // This will refetch all data, including clearing the cart view
    } catch (error) {
        console.error("Failed to place order:", error);
        // In a real app, show an error message to the user
    } finally {
        setIsPlacingOrder(false);
    }
  };

  const subtotal = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const vat = subtotal * 0.15;
  const total = subtotal + vat;

  if (isPlacingOrder) {
      return (
          <div className="flex flex-col justify-center items-center h-full text-center p-12 bg-white rounded-lg shadow-sm">
                <LoaderIcon className="h-12 w-12 text-teal-600 mb-4" />
                <h3 className="text-xl font-bold text-slate-800">Placing Your Order...</h3>
                <p className="text-slate-500">Please wait a moment.</p>
            </div>
      )
  }

  return (
    <div className="space-y-6">
        <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-slate-800">Your Cart</h2>
            <p className="text-md text-slate-500 mt-2">Review your items before checking out.</p>
        </div>
      {items.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          <div className="lg:col-span-2 space-y-4">
            {items.map(item => (
              <CartItemCard 
                key={item.productId} 
                item={item} 
                onUpdateQuantity={handleUpdateQuantity} 
                onRemoveItem={handleRemoveItem}
              />
            ))}
          </div>
          <div className="lg:col-span-1 bg-white rounded-2xl shadow-lg p-6 sticky top-24">
              <h3 className="text-xl font-bold text-slate-800 border-b pb-3">Order Summary</h3>
              <div className="space-y-2 mt-4">
                  <div className="flex justify-between text-slate-600">
                      <span>Subtotal</span>
                      <span>{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                      <span>VAT (15%)</span>
                      <span>{formatCurrency(vat)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-800 text-lg border-t pt-3 mt-2">
                      <span>Total</span>
                      <span>{formatCurrency(total)}</span>
                  </div>
              </div>
              <button 
                onClick={handlePlaceOrder}
                disabled={isLimitedAccess}
                title={isLimitedAccess ? "Verify your account to place an order" : "Place your order"}
                className="w-full mt-6 px-4 py-3 font-bold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:bg-slate-400 disabled:cursor-not-allowed"
              >
                Place Order
              </button>
          </div>
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-lg shadow-sm flex flex-col items-center">
            <ShoppingCartIcon className="h-16 w-16 text-slate-300 mb-4" />
            <h3 className="text-xl font-bold text-slate-800">Your cart is empty</h3>
            <p className="text-slate-500 mt-1">Browse the catalog to add products.</p>
        </div>
      )}
    </div>
  );
};

export default CartView;
