import React, { useState, useEffect } from 'react';
import type { User } from './types';
import * as api from './services/api';
import Login from './components/Login';
import SignUp from './components/SignUp';
import Dashboard from './components/Dashboard';
import EmailVerification from './components/EmailVerification';
import VerificationGate from './components/VerificationGate';
import LoaderIcon from './components/icons/LoaderIcon';
import MoveEasyLogo from './components/icons/MoveEasyLogo';

type AuthState = 'loading' | 'login' | 'signup' | 'verify_email' | 'verify_kyc' | 'dashboard';

const App: React.FC = () => {
  const [authState, setAuthState] = useState<AuthState>('loading');
  const [user, setUser] = useState<User | null>(null);
  const [isLimitedAccess, setIsLimitedAccess] = useState(false);

  const determineAuthState = (user: User | null) => {
    if (!user) {
      setAuthState('login');
      return;
    }
    
    setUser(user);
    if (!user.isEmailVerified) {
      setAuthState('verify_email');
    } else if (!user.isKycVerified) {
      setAuthState('verify_kyc');
    } else {
      setAuthState('dashboard');
    }
  };
  
  useEffect(() => {
    const savedUser = localStorage.getItem('moveeasy_user');
    determineAuthState(savedUser ? JSON.parse(savedUser) : null);
  }, []);

  const updateUserSession = (updatedUser: User) => {
    setUser(updatedUser);
    localStorage.setItem('moveeasy_user', JSON.stringify(updatedUser));
    determineAuthState(updatedUser); // Re-evaluate the state after update
  };

  const handleLogin = async (email: string, pass: string) => {
    const loggedInUser = await api.login(email, pass);
    updateUserSession(loggedInUser);
  };

  const handleSignUp = async (name: string, email: string, pass: string, region: User['region'], role: User['role']) => {
    const newUser = await api.signUp(name, email, pass, region, role);
    updateUserSession(newUser);
  };

  const handleLogout = () => {
    setUser(null);
    setIsLimitedAccess(false);
    localStorage.removeItem('moveeasy_user');
    setAuthState('login');
  };
  
  const handleSkipKyc = () => {
      setIsLimitedAccess(true);
      setAuthState('dashboard');
  };

  const renderContent = () => {
    switch (authState) {
      case 'loading':
        return (
          <div className="flex flex-col items-center gap-4">
            <MoveEasyLogo className="text-teal-600" />
            <LoaderIcon className="h-8 w-8 text-teal-600" />
          </div>
        );
      case 'login':
        return <Login onLogin={handleLogin} onSwitchToSignUp={() => setAuthState('signup')} />;
      case 'signup':
        return <SignUp onSignUp={handleSignUp} onSwitchToLogin={() => setAuthState('login')} />;
      case 'verify_email':
        if (!user) return null;
        return <EmailVerification user={user} onVerified={updateUserSession} onLogout={handleLogout} />;
      case 'verify_kyc':
        if (!user) return null;
        return <VerificationGate user={user} onKycSubmitted={updateUserSession} onSkip={handleSkipKyc}/>;
      case 'dashboard':
        if (!user) return null;
        return <Dashboard user={user} onLogout={handleLogout} isLimitedAccess={isLimitedAccess} />;
      default:
        return <Login onLogin={handleLogin} onSwitchToSignUp={() => setAuthState('signup')} />;
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen font-sans">
      <div className={authState === 'dashboard' ? '' : 'flex items-center justify-center min-h-screen p-4'}>
         {renderContent()}
      </div>
    </div>
  );
};

export default App;