// types.ts

export type UserRole = 'Trader' | 'Source';
export type Region = 'Gauteng' | 'Western Cape' | 'KwaZulu-Natal' | 'Eastern Cape';

export interface KycDetails {
  businessName?: string;
  registrationNumber?: string;
  vatNumber?: string;
  permitUrl?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  isEmailVerified: boolean;
  isKycVerified: boolean;
  kycDetails?: KycDetails;
  region: Region;
  role: UserRole;
}

export interface Category {
  id: string;
  name: string;
}

export interface Supplier {
  id: number;
  name: string;
  location: string;
  isVerified: boolean;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  minOrderQuantity: number;
  supplierId: number;
  categoryId: string;
}

export type SourcingRequestStatus = 'pending' | 'sourcing' | 'complete' | 'failed';

export interface SourcingRequest {
  id: number;
  userId: string;
  query: string;
  date: string;
  status: SourcingRequestStatus;
  foundProductIds?: number[];
}

export interface StokvelMember {
  userId: string;
  contribution: number; // quantity
}

export interface Stokvel {
  id: number;
  productId: number;
  targetQuantity: number;
  currentQuantity: number;
  members: StokvelMember[];
  endDate: string;
  region: Region;
}

export interface Deal {
  id: number;
  productId: number;
  dealPrice: number;
  expiryDate: string;
}

export interface CartItem {
  userId: string;
  productId: number;
  quantity: number;
}

export interface OrderItem {
  productId: number;
  name: string;
  quantity: number;
  price: number; // price at time of order
}

export type OrderStatus = 'Pending' | 'Shipped' | 'Delivered' | 'Cancelled';

export interface Order {
  id: string;
  userId: string;
  date: string;
  items: OrderItem[];
  totalAmount: number;
  status: OrderStatus;
}

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-ZA', {
    style: 'currency',
    currency: 'ZAR',
  }).format(amount);
};
