import type { User, Product, Category, Supplier, SourcingRequest, Stokvel, Deal } from '../types';

export const mockUsers: User[] = [
  {
    id: 'user_1',
    name: 'Thabo Ndlovu',
    email: 'thabo@example.com',
    passwordHash: '123456',
    isEmailVerified: true,
    isKycVerified: true,
    kycDetails: { businessName: "Thabo's Trades" },
    region: 'Gauteng',
    role: 'Trader',
  },
  {
    id: 'user_2',
    name: 'Verified Tester',
    email: 'test@example.com',
    passwordHash: '123456',
    isEmailVerified: true,
    isKycVerified: true,
    kycDetails: { businessName: "Tester Inc." },
    region: 'Western Cape',
    role: 'Trader',
  },
   {
    id: 'user_3',
    name: 'Partial User',
    email: 'partial@example.com',
    passwordHash: '123456',
    isEmailVerified: true,
    isKycVerified: false,
    region: 'KwaZulu-Natal',
    role: 'Source',
  },
];

export const mockCategories: Category[] = [
    { id: 'cat_1', name: 'Groceries' },
    { id: 'cat_2', name: 'Electronics' },
    { id: 'cat_3', name: 'Hardware' },
    { id: 'cat_4', name: 'Cleaning Supplies' },
];

export const mockSuppliers: Supplier[] = [
    { id: 1, name: 'Joburg Wholesalers', location: 'Johannesburg, Gauteng', isVerified: true },
    { id: 2, name: 'Cape Town Imports', location: 'Cape Town, Western Cape', isVerified: true },
    { id: 3, name: 'Durban Direct', location: 'Durban, KwaZulu-Natal', isVerified: false },
];

export const mockProducts: Product[] = [
    {
        id: 1,
        name: 'Sunflower Oil - 20L',
        description: 'High-quality cooking oil, perfect for restaurants and catering. Locally sourced and refined.',
        price: 350.00,
        imageUrl: 'https://images.unsplash.com/photo-1625758600962-f089a81b3a3d?q=80&w=800',
        minOrderQuantity: 10,
        supplierId: 1,
        categoryId: 'cat_1',
    },
    {
        id: 2,
        name: 'Maize Meal - 10kg Bags',
        description: 'Bulk pack of staple maize meal. Ideal for retailers and community feeding schemes.',
        price: 85.00,
        imageUrl: 'https://images.unsplash.com/photo-1590312356394-1a3b4f6d8c4e?q=80&w=800',
        minOrderQuantity: 50,
        supplierId: 1,
        categoryId: 'cat_1',
    },
    {
        id: 3,
        name: 'Imported Power Banks - 10000mAh',
        description: 'High-capacity power banks with fast charging capabilities. Sold in boxes of 20.',
        price: 150.00,
        imageUrl: 'https://images.unsplash.com/photo-1588855140939-9a79a61f3a53?q=80&w=800',
        minOrderQuantity: 20,
        supplierId: 2,
        categoryId: 'cat_2',
    },
    {
        id: 4,
        name: 'Rooibos Tea Bags (Bulk Pack 1000)',
        description: 'Authentic South African Rooibos tea. Bulk packed for hospitality and retail.',
        price: 250.00,
        imageUrl: 'https://images.unsplash.com/photo-1597352123918-5a415a78297f?q=80&w=800',
        minOrderQuantity: 10,
        supplierId: 2,
        categoryId: 'cat_1',
    },
     {
        id: 5,
        name: 'Industrial Bleach - 25L Drum',
        description: 'Concentrated bleach for industrial and commercial cleaning. Handle with care.',
        price: 180.00,
        imageUrl: 'https://images.unsplash.com/photo-1584441221379-3c8dbe4949a2?q=80&w=800',
        minOrderQuantity: 5,
        supplierId: 3,
        categoryId: 'cat_4',
    },
     {
        id: 6,
        name: 'Galvanized Roofing Screws (Box of 5000)',
        description: 'Durable roofing screws for construction and hardware retail.',
        price: 450.00,
        imageUrl: 'https://images.unsplash.com/photo-1595379735497-2261e405a74e?q=80&w=800',
        minOrderQuantity: 10,
        supplierId: 1,
        categoryId: 'cat_3',
    }
];


export const mockSourcingRequests: SourcingRequest[] = [
    {
        id: 1,
        userId: 'user_1',
        query: '2000kg of A-grade potatoes from Limpopo',
        date: new Date(Date.now() - 86400000 * 2).toISOString(), // 2 days ago
        status: 'complete',
        foundProductIds: [],
    },
];

export const mockStokvels: Stokvel[] = [
    {
        id: 1,
        productId: 2, // Maize Meal
        targetQuantity: 1000,
        currentQuantity: 350,
        members: [
            { userId: 'user_x', contribution: 50 },
            { userId: 'user_y', contribution: 100 },
            { userId: 'user_z', contribution: 200 },
        ],
        endDate: new Date(Date.now() + 86400000 * 10).toISOString(), // 10 days from now
        region: 'Gauteng',
    },
    {
        id: 2,
        productId: 4, // Rooibos Tea
        targetQuantity: 50,
        currentQuantity: 40,
        members: [
            { userId: 'user_1', contribution: 10 },
            { userId: 'user_a', contribution: 10 },
            { userId: 'user_b', contribution: 20 },
        ],
        endDate: new Date(Date.now() + 86400000 * 5).toISOString(), // 5 days from now
        region: 'Western Cape',
    }
];

export const mockDeals: Deal[] = [
    {
        id: 1,
        productId: 3, // Power Banks
        dealPrice: 135.00,
        expiryDate: new Date(Date.now() + 86400000 * 7).toISOString(), // 7 days from now
    }
];
