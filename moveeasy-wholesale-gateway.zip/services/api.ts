// services/api.ts
import * as db from './mock-data';
import type { User, Product, CartItem, Order, SourcingRequest, Stokvel, KycDetails } from '../types';

// In-memory database simulation
let users: User[] = [...db.mockUsers];
const products: Product[] = [...db.mockProducts];
let sourcingRequests: SourcingRequest[] = [...db.mockSourcingRequests];
let stokvels: Stokvel[] = [...db.mockStokvels];
let orders: Order[] = [];
let carts: CartItem[] = [];

const simulateDelay = (ms: number) => new Promise(res => setTimeout(res, ms));

// --- Auth & Verification ---
export const login = async (email: string, pass: string): Promise<User> => {
  await simulateDelay(500);
  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (user && user.passwordHash === pass) {
    return user;
  }
  throw new Error('Invalid email or password');
};

export const signUp = async (name: string, email: string, pass: string, region: User['region'], role: User['role']): Promise<User> => {
    await simulateDelay(500);
    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
        throw new Error('An account with this email already exists.');
    }
    const newUser: User = {
        id: `user_${Date.now()}`,
        name,
        email,
        passwordHash: pass,
        isEmailVerified: false,
        isKycVerified: false,
        region,
        role,
    };
    users.push(newUser);
    return newUser;
};

export const sendVerificationCode = async (email: string): Promise<void> => {
    await simulateDelay(1000);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    // In a real app, this sends an email. Here we'll store it and log it.
    localStorage.setItem(`verification_code_${email}`, code);
    console.log(`Verification code for ${email}: ${code}`);
};

export const verifyEmailCode = async (email: string, code: string): Promise<User> => {
    await simulateDelay(500);
    const storedCode = localStorage.getItem(`verification_code_${email}`);
    if (storedCode === code) {
        const userIndex = users.findIndex(u => u.email === email);
        if (userIndex > -1) {
            users[userIndex].isEmailVerified = true;
            localStorage.removeItem(`verification_code_${email}`);
            return users[userIndex];
        }
    }
    throw new Error('Invalid verification code.');
};

export const submitKyc = async (userId: string, kycDetails: KycDetails): Promise<User> => {
    await simulateDelay(1500);
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex > -1) {
        users[userIndex].kycDetails = kycDetails;
        users[userIndex].isKycVerified = true; // Simulate auto-approval
        return users[userIndex];
    }
    throw new Error('User not found.');
};


// --- Data Fetching ---
export const getProducts = async (query: string, category: string): Promise<Product[]> => {
    await simulateDelay(300);
    let filteredProducts = products;
    if (query) {
        filteredProducts = filteredProducts.filter(p => p.name.toLowerCase().includes(query.toLowerCase()));
    }
    if (category) {
        filteredProducts = filteredProducts.filter(p => p.categoryId === category);
    }
    return filteredProducts;
};

export const getCategories = async () => { await simulateDelay(50); return db.mockCategories; };
export const getSuppliers = async () => { await simulateDelay(50); return db.mockSuppliers; };
export const getStokvels = async () => { await simulateDelay(200); return stokvels; };
export const getDeals = async () => { await simulateDelay(150); return db.mockDeals; };
export const getSourcingRequests = async (userId: string) => { 
    await simulateDelay(100);
    return sourcingRequests.filter(r => r.userId === userId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};
export const getOrders = async (userId: string) => {
    await simulateDelay(250);
    return orders.filter(o => o.userId === userId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

// --- Cart ---
export const getCart = async (userId: string): Promise<CartItem[]> => {
    await simulateDelay(50);
    return carts.filter(item => item.userId === userId);
};

export const addToCart = async (userId: string, productId: number, quantity: number): Promise<CartItem[]> => {
    await simulateDelay(100);
    const existingItem = carts.find(item => item.userId === userId && item.productId === productId);
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        carts.push({ userId, productId, quantity });
    }
    return getCart(userId);
};

export const updateCartItemQuantity = async (userId: string, productId: number, newQuantity: number): Promise<CartItem[]> => {
    await simulateDelay(50);
    const item = carts.find(i => i.userId === userId && i.productId === productId);
    if (item) {
        if (newQuantity > 0) {
            item.quantity = newQuantity;
        } else {
            return removeFromCart(userId, productId);
        }
    }
    return getCart(userId);
};

export const removeFromCart = async (userId: string, productId: number): Promise<CartItem[]> => {
    await simulateDelay(50);
    const index = carts.findIndex(i => i.userId === userId && i.productId === productId);
    if (index > -1) {
        carts.splice(index, 1);
    }
    return getCart(userId);
};

// --- Orders ---
export const placeOrder = async (userId: string, items: (CartItem & {product: Product})[]): Promise<Order> => {
    await simulateDelay(1000);
    const totalAmount = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0) * 1.15; // with VAT
    const newOrder: Order = {
        id: `order-${Date.now()}`,
        userId,
        date: new Date().toISOString(),
        items: items.map(i => ({ productId: i.productId, name: i.product.name, quantity: i.quantity, price: i.product.price })),
        totalAmount,
        status: 'Pending',
    };
    orders.push(newOrder);
    // Clear cart for user
    const userCartItemIds = items.map(i => i.productId);
    for (let i = carts.length - 1; i >= 0; i--) {
        if (carts[i].userId === userId && userCartItemIds.includes(carts[i].productId)) {
            carts.splice(i, 1);
        }
    }
    return newOrder;
};

// --- AI Sourcing ---
export const createSourcingRequest = async (userId: string, query: string): Promise<void> => {
    const newRequest: SourcingRequest = {
        id: Date.now(),
        userId,
        query,
        date: new Date().toISOString(),
        status: 'pending',
    };
    sourcingRequests.push(newRequest);

    setTimeout(() => { newRequest.status = 'sourcing'; }, 1000);
    setTimeout(() => {
        const foundProduct = products.find(p => p.name.toLowerCase().includes('oil'));
        if (foundProduct) {
            newRequest.status = 'complete';
            newRequest.foundProductIds = [foundProduct.id];
        } else {
            newRequest.status = 'failed';
        }
    }, 5000);
};

// --- Stokvels / Group Buys ---
export const createStokvel = async (userId: string, productId: number, targetQuantity: number, endDate: string, region: User['region']): Promise<Stokvel> => {
    await simulateDelay(600);
    const product = products.find(p => p.id === productId);
    if (!product) throw new Error("Product not found");

    const newStokvel: Stokvel = {
        id: Date.now(),
        productId,
        targetQuantity,
        endDate,
        region,
        currentQuantity: product.minOrderQuantity,
        members: [{ userId, contribution: product.minOrderQuantity }],
    };
    stokvels.push(newStokvel);
    return newStokvel;
};

export const joinStokvel = async (userId: string, stokvelId: number): Promise<void> => {
    await simulateDelay(400);
    const stokvel = stokvels.find(s => s.id === stokvelId);
    if (!stokvel) throw new Error("Group buy not found.");
    if (stokvel.members.some(m => m.userId === userId)) throw new Error("You have already joined this group buy.");

    const product = products.find(p => p.id === stokvel.productId);
    if (!product) throw new Error("Product for this group buy not found.");

    stokvel.members.push({ userId, contribution: product.minOrderQuantity });
    stokvel.currentQuantity += product.minOrderQuantity;
};
